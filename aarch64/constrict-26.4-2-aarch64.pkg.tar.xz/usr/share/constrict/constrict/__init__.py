APPLICATION_ID = 'io.github.wartybix.Constrict'
PREFIX = '/io/github/wartybix/Constrict'
VERSION = '26.4'
# interfaces/sound.py
#
# Copyright 2025 revisto
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# SPDX-License-Identifier: GPL-3.0-or-later

from abc import ABC, abstractmethod


class ISoundService(ABC):
    @abstractmethod
    def load_sounds(self) -> None:
        pass

    @abstractmethod
    def play_sound(self, sound_name: str) -> None:
        pass

    @abstractmethod
    def set_volume(self, volume: float) -> None:
        pass

    @abstractmethod
    def preview_sound(self, sound_name: str) -> None:
        """Play a preview of the sound at preview volume level"""
        pass

    @abstractmethod
    def stop_all_sounds(self) -> None:
        """Stop all currently playing sounds"""
        pass

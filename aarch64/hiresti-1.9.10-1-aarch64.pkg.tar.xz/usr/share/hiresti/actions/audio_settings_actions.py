from threading import Thread
from types import SimpleNamespace
import logging
import os
import re
import shlex
import subprocess
import tempfile
import time

import gi
gi.require_version('Gtk', '4.0')
from gi.repository import Gtk, GLib, Gdk

from core.executor import submit_daemon

logger = logging.getLogger(__name__)

_OUTPUT_BIT_DEPTH_GUESS_FORMATS = {
    16: "S16LE",
    24: "S24LE",
    32: "S32LE",
}

DRIVER_ALSA_AUTO = "ALSA（auto）"
DRIVER_ALSA_MMAP = "ALSA（mmap）"
DRIVER_USB_RAWLINK_V2 = "USB Rawlink v2"

USB_CLOCK_OPTIONS = ["Push", "Pull"]
USB_CLOCK_DEFAULT = "Push"
_USB_CLOCK_MODE_MAP = {"Push": 0, "Pull": 1}
_PLAYBACK_STATUS_NORMAL = "normal"
_PLAYBACK_STATUS_BIT_PERFECT = "bit-perfect"
_PLAYBACK_STATUS_EXCLUSIVE = "exclusive"
_PLAYBACK_STATUS_DSP = "dsp"
_PLAYBACK_STATUS_ICONS = {
    _PLAYBACK_STATUS_NORMAL: "hiresti-status-normal-symbolic",
    _PLAYBACK_STATUS_BIT_PERFECT: "hiresti-status-bit-perfect-symbolic",
    _PLAYBACK_STATUS_EXCLUSIVE: "hiresti-status-exclusive-symbolic",
    _PLAYBACK_STATUS_DSP: "hiresti-status-dsp-symbolic",
}
_PLAYBACK_STATUS_TOOLTIPS = {
    _PLAYBACK_STATUS_NORMAL: "Normal Mode",
    _PLAYBACK_STATUS_BIT_PERFECT: "Bit-Perfect Mode Active",
    _PLAYBACK_STATUS_EXCLUSIVE: "Exclusive Mode Active",
    _PLAYBACK_STATUS_DSP: "DSP Processing Active",
}


def _dsp_processing_active(app):
    player = getattr(app, "player", None)
    if player is None or not bool(getattr(player, "dsp_enabled", False)):
        return False

    settings = getattr(app, "settings", {}) or {}
    convolver_path = str(
        getattr(player, "convolver_ir_path", "")
        or settings.get("dsp_convolver_path", "")
        or ""
    ).strip()
    if bool(getattr(player, "peq_enabled", False)):
        return True
    if bool(getattr(player, "convolver_enabled", False)) and bool(convolver_path):
        return True
    if bool(getattr(player, "limiter_enabled", False)):
        return True
    if bool(getattr(player, "resampler_enabled", False)):
        return True
    if bool(getattr(player, "tape_enabled", False)):
        return True
    if bool(getattr(player, "tube_enabled", False)):
        return True
    if bool(getattr(player, "widener_enabled", False)):
        return True
    return False


def _playback_status_visual(app):
    player = getattr(app, "player", None)
    if player is not None:
        if bool(getattr(player, "exclusive_lock_mode", False)):
            status = _PLAYBACK_STATUS_EXCLUSIVE
        elif bool(getattr(player, "bit_perfect_mode", False)):
            status = _PLAYBACK_STATUS_BIT_PERFECT
        elif _dsp_processing_active(app):
            status = _PLAYBACK_STATUS_DSP
        else:
            status = _PLAYBACK_STATUS_NORMAL
    else:
        status = _PLAYBACK_STATUS_NORMAL
    return status, _PLAYBACK_STATUS_ICONS[status], _PLAYBACK_STATUS_TOOLTIPS[status]


def _sync_playback_status_icon(self):
    _status, icon_name, tooltip = _playback_status_visual(self)
    for btn in (
        getattr(self, "playback_status_btn", None),
        getattr(self, "now_playing_status_btn", None),
    ):
        if btn is None:
            continue
        try:
            btn.set_icon_name(icon_name)
        except Exception:
            pass
        try:
            btn.set_tooltip_text(tooltip)
        except Exception:
            pass


def _canonical_output_format_name(fmt):
    up = str(fmt or "").strip().upper()
    mapping = {
        "S16_LE": "S16LE",
        "S16LE": "S16LE",
        "S24_LE": "S24LE",
        "S24LE": "S24LE",
        "S24_3LE": "S24LE",
        "S24_32_LE": "S24_32LE",
        "S24_32LE": "S24_32LE",
        "S32_LE": "S32LE",
        "S32LE": "S32LE",
    }
    return mapping.get(up, up)


def _output_format_bit_depth(fmt):
    up = _canonical_output_format_name(fmt)
    if not up:
        return 0
    if "S24_32" in up:
        return 24
    match = re.search(r"(\d+)", up)
    if not match:
        return 0
    try:
        return int(match.group(1))
    except Exception:
        return 0


def _device_supported_output_formats(device_info):
    if not isinstance(device_info, dict):
        return []
    out = []
    seen = set()
    for raw in list(device_info.get("supported_formats") or []):
        fmt = _canonical_output_format_name(raw)
        depth = _output_format_bit_depth(fmt)
        if depth not in (16, 24, 32):
            continue
        if fmt in seen:
            continue
        seen.add(fmt)
        out.append(fmt)
    return out


def _device_supported_bit_depths(device_info):
    seen = set()
    out = []
    for fmt in _device_supported_output_formats(device_info):
        depth = _output_format_bit_depth(fmt)
        if depth in (16, 24, 32) and depth not in seen:
            seen.add(depth)
            out.append(depth)
    if out:
        return out
    if isinstance(device_info, dict):
        for raw in list(device_info.get("supported_bit_depths") or []):
            try:
                depth = int(raw or 0)
            except Exception:
                depth = 0
            if depth in (16, 24, 32) and depth not in seen:
                seen.add(depth)
                out.append(depth)
    out.sort()
    return out


def _bit_depth_labels_for_device(device_info):
    return ["Auto"] + [f"{depth}-bit" for depth in _device_supported_bit_depths(device_info)]


def _parse_output_bit_depth_label(label):
    text = str(label or "").strip()
    if not text or text.lower() == "auto":
        return 0
    match = re.search(r"(\d+)", text)
    if not match:
        return 0
    try:
        depth = int(match.group(1))
    except Exception:
        return 0
    return depth if depth in (16, 24, 32) else 0


def _current_selected_device_info(app):
    dd = getattr(app, "device_dd", None)
    devices = list(getattr(app, "current_device_list", []) or [])
    if dd is None or not devices:
        return None
    try:
        idx = int(dd.get_selected())
    except Exception:
        idx = 0
    if 0 <= idx < len(devices):
        return devices[idx]
    return None


def _preferred_output_format_for_device(device_info, label):
    depth = _parse_output_bit_depth_label(label)
    if depth <= 0:
        return None
    for fmt in _device_supported_output_formats(device_info):
        if _output_format_bit_depth(fmt) == depth:
            return fmt
    if depth in _device_supported_bit_depths(device_info):
        return _OUTPUT_BIT_DEPTH_GUESS_FORMATS.get(depth)
    return None


def _selected_driver_name(app):
    dd = getattr(app, "driver_dd", None)
    item = dd.get_selected_item() if dd is not None else None
    return item.get_string() if item is not None else ""


def _driver_key(driver_name):
    text = str(driver_name or "").strip().lower()
    text = text.replace("（", "(").replace("）", ")")
    compact = text.replace(" ", "")
    if compact in ("usbrawlinkv2", "usb_rawlink_v2", "usbrawlink", "usb_rawlink"):
        # Legacy "USB Rawlink" labels migrate to V2 transparently — V1 is gone.
        return "usb_rawlink_v2"
    if compact in ("alsa_mmap", "alsa(mmap)"):
        return "alsa_mmap"
    if compact in ("alsa", "alsa(auto)"):
        return "alsa_auto"
    if compact in ("pipewire",):
        return "pipewire"
    if compact in ("auto", "auto(default)"):
        return "auto"
    return compact


def _driver_is_alsa_family(driver_name):
    return _driver_key(driver_name) in ("alsa_auto", "alsa_mmap")


def _driver_is_usb_rawlink_family(driver_name):
    return _driver_key(driver_name) == "usb_rawlink_v2"


def _is_usb_rawlink_to_alsa_switch(previous_driver_name, target_driver_name):
    return _driver_is_usb_rawlink_family(previous_driver_name) and _driver_is_alsa_family(target_driver_name)


def _release_output_before_driver_enumeration(app, previous_driver_name, target_driver_name):
    if not _is_usb_rawlink_to_alsa_switch(previous_driver_name, target_driver_name):
        return
    player = getattr(app, "player", None)
    if player is None or not hasattr(player, "release_output_route"):
        return
    try:
        logger.info(
            "Pre-releasing USB Rawlink session before ALSA enumeration: from=%s to=%s",
            previous_driver_name,
            target_driver_name,
        )
        player.release_output_route()
    except Exception:
        logger.debug("Pre-release before ALSA enumeration failed", exc_info=True)


def _schedule_output_refresh_after_usb_release(app, previous_driver_name, target_driver_name):
    if not _is_usb_rawlink_to_alsa_switch(previous_driver_name, target_driver_name):
        return

    target_key = _driver_key(target_driver_name)

    def _refresh():
        if _driver_key(_selected_driver_name(app)) != target_key:
            return False
        prefer_device_id = str(getattr(getattr(app, "player", None), "requested_device_id", "") or "") or None
        try:
            _refresh_devices_for_current_driver_ui_only(
                app,
                reason="usb-rawlink-release",
                prefer_device_id=prefer_device_id,
            )
        except Exception:
            logger.debug("Post-release ALSA device refresh failed", exc_info=True)
        return False

    GLib.idle_add(_refresh)
    GLib.timeout_add(900, _refresh)
    GLib.timeout_add(1800, _refresh)


def _driver_choices_for_mode(app, exclusive_enabled=None):
    player = getattr(app, "player", None)
    drivers = list(player.get_drivers() or []) if player is not None else []
    if exclusive_enabled is None:
        # The historical exclusive_lock toggle is gone — Bit-Perfect is the
        # single source of truth for the "hide PipeWire + Auto Default"
        # filter. Prefer the live player state and fall back to the saved
        # setting (covers calls that run before the player has been told
        # about Bit-Perfect on startup).
        bp_state = getattr(player, "bit_perfect_mode", None) if player is not None else None
        if bp_state is None:
            bp_state = bool(getattr(app, "settings", {}).get("bit_perfect", False))
        exclusive_enabled = bool(bp_state)
    if exclusive_enabled:
        drivers = [drv for drv in drivers if _driver_is_alsa_family(drv) or _driver_is_usb_rawlink_family(drv)]
    return drivers


def _refresh_driver_dropdown_options(app, preferred_driver=None, exclusive_enabled=None):
    dd = getattr(app, "driver_dd", None)
    if dd is None:
        return ""
    drivers = _driver_choices_for_mode(app, exclusive_enabled=exclusive_enabled)
    if not drivers:
        return ""
    target = str(
        preferred_driver
        or _selected_driver_name(app)
        or getattr(app, "settings", {}).get("driver", "")
        or ""
    ).strip()
    target_key = _driver_key(target)
    if target not in drivers:
        for candidate in drivers:
            if _driver_key(candidate) == target_key:
                target = candidate
                break
        else:
            target = DRIVER_ALSA_AUTO if DRIVER_ALSA_AUTO in drivers else drivers[0]
    app.ignore_driver_change = True
    try:
        dd.set_model(Gtk.StringList.new(drivers))
        dd.set_selected(drivers.index(target))
    finally:
        app.ignore_driver_change = False
    return target


def _driver_supports_explicit_output_bit_depth(app):
    return _driver_is_alsa_family(_selected_driver_name(app))


def _apply_output_bit_depth_preference(app, device_info=None):
    player = getattr(app, "player", None)
    if player is None:
        return None
    fmt = None
    if _driver_supports_explicit_output_bit_depth(app):
        label = str(getattr(app, "settings", {}).get("output_bit_depth", "Auto") or "Auto")
        fmt = _preferred_output_format_for_device(device_info, label)
    if hasattr(player, "set_output_format_preference"):
        player.set_output_format_preference(fmt)
    else:
        setattr(player, "preferred_output_format", str(fmt or ""))
    return fmt


def _sync_output_bit_depth_dropdown(app, device_info=None):
    dd = getattr(app, "bit_depth_dd", None)
    if dd is None:
        _apply_output_bit_depth_preference(app, device_info)
        return
    if _driver_supports_explicit_output_bit_depth(app):
        labels = _bit_depth_labels_for_device(device_info)
        saved = str(getattr(app, "settings", {}).get("output_bit_depth", "Auto") or "Auto")
        selected_label = saved if saved in labels else "Auto"
        if selected_label != saved:
            app.settings["output_bit_depth"] = selected_label
            if hasattr(app, "save_settings"):
                app.save_settings()
        sensitive = len(labels) > 1
        selected_idx = labels.index(selected_label)
    else:
        labels = ["Auto"]
        sensitive = False
        selected_idx = 0
    app.ignore_output_bit_depth_change = True
    dd.set_model(Gtk.StringList.new(labels))
    dd.set_sensitive(sensitive)
    dd.set_selected(selected_idx)
    app.ignore_output_bit_depth_change = False
    _apply_output_bit_depth_preference(app, device_info)


def _device_enum_signature(devices):
    sig = []
    for info in list(devices or []):
        if not isinstance(info, dict):
            continue
        sig.append(
            (
                str(info.get("name") or ""),
                str(info.get("device_id") or ""),
                tuple(str(v or "") for v in list(info.get("supported_formats") or [])),
                tuple(int(v or 0) for v in list(info.get("supported_bit_depths") or [])),
            )
        )
    return tuple(sig)


def _stop_output_hotplug_watch(app):
    source_id = getattr(app, "_output_hotplug_source", 0)
    if source_id:
        try:
            GLib.source_remove(source_id)
        except Exception:
            pass
    app._output_hotplug_source = 0


def _refresh_devices_for_current_driver_ui_only(app, reason="hotplug-watch", prefer_device_id=None):
    """Refresh current driver's device dropdown only, without applying output switch."""
    selected_driver = app.driver_dd.get_selected_item()
    if not selected_driver:
        return
    driver_name = selected_driver.get_string()
    selected_item = app.device_dd.get_selected_item()
    prefer_name = selected_item.get_string() if selected_item else getattr(app, "current_device_name", None)

    def worker():
        devices = app.player.get_devices_for_driver(driver_name)

        def apply_devices():
            old_sig = _device_enum_signature(getattr(app, "current_device_list", []))
            new_sig = _device_enum_signature(devices)
            new_names = [d.get("name") for d in devices]
            if new_sig == old_sig:
                return False
            old_names = [d.get("name") for d in getattr(app, "current_device_list", [])]
            old_set = set([n for n in old_names if n])
            new_set = set([n for n in new_names if n])
            added = [n for n in new_names if n in (new_set - old_set)]

            app.ignore_device_change = True
            app.current_device_list = devices
            app.device_dd.set_model(Gtk.StringList.new(new_names))
            _min_dev = 1 if _driver_is_usb_rawlink_family(driver_name) else 2
            app.device_dd.set_sensitive(len(devices) >= _min_dev)

            sel_idx = 0
            if prefer_device_id:
                for i, d in enumerate(devices):
                    if d.get("device_id") == prefer_device_id:
                        sel_idx = i
                        break
            elif prefer_name:
                for i, d in enumerate(devices):
                    if d.get("name") == prefer_name:
                        sel_idx = i
                        break
            if devices and sel_idx < len(devices):
                app.device_dd.set_selected(sel_idx)
                app.current_device_name = devices[sel_idx].get("name") or app.current_device_name
            device_info = devices[sel_idx] if devices and sel_idx < len(devices) else None
            _sync_output_bit_depth_dropdown(app, device_info)
            app.ignore_device_change = False
            app.update_tech_label(app.player.stream_info)
            if hasattr(app, "_update_dsp_ui_state"):
                app._update_dsp_ui_state()
            logger.info("Output device list refreshed (%s): %d devices", reason, len(devices))
            if reason == "hotplug-watch" and added and hasattr(app, "show_output_notice"):
                remembered_name = str(getattr(app, "_last_disconnected_device_name", "") or "")
                remembered_driver = str(getattr(app, "_last_disconnected_driver", "") or "")
                if remembered_name and remembered_driver == driver_name and remembered_name in added:
                    auto_rebind = bool(getattr(app, "settings", {}).get("output_auto_rebind_once", False))
                    if auto_rebind:
                        now_mono = time.monotonic()
                        cooldown_until = float(getattr(app, "_auto_rebind_cooldown_until", 0.0) or 0.0)
                        if now_mono < cooldown_until:
                            remain = int(max(1, round(cooldown_until - now_mono)))
                            app.show_output_notice(
                                f"Your previous device is back: {remembered_name}. Auto rebind cooling down ({remain}s), switch manually if needed.",
                                "warn",
                                3800,
                            )
                            app._last_disconnected_device_name = ""
                            app._last_disconnected_driver = ""
                            _stop_output_hotplug_watch(app)
                            logger.info("Output hotplug watch stopped: auto-rebind cooldown active")
                            return False
                        target_idx = None
                        target_device = None
                        for i, d in enumerate(devices):
                            if d.get("name") == remembered_name:
                                target_idx = i
                                target_device = d
                                break
                        if target_idx is not None and target_device is not None:
                            app.ignore_device_change = True
                            app.device_dd.set_selected(target_idx)
                            app.current_device_name = target_device.get("name") or app.current_device_name
                            app.settings["device"] = app.current_device_name
                            app.save_settings()
                            app.ignore_device_change = False
                            app.update_tech_label(app.player.stream_info)

                            def _apply_auto_rebind():
                                app.player.set_output(driver_name, target_device.get("device_id"))
                                if hasattr(app, "_apply_viz_sync_offset_for_device"):
                                    app._apply_viz_sync_offset_for_device(
                                        driver_name,
                                        device_id=target_device.get("device_id"),
                                        device_name=target_device.get("name"),
                                    )
                                GLib.idle_add(lambda: update_output_status_ui(app) or False)

                            Thread(target=_apply_auto_rebind, daemon=True).start()
                            app.show_output_notice(
                                f"Your previous device is back: {remembered_name}. Switched back automatically.",
                                "ok",
                                4200,
                            )
                            app._auto_rebind_cooldown_until = now_mono + 15.0
                        else:
                            app.show_output_notice(
                                f"Your previous device is back: {remembered_name}. You can switch back in Output settings.",
                                "ok",
                                4200,
                            )
                    else:
                        app.show_output_notice(
                            f"Your previous device is back: {remembered_name}. You can switch back in Output settings.",
                            "ok",
                            4200,
                        )
                    app._last_disconnected_device_name = ""
                    app._last_disconnected_driver = ""
                    _stop_output_hotplug_watch(app)
                    logger.info("Output hotplug watch stopped: previous device rediscovered")
                    return False
                name = added[0]
                if len(added) > 1:
                    app.show_output_notice(
                        f"New audio devices detected ({len(added)}). Example: {name}",
                        "ok",
                        3600,
                    )
                else:
                    app.show_output_notice(
                        f"New audio device detected: {name}",
                        "ok",
                        3200,
                    )
                # Stop hotplug polling once new devices are discovered.
                _stop_output_hotplug_watch(app)
                logger.info("Output hotplug watch stopped: new device discovered")
            return False

        GLib.idle_add(apply_devices)

    Thread(target=worker, daemon=True).start()


def start_output_hotplug_watch(app, seconds=60, interval_ms=1000, slow_interval_ms=5000):
    """Start two-stage device auto-refresh after disconnect.

    Stage-1 (fast): interval_ms for `seconds`.
    Stage-2 (slow): slow_interval_ms until stopped by rediscovery or caller.
    """
    _stop_output_hotplug_watch(app)
    now_us = GLib.get_monotonic_time()
    app._output_hotplug_deadline = now_us + int(seconds * 1_000_000)
    app._output_hotplug_fast_interval_us = int(max(200, interval_ms) * 1000)
    app._output_hotplug_slow_interval_us = int(max(1000, slow_interval_ms) * 1000)
    app._output_hotplug_next_probe_us = 0
    logger.info(
        "Output hotplug watch started: fast_seconds=%s fast_interval_ms=%s slow_interval_ms=%s",
        seconds,
        interval_ms,
        slow_interval_ms,
    )

    def _tick():
        now = GLib.get_monotonic_time()
        deadline = int(getattr(app, "_output_hotplug_deadline", 0) or 0)
        fast_us = int(getattr(app, "_output_hotplug_fast_interval_us", 1_000_000) or 1_000_000)
        slow_us = int(getattr(app, "_output_hotplug_slow_interval_us", 5_000_000) or 5_000_000)
        next_probe = int(getattr(app, "_output_hotplug_next_probe_us", 0) or 0)
        current_us = fast_us if (deadline and now < deadline) else slow_us
        if next_probe and now < next_probe:
            return True
        app._output_hotplug_next_probe_us = now + current_us
        _refresh_devices_for_current_driver_ui_only(app, reason="hotplug-watch")
        return True

    # Keep 1s timer and internally gate probes for slow phase.
    app._output_hotplug_source = GLib.timeout_add(1000, _tick)


def refresh_devices_keep_driver_select_first(app, reason="device-refresh"):
    """Refresh device list for current driver, keep driver unchanged, select first available device."""
    selected_driver = app.driver_dd.get_selected_item()
    if not selected_driver:
        return
    driver_name = selected_driver.get_string()

    def worker():
        devices = app.player.get_devices_for_driver(driver_name)

        def apply_devices():
            app.ignore_device_change = True
            app.current_device_list = devices
            app.device_dd.set_model(Gtk.StringList.new([d["name"] for d in devices]))
            app.device_dd.set_sensitive(len(devices) > 1)

            if not devices:
                app.current_device_name = "Unavailable"
                _sync_output_bit_depth_dropdown(app, None)
                app.ignore_device_change = False
                try:
                    app.player.output_state = "error"
                    app.player.output_error = f"No available output devices for {driver_name}"
                except Exception:
                    pass
                if hasattr(app, "show_output_notice"):
                    app.show_output_notice(
                        f"No available output devices for {driver_name}. Waiting for reconnect...",
                        "error",
                        3600,
                    )
                update_output_status_ui(app)
                return False

            sel_idx = 0
            app.device_dd.set_selected(sel_idx)
            target = devices[sel_idx]
            app.current_device_name = target["name"]
            app.settings["device"] = target["name"]
            app.save_settings()
            _sync_output_bit_depth_dropdown(app, target)
            app.ignore_device_change = False
            app.update_tech_label(app.player.stream_info)

            def apply_output_async():
                logger.warning(
                    "Output auto-rebind (%s): driver=%s device=%s",
                    reason,
                    driver_name,
                    target.get("device_id"),
                )
                ok = app.player.set_output(driver_name, target.get("device_id"))
                if not ok:
                    if hasattr(app, "show_output_notice"):
                        app.show_output_notice(
                            f"Failed to switch output to {target.get('name')}",
                            "error",
                            3500,
                        )
                if hasattr(app, "_apply_viz_sync_offset_for_device"):
                    app._apply_viz_sync_offset_for_device(
                        driver_name,
                        device_id=target.get("device_id"),
                        device_name=target.get("name"),
                    )
                GLib.idle_add(lambda: update_output_status_ui(app) or False)

            Thread(target=apply_output_async, daemon=True).start()
            return False

        GLib.idle_add(apply_devices)

    Thread(target=worker, daemon=True).start()


def setup_device_dropdown_refresh_gesture(app):
    """Attach a click gesture so the device dropdown re-enumerates USB only on user open.

    Replaces the previous 2.5s polling loop. Enumerating USB devices issues
    control transfers to every connected device (including the actively
    streaming DAC), which produces audible micro-stutters on some firmware
    (e.g. FiiO KA13). Doing it only on user-initiated drop-open keeps the
    list fresh without bothering the audio path during steady-state playback.
    """
    if getattr(app, "_device_dd_refresh_gesture", None) is not None:
        return
    if not hasattr(app, "device_dd") or app.device_dd is None:
        return
    gesture = Gtk.GestureClick.new()
    gesture.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
    gesture.set_button(0)

    def _on_press(_g, _n_press, _x, _y):
        try:
            drv_item = app.driver_dd.get_selected_item() if hasattr(app, "driver_dd") else None
            if not drv_item:
                return
            driver_name = drv_item.get_string()
            if _driver_key(driver_name) not in (
                "alsa_auto", "alsa_mmap", "pipewire", "usb_rawlink_v2"
            ):
                return
            if getattr(app, "ignore_device_change", False):
                return
            _refresh_devices_for_current_driver_ui_only(app, reason="dropdown-open")
        except Exception:
            logger.exception("device dropdown refresh failed")

    gesture.connect("pressed", _on_press)
    app.device_dd.add_controller(gesture)
    app._device_dd_refresh_gesture = gesture


def update_output_status_ui(app):
    if not hasattr(app, "output_status_label") or app.output_status_label is None:
        if hasattr(app, "_sync_playback_status_icon"):
            app._sync_playback_status_icon()
        return

    state = getattr(app.player, "output_state", "idle")
    err = getattr(app.player, "output_error", None)
    text = state.capitalize()
    if err and state in ("fallback", "error"):
        text = f"{text}: {err}"
    app.output_status_label.set_text(text)

    class_map = {
        "active": "status-active",
        "fallback": "status-fallback",
        "error": "status-error",
        "switching": "status-switching",
        "idle": "status-idle",
    }
    for cls in ("status-active", "status-fallback", "status-error", "status-switching", "status-idle"):
        app.output_status_label.remove_css_class(cls)
    app.output_status_label.add_css_class(class_map.get(state, "status-idle"))

    prev_state = getattr(app, "_last_output_state", None)
    prev_err = getattr(app, "_last_output_error", None)
    changed = (state != prev_state) or (state in ("fallback", "error") and err != prev_err)
    if changed and hasattr(app, "on_output_state_transition"):
        app.on_output_state_transition(prev_state, state, err)
    app._last_output_state = state
    app._last_output_error = err

    # If snd-usb-audio just finished re-attaching (after USB rawlink release),
    # the device list had a placeholder entry with no hw: label.  Refresh now
    # so it shows the proper hw:X,Y device.
    if getattr(app.player, "_needs_device_list_refresh", False):
        app.player._needs_device_list_refresh = False
        try:
            _refresh_devices_for_current_driver_ui_only(app, reason="alsa-device-ready")
        except Exception:
            pass

    err_low = str(err or "").lower()
    is_usb_perm_error = (
        state == "error"
        and bool(err)
        and any(
            k in err_low
            for k in ("access denied", "permission denied", "insufficient permissions", "eacces")
        )
        and _driver_is_usb_rawlink_family(getattr(app.player, "requested_driver", ""))
    )
    if hasattr(app, "usb_fix_perm_btn") and app.usb_fix_perm_btn is not None:
        app.usb_fix_perm_btn.set_visible(is_usb_perm_error)

    # USB Rawlink replug timing race: if the udev rule already covers this device,
    # the ACL just hasn't been applied yet.  Schedule one silent auto-retry after
    # 2.5 s instead of requiring the user to click "Fix USB Permissions".
    if is_usb_perm_error and not getattr(app, "_usb_perm_auto_retry_pending", False):
        device_id = getattr(app.player, "requested_device_id", None)
        if device_id and _usb_rule_covers_device(device_id):
            app._usb_perm_auto_retry_pending = True
            logger.info("USB permission timing race detected — auto-retry in 2.5 s")
            def _auto_retry():
                app._usb_perm_auto_retry_pending = False
                on_recover_output_clicked(app)
                return False
            GLib.timeout_add(2500, _auto_retry)

    can_recover = state in ("fallback", "error") and bool(getattr(app.player, "requested_driver", None))
    if hasattr(app, "output_recover_btn") and app.output_recover_btn is not None:
        app.output_recover_btn.set_sensitive(can_recover)
    if hasattr(app, "set_diag_health"):
        if state == "active":
            app.set_diag_health("output", "ok")
        elif state in ("fallback", "switching"):
            app.set_diag_health("output", "warn", err)
        elif state == "error":
            app.set_diag_health("output", "error", err)
        else:
            app.set_diag_health("output", "idle")
    if hasattr(app, "_sync_playback_status_icon"):
        app._sync_playback_status_icon()


_USB_UDEV_RULE_PATH = "/etc/udev/rules.d/99-hiresti-usb-audio.rules"
_USB_AUDIO_INTERFACES_GLOB = "*:01????:*"
_USB_AUDIO_INTERFACES_REGEX = r"^ID_USB_INTERFACES=.*:01[[:xdigit:]]{4}:"


def _build_udev_rule_content(device_id=None):
    """Return the udev rule file content.

    Always includes a generic rule matching any USB Audio Class device via
    ID_USB_INTERFACES (populated by 50-udev-default.rules → usb_id builtin).

    If ``device_id`` is a known ``usb:VVVV:PPPP`` identifier, also adds a
    VID/PID-specific rule using ``ATTRS{idVendor}``/``ATTRS{idProduct}``.
    These sysfs attributes are always present on ``add`` events without any
    import, making the device-specific rule reliable even when the generic
    rule's ID_USB_INTERFACES match is delayed or unavailable.

    TAG+="uaccess" grants access to the currently-active logged-in session
    user via systemd-logind; it persists across replugs as long as the rule
    file is installed.
    """
    lines = [
        "# HiresTI USB Rawlink - grant logged-in user access to USB audio devices",
        # Generic rule: any USB device advertising an Audio-class interface.
        f'SUBSYSTEM=="usb", ENV{{DEVTYPE}}=="usb_device",'
        f' ENV{{ID_USB_INTERFACES}}=="{_USB_AUDIO_INTERFACES_GLOB}", TAG+="uaccess"',
    ]
    target = _parse_usb_rawlink_device_id(device_id)
    if target is not None:
        # Device-specific rule: matched by VID/PID, no property import needed.
        # This ensures the device is re-granted access on every replug even if
        # the generic class rule hasn't matched yet at the time of the add event.
        lines.append(
            f'SUBSYSTEM=="usb", ENV{{DEVTYPE}}=="usb_device",'
            f' ATTRS{{idVendor}}=="{target["vendor_id"]}",'
            f' ATTRS{{idProduct}}=="{target["product_id"]}", TAG+="uaccess"'
        )
    return "\n".join(lines) + "\n"


def _parse_usb_rawlink_device_id(device_id):
    text = str(device_id or "").strip()
    if not text.lower().startswith("usb:"):
        return None
    parts = text.split(":")
    if len(parts) < 3:
        return None
    vendor_id = parts[1].strip().lower()
    product_id = parts[2].strip().lower()
    if not re.fullmatch(r"[0-9a-f]{4}", vendor_id):
        return None
    if not re.fullmatch(r"[0-9a-f]{4}", product_id):
        return None
    serial = ":".join(parts[3:]).strip() if len(parts) > 3 else ""
    return {
        "vendor_id": vendor_id,
        "product_id": product_id,
        "serial": serial or None,
    }


_USB_UDEV_RULE_CONTENT = _build_udev_rule_content()


def _build_usb_audio_acl_script(device_id=None):
    target = _parse_usb_rawlink_device_id(device_id)
    lines = [
        'for _d in /dev/bus/usb/*/*; do',
        '  _props=$(udevadm info -q property -n "$_d" 2>/dev/null || true)',
        '  printf \'%s\\n\' "$_props" | grep -q "^DEVTYPE=usb_device$" || continue',
    ]
    if target is None:
        lines.append(
            f'  printf \'%s\\n\' "$_props" | grep -Eiq {shlex.quote(_USB_AUDIO_INTERFACES_REGEX)} || continue'
        )
    else:
        vendor_pat = shlex.quote(f"^ID_VENDOR_ID={target['vendor_id']}$")
        product_pat = shlex.quote(f"^ID_MODEL_ID={target['product_id']}$")
        lines.extend(
            [
                f'  printf \'%s\\n\' "$_props" | grep -Eiq {vendor_pat} || continue',
                f'  printf \'%s\\n\' "$_props" | grep -Eiq {product_pat} || continue',
            ]
        )
        if target["serial"]:
            serial_line = shlex.quote(f"ID_SERIAL_SHORT={target['serial']}")
            lines.append(
                f'  printf \'%s\\n\' "$_props" | grep -Fqx -- {serial_line} || continue'
            )
    lines.extend(
        [
            '  setfacl -m "u:$_U:rw" "$_d" 2>/dev/null || true',
            'done',
        ]
    )
    return "\n".join(lines)


def _build_usb_permission_install_cmd(tmp_path, device_id=None):
    quoted_tmp = shlex.quote(str(tmp_path))
    quoted_rule = shlex.quote(_USB_UDEV_RULE_PATH)
    acl_script = _build_usb_audio_acl_script(device_id)
    return (
        f"cp {quoted_tmp} {quoted_rule} "
        f"&& udevadm control --reload-rules "
        f"&& udevadm trigger --subsystem-match=usb "
        f"&& udevadm settle --timeout=3 "
        f'&& _U=$(id -nu "$PKEXEC_UID" 2>/dev/null || id -nu) '
        f"&& {acl_script} "
        f"&& rm -f {quoted_tmp}"
    )


def _build_manual_udev_setup_script(device_id=None):
    """Return a copy-pasteable shell snippet that installs the udev rule by hand.

    Uses ``sudo`` instead of ``pkexec`` so it works in a terminal without a
    polkit authentication agent (relevant for wlroots compositors such as
    Hyprland/Sway, which don't auto-start a polkit agent).  The exact udev rule
    — including the detected VID:PID when known — is embedded via a heredoc.
    """
    rule_content = _build_udev_rule_content(device_id).rstrip("\n")
    lines = [
        f"sudo tee {_USB_UDEV_RULE_PATH} > /dev/null <<'EOF'",
        rule_content,
        "EOF",
        "sudo udevadm control --reload-rules",
        "sudo udevadm trigger --subsystem-match=usb",
    ]
    return "\n".join(lines) + "\n"


def _copy_text_to_clipboard(app, text):
    """Best-effort clipboard copy via the app window, falling back to the display."""
    for getter in (
        lambda: getattr(app, "win", None) and app.win.get_clipboard(),
        lambda: (Gdk.Display.get_default() and Gdk.Display.get_default().get_clipboard()),
    ):
        try:
            clipboard = getter()
        except Exception:
            clipboard = None
        if clipboard is not None:
            try:
                clipboard.set(str(text))
                return True
            except Exception:
                logger.debug("Clipboard copy failed", exc_info=True)
    return False


def _show_usb_manual_setup_dialog(app, device_id=None, intro=None):
    """Show a dialog with a copyable manual udev-rule install snippet.

    Used when automatic install via pkexec is unavailable or fails (e.g. no
    polkit agent on wlroots compositors), so users can finish setup by hand.
    """
    win = getattr(app, "win", None)
    dialog = Gtk.Dialog(title="Manual USB Setup", transient_for=win, modal=True)
    try:
        dialog.set_default_size(620, -1)
    except Exception:
        pass
    root = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=12,
        margin_top=16,
        margin_bottom=16,
        margin_start=20,
        margin_end=20,
    )
    intro_text = intro or (
        "Automatic setup needs a polkit authentication agent, which isn't running.\n"
        "On Hyprland/Sway and other wlroots compositors no agent is started by "
        "default, so the password prompt can't appear.\n\n"
        "Run the commands below in a terminal to install the USB access rule "
        "manually, then replug the DAC (or re-select it) and start playback."
    )
    msg = Gtk.Label(label=intro_text, wrap=True, xalign=0.0, max_width_chars=64)
    root.append(msg)

    script = _build_manual_udev_setup_script(device_id)
    text_view = Gtk.TextView()
    text_view.set_editable(False)
    text_view.set_monospace(True)
    text_view.set_wrap_mode(Gtk.WrapMode.NONE)
    text_view.get_buffer().set_text(script)
    scroller = Gtk.ScrolledWindow()
    scroller.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
    scroller.set_min_content_height(150)
    scroller.set_child(text_view)
    try:
        scroller.add_css_class("card")
    except Exception:
        pass
    root.append(scroller)

    action_row = Gtk.Box(spacing=8, halign=Gtk.Align.END)
    copy_btn = Gtk.Button(label="Copy Commands")
    close_btn = Gtk.Button(label="Close", css_classes=["suggested-action"])
    action_row.append(copy_btn)
    action_row.append(close_btn)
    root.append(action_row)
    dialog.set_child(root)

    def _on_copy(_b):
        if _copy_text_to_clipboard(app, script):
            copy_btn.set_label("Copied")
            if hasattr(app, "show_output_notice"):
                app.show_output_notice("Manual USB setup commands copied to clipboard.", "ok", 2200)

    copy_btn.connect("clicked", _on_copy)
    close_btn.connect("clicked", lambda _b: dialog.response(Gtk.ResponseType.CLOSE))
    dialog.connect("response", lambda d, _r: d.destroy())
    dialog.present()


_USB_FALLBACK_NAME_RE = re.compile(
    r'^USB Audio Device \([0-9a-f]{4}:[0-9a-f]{4}\)$', re.IGNORECASE
)


def _usb_device_needs_permission(dev):
    """True if this USB Rawlink device was enumerated without read permission."""
    return bool(_USB_FALLBACK_NAME_RE.match(str(dev.get("name") or "")))


def _show_usb_permission_dialog(app, dev_name, device_id):
    """Ask user whether to grant USB access; if yes, run pkexec install."""
    dialog = Gtk.Dialog(title="USB Access Required", transient_for=app.win, modal=True)
    root = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=12,
        margin_top=16,
        margin_bottom=16,
        margin_start=20,
        margin_end=20,
    )
    msg = Gtk.Label(
        label=(
            f"USB audio device detected, but access permission is missing.\n\n"
            f"Grant system-level USB access for \"{dev_name}\"?\n\n"
            "This installs a udev rule and requires your password."
        ),
        wrap=True,
        xalign=0.0,
        max_width_chars=52,
    )
    root.append(msg)
    action_row = Gtk.Box(spacing=8, halign=Gtk.Align.END)
    no_btn = Gtk.Button(label="Not Now")
    manual_btn = Gtk.Button(label="Manual Setup")
    yes_btn = Gtk.Button(label="Grant Access", css_classes=["suggested-action"])
    action_row.append(no_btn)
    action_row.append(manual_btn)
    action_row.append(yes_btn)
    root.append(action_row)
    dialog.set_child(root)

    def _on_response(d, resp):
        d.destroy()
        if resp == Gtk.ResponseType.YES:
            on_usb_fix_permissions_clicked(app, device_id=device_id)
        elif resp == Gtk.ResponseType.APPLY:
            _show_usb_manual_setup_dialog(
                app,
                device_id,
                intro=(
                    "Run the commands below in a terminal to grant USB access for "
                    f"\"{dev_name}\" manually, then replug the DAC (or re-select it) "
                    "and start playback."
                ),
            )

    no_btn.connect("clicked", lambda _b: dialog.response(Gtk.ResponseType.NO))
    manual_btn.connect("clicked", lambda _b: dialog.response(Gtk.ResponseType.APPLY))
    yes_btn.connect("clicked", lambda _b: dialog.response(Gtk.ResponseType.YES))
    dialog.connect("response", _on_response)
    dialog.present()


def _usb_rule_covers_device(device_id):
    """True if the installed udev rule file has a VID:PID-specific rule for this device.

    When the rule file already covers the exact VID:PID, any fallback name seen at
    enumeration time is a transient timing race (udev ACL not yet applied).  The
    device cache handles the identity restore; we don't need to prompt the user.
    """
    target = _parse_usb_rawlink_device_id(device_id)
    if not target:
        return False
    try:
        content = open(_USB_UDEV_RULE_PATH).read()
        return (
            f'idVendor}}=="{target["vendor_id"]}"' in content
            and f'idProduct}}=="{target["product_id"]}"' in content
        )
    except OSError:
        return False


def _check_and_prompt_usb_permission(app, devices):
    """Show permission dialog if USB Rawlink devices lack access and no rule covers them.

    Only prompts when the udev rule file does NOT already have a VID:PID entry for the
    affected device.  If the rule is present, the fallback name is a transient timing
    race (udev ACL not yet applied on replug) — the device cache handles identity
    restore and no user action is needed.
    """
    if getattr(app, "_usb_perm_dialog_shown", False):
        return
    needs_perm = [d for d in devices if _usb_device_needs_permission(d)]
    if not needs_perm:
        return
    # If every fallback device is already covered by the installed rule, it's a timing
    # race — udev will grant access within ~1 s.  Don't interrupt the user.
    if all(_usb_rule_covers_device(d.get("device_id")) for d in needs_perm):
        return
    app._usb_perm_dialog_shown = True
    dev = needs_perm[0]
    _show_usb_permission_dialog(app, dev.get("name", "USB audio device"), dev.get("device_id"))


def on_usb_fix_permissions_clicked(app, _btn=None, device_id=None):
    if hasattr(app, "usb_fix_perm_btn") and app.usb_fix_perm_btn is not None:
        app.usb_fix_perm_btn.set_sensitive(False)

    try:
        requested_device_id = device_id or getattr(getattr(app, "player", None), "requested_device_id", None)
        rule_content = _build_udev_rule_content(requested_device_id)

        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".rules", delete=False, prefix="hiresti_usb_"
        )
        tmp.write(rule_content)
        tmp.close()
        tmp_path = tmp.name

        # Install the udev rule AND directly set ACLs on the current USB
        # Rawlink target (or, if unavailable, USB Audio Class devices only).
        # TAG+="uaccess" is processed asynchronously by systemd-logind, so there
        # is a window after udevadm settle returns where the ACL may not yet be
        # applied.  The setfacl step provides an immediate, synchronous grant
        # that takes effect before pkexec returns, eliminating the race.
        # $PKEXEC_UID is set by pkexec to the invoking user's UID.
        cmd = _build_usb_permission_install_cmd(tmp_path, requested_device_id)

        def _on_done(proc):
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            rc = proc.returncode

            def _ui():
                if hasattr(app, "usb_fix_perm_btn") and app.usb_fix_perm_btn is not None:
                    app.usb_fix_perm_btn.set_sensitive(True)
                if rc == 0:
                    logger.info("USB udev rule installed successfully")
                    if hasattr(app, "record_diag_event"):
                        app.record_diag_event("USB permission rule installed via pkexec")
                    # Extra 1s delay: systemd-logind sets ACLs asynchronously after
                    # udevadm settle returns, so give it a moment before retrying.
                    # Also refresh the device list so the real device name/serial is
                    # read and the USB device cache is populated — this prevents the
                    # "needs re-auth" dialog from appearing on subsequent replugs.
                    def _recover_and_refresh():
                        on_recover_output_clicked(app)
                        _refresh_devices_for_current_driver_ui_only(app, reason="usb-perm-granted")
                        return False
                    GLib.timeout_add(1000, _recover_and_refresh)
                else:
                    logger.warning("pkexec USB rule install failed (rc=%d)", rc)
                    if hasattr(app, "record_diag_event"):
                        app.record_diag_event(f"USB permission rule install failed (pkexec rc={rc})")
                    # The automatic install via polkit failed (no agent, dismissed, or
                    # not authorized).  Tell the user instead of silently degrading, and
                    # offer the copy-pasteable manual udev steps.
                    if hasattr(app, "show_output_notice"):
                        app.show_output_notice(
                            "Couldn't install the USB access rule automatically. "
                            "Showing manual setup steps.",
                            "error",
                            4200,
                        )
                    _show_usb_manual_setup_dialog(app, requested_device_id)

            GLib.idle_add(_ui)

        def _run():
            try:
                proc = subprocess.run(["pkexec", "/bin/sh", "-c", cmd])
                rc = proc.returncode
            except FileNotFoundError:
                # pkexec is not installed — common on minimal/wlroots setups.
                logger.warning("pkexec not found; cannot auto-install USB rule")
                rc = 127
            except Exception:
                logger.exception("pkexec USB rule install raised")
                rc = 1
            _on_done(SimpleNamespace(returncode=rc))

        Thread(target=_run, daemon=True).start()

    except Exception as e:
        logger.error("USB fix permissions error: %s", e)
        if hasattr(app, "usb_fix_perm_btn") and app.usb_fix_perm_btn is not None:
            app.usb_fix_perm_btn.set_sensitive(True)


def on_recover_output_clicked(app, _btn=None):
    driver = getattr(app.player, "requested_driver", None)
    device_id = getattr(app.player, "requested_device_id", None)
    if not driver:
        return
    logger.info("Recovering output to requested target: driver=%s device=%s", driver, device_id)
    if hasattr(app, "record_diag_event"):
        app.record_diag_event(f"Recover output requested: {driver} / {device_id or 'default'}")
    app.player.set_output(driver, device_id)
    if hasattr(app, "_apply_viz_sync_offset_for_device"):
        app._apply_viz_sync_offset_for_device(driver, device_id=device_id, device_name=getattr(app, "current_device_name", None))
    update_output_status_ui(app)


def on_latency_changed(app, dd, p):
    selected = dd.get_selected_item()
    if not selected:
        return
    profile_name = selected.get_string()

    app.settings["latency_profile"] = profile_name
    app.save_settings()

    if profile_name in app.LATENCY_MAP:
        buf_ms, lat_ms = app.LATENCY_MAP[profile_name]
        app.player.set_alsa_latency(buf_ms, lat_ms)
        logger.info(
            "Audio latency profile applied: buffer=%dms latency=%dms (latency-change, viz offset unchanged, profile=%s)",
            int(buf_ms),
            int(lat_ms),
            profile_name,
        )

        if _driver_is_alsa_family(_selected_driver_name(app)):
            logger.info("Latency changed, restarting output")
            app.on_driver_changed(app.driver_dd, None)


def on_mmap_realtime_priority_changed(app, dd, p):
    selected = dd.get_selected_item()
    if not selected:
        return
    profile_name = selected.get_string()

    app.settings["alsa_mmap_realtime_priority"] = profile_name
    app.save_settings()

    priority = app.ALSA_MMAP_REALTIME_PRIORITY_MAP.get(
        profile_name,
        app.ALSA_MMAP_REALTIME_PRIORITY_MAP[app.ALSA_MMAP_REALTIME_PRIORITY_DEFAULT],
    )
    app.player.set_alsa_mmap_realtime_priority(priority)
    logger.info(
        "ALSA mmap realtime priority applied: priority=%d (priority-change, profile=%s)",
        int(priority),
        profile_name,
    )

    if _driver_key(_selected_driver_name(app)) == "alsa_mmap":
        logger.info("Realtime priority changed, restarting ALSA mmap output")
        app.on_driver_changed(app.driver_dd, None)


def on_usb_clock_mode_changed(app, dd, p):
    selected = dd.get_selected_item()
    if not selected:
        return
    label = selected.get_string()
    app.settings["usb_clock_mode"] = label
    app.save_settings()
    mode_int = _USB_CLOCK_MODE_MAP.get(label, 0)
    if hasattr(app, "player") and hasattr(app.player, "set_usb_clock_mode"):
        app.player.set_usb_clock_mode(mode_int)
    logger.info("USB clock mode changed: %s (%d)", label, mode_int)


def on_driver_changed(app, dd, p):
    driver_change_t0 = time.monotonic()

    def _driver_mark(stage):
        logger.info(
            "STARTUP TIMING driver-change %s +%.1fms",
            str(stage),
            (time.monotonic() - driver_change_t0) * 1000.0,
        )

    if getattr(app, "ignore_driver_change", False):
        return
    app._usb_perm_dialog_shown = False  # reset so prompt can fire for this driver selection
    _stop_output_hotplug_watch(app)
    selected = dd.get_selected_item()
    if not selected:
        return
    driver_name = selected.get_string()
    previous_driver_name = str(
        getattr(app.player, "current_driver", None)
        or getattr(app.player, "requested_driver", None)
        or ""
    )
    _driver_mark(f"begin driver={driver_name}")

    bp_active = bool(getattr(app.player, "bit_perfect_mode", False)) \
        or bool(getattr(app, "settings", {}).get("bit_perfect", False))
    if bp_active and not _driver_is_alsa_family(driver_name) and not _driver_is_usb_rawlink_family(driver_name):
        app._force_driver_selection(DRIVER_ALSA_AUTO)
        if hasattr(app, "show_output_notice"):
            app.show_output_notice(
                f"Bit-Perfect mode requires {DRIVER_ALSA_AUTO}, {DRIVER_ALSA_MMAP}, or {DRIVER_USB_RAWLINK_V2}.",
                "warn",
                3200,
            )
        return

    if not bp_active or _driver_is_alsa_family(driver_name) or _driver_is_usb_rawlink_family(driver_name):
        app.settings["driver"] = driver_name
        app.save_settings()
    _driver_mark("settings-saved")

    # Stop playback and release the current audio path before switching driver,
    # so the device is free when the new driver (e.g. ALSA exclusive) opens it.
    # Skip the stop on first-launch initialization when no output route has been
    # established yet; this avoids a pointless synchronous stop during startup.
    had_active_output = bool(
        getattr(app.player, "current_device_id", None)
        or str(getattr(app.player, "output_state", "idle") or "idle") != "idle"
    )
    if app.player.is_playing():
        app.player.pause()
        app.player.stop()
    elif had_active_output:
        app.player.stop()
    _driver_mark("stop-complete")
    _release_output_before_driver_enumeration(app, previous_driver_name, driver_name)

    app.current_device_name = "Default"
    app.update_tech_label(app.player.stream_info)
    if hasattr(app, "_update_dsp_ui_state"):
        app._update_dsp_ui_state()
    _driver_mark("ui-reset")

    def worker():
        worker_t0 = time.monotonic()
        devices = app.player.get_devices_for_driver(driver_name)
        logger.info(
            "STARTUP TIMING driver-change enum-complete driver=%s +%.1fms",
            driver_name,
            (time.monotonic() - worker_t0) * 1000.0,
        )

        def apply_devices():
            apply_t0 = time.monotonic()
            app.ignore_device_change = True

            app.current_device_list = devices
            app.device_dd.set_model(Gtk.StringList.new([d["name"] for d in devices]))

            saved_dev = app.settings.get("device")
            sel_idx = 0

            if saved_dev:
                for i, d in enumerate(devices):
                    if d["name"] == saved_dev:
                        sel_idx = i
                        break

            # USB Rawlink has no "Default" placeholder — enable with ≥1 device.
            min_count = 1 if _driver_is_usb_rawlink_family(driver_name) else 2
            app.device_dd.set_sensitive(len(devices) >= min_count)
            if hasattr(app, "mmap_realtime_priority_dd"):
                app.mmap_realtime_priority_dd.set_sensitive(driver_name == DRIVER_ALSA_MMAP)
            if hasattr(app, "latency_dd"):
                app.latency_dd.set_sensitive(_driver_is_alsa_family(driver_name))
            if hasattr(app, "usb_clock_mode_dd"):
                app.usb_clock_mode_dd.set_sensitive(_driver_is_usb_rawlink_family(driver_name))

            if sel_idx < len(devices):
                app.device_dd.set_selected(sel_idx)

            device_info = devices[sel_idx] if sel_idx < len(devices) else None
            _sync_output_bit_depth_dropdown(app, device_info)
            app.ignore_device_change = False
            if hasattr(app, "_update_dsp_ui_state"):
                app._update_dsp_ui_state()
            logger.info(
                "STARTUP TIMING driver-change apply-devices driver=%s +%.1fms",
                driver_name,
                (time.monotonic() - apply_t0) * 1000.0,
            )

            target_id = None
            if sel_idx < len(devices):
                target_id = devices[sel_idx]["device_id"]
                app.current_device_name = devices[sel_idx]["name"]
            if hasattr(app, "_update_dsp_ui_state"):
                app._update_dsp_ui_state()

            app.update_tech_label(app.player.stream_info)
            _driver_mark(f"devices-applied target={target_id or 'default'}")

            if _driver_is_usb_rawlink_family(driver_name):
                GLib.idle_add(lambda: _check_and_prompt_usb_permission(app, devices) or False)

            def apply_output_async():
                output_t0 = time.monotonic()
                ok = app.player.set_output(driver_name, target_id)
                logger.info(
                    "STARTUP TIMING driver-change set-output driver=%s target=%s +%.1fms ok=%s",
                    driver_name,
                    target_id or "default",
                    (time.monotonic() - output_t0) * 1000.0,
                    bool(ok),
                )
                if not ok and hasattr(app, "show_output_notice"):
                    app.show_output_notice(
                        f"Failed to switch output to {app.current_device_name or 'selected device'}",
                        "error",
                        3500,
                    )
                if hasattr(app, "_apply_viz_sync_offset_for_device"):
                    app._apply_viz_sync_offset_for_device(
                        driver_name,
                        device_id=target_id,
                        device_name=app.current_device_name,
                    )
                if ok:
                    _schedule_output_refresh_after_usb_release(app, previous_driver_name, driver_name)
                if hasattr(app, "_update_dsp_ui_state"):
                    GLib.idle_add(lambda: (app._update_dsp_ui_state(), False)[1])
                GLib.idle_add(lambda: update_output_status_ui(app) or False)

            Thread(target=apply_output_async, daemon=True).start()
            return False

        GLib.idle_add(apply_devices)

    Thread(target=worker, daemon=True).start()


def _pipewire_device_needs_pro_audio(device_id):
    """Heuristic: True if device_id is not already in/targeting pro-audio mode."""
    dev = str(device_id or "").strip()
    if not dev:
        return False
    if ".pro-output-" in dev:
        return False
    if dev.startswith("pwcardprofile:") and "|pro-audio" in dev:
        return False
    return True


def _normalize_pipewire_device_id(device_id):
    dev = str(device_id or "").strip()
    if not dev.startswith("pwcardprofile:"):
        return device_id
    if "|pro-audio" in dev:
        return device_id
    card_part = dev[len("pwcardprofile:"):]
    card_name = card_part.split("|", 1)[0].strip()
    if not card_name:
        return device_id
    return f"pwcardprofile:{card_name}|pro-audio"


def _show_pro_audio_switch_info(app, on_confirm):
    """Informational dialog: device will be auto-switched to pro-audio. Calls on_confirm after OK."""
    dialog = Gtk.Dialog(title="Pro-Audio Mode", transient_for=app.win, modal=True)
    root = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=12,
        margin_top=16,
        margin_bottom=16,
        margin_start=20,
        margin_end=20,
    )
    msg = Gtk.Label(
        label=(
            "The selected device is not in Pro-Audio mode.\n\n"
            "It will be automatically switched to Pro-Audio to enable adaptive sample rate switching."
        ),
        wrap=True,
        xalign=0.0,
        max_width_chars=48,
    )
    root.append(msg)
    action_row = Gtk.Box(spacing=8, halign=Gtk.Align.END)
    ok_btn = Gtk.Button(label="OK", css_classes=["suggested-action"])
    ok_btn.connect("clicked", lambda _b: dialog.response(Gtk.ResponseType.OK))
    action_row.append(ok_btn)
    root.append(action_row)
    dialog.set_child(root)

    def _on_response(d, _resp):
        d.destroy()
        on_confirm()

    dialog.connect("response", _on_response)
    dialog.present()


def on_device_changed(app, dd, p):
    if app.ignore_device_change:
        return
    _stop_output_hotplug_watch(app)
    idx = dd.get_selected()
    if not (hasattr(app, "current_device_list") and idx < len(app.current_device_list)):
        return
    device_info = app.current_device_list[idx]
    previous_name = str(getattr(app, "current_device_name", "") or "")
    previous_saved = str(app.settings.get("device", "") or "")
    previous_idx = None
    for i, info in enumerate(list(getattr(app, "current_device_list", []) or [])):
        if str(info.get("name", "") or "") == previous_name:
            previous_idx = i
            break
    remembered_name = str(getattr(app, "_last_disconnected_device_name", "") or "")
    target_name = device_info["name"]
    driver_label = app.driver_dd.get_selected_item().get_string()
    _sync_output_bit_depth_dropdown(app, device_info)

    def _do_switch():
        original_device_id = device_info["device_id"]
        target_device_id = original_device_id
        if driver_label == "PipeWire":
            target_device_id = _normalize_pipewire_device_id(target_device_id)
        ok = app.player.set_output(driver_label, target_device_id)
        if not ok:
            if previous_idx is not None and previous_idx != idx:
                app.ignore_device_change = True
                try:
                    dd.set_selected(previous_idx)
                finally:
                    app.ignore_device_change = False
            if previous_saved:
                app.settings["device"] = previous_saved
            app.current_device_name = previous_name or getattr(app, "current_device_name", "Default")
            app.update_tech_label(app.player.stream_info)
            if hasattr(app, "show_output_notice"):
                app.show_output_notice(
                    f"Output device unavailable: {target_name}",
                    "error",
                    4200,
                )
            if hasattr(app, "_update_dsp_ui_state"):
                app._update_dsp_ui_state()
            update_output_status_ui(app)
            return
        if remembered_name and target_name == remembered_name:
            app._last_disconnected_device_name = ""
            app._last_disconnected_driver = ""
        app.current_device_name = target_name
        app.update_tech_label(app.player.stream_info)
        app.settings["device"] = target_name
        app.save_settings()
        if hasattr(app, "_update_dsp_ui_state"):
            app._update_dsp_ui_state()
        if hasattr(app, "_apply_viz_sync_offset_for_device"):
            app._apply_viz_sync_offset_for_device(driver_label, device_id=target_device_id, device_name=target_name)
        if driver_label == "PipeWire" and target_device_id != original_device_id:
            new_id = str(getattr(app.player, "requested_device_id", "") or target_device_id or "")
            _refresh_devices_for_current_driver_ui_only(
                app,
                reason="pipewire-target-normalized",
                prefer_device_id=new_id or None,
            )
        update_output_status_ui(app)

    if (driver_label == "PipeWire"
            and bool(getattr(app.player, "active_rate_switch", False))
            and _pipewire_device_needs_pro_audio(device_info.get("device_id"))):
        def _do_switch_and_refresh():
            _do_switch()
            new_id = str(getattr(app.player, "requested_device_id", "") or "")
            _refresh_devices_for_current_driver_ui_only(
                app, reason="pro-audio-switch", prefer_device_id=new_id or None
            )
        _show_pro_audio_switch_info(app, _do_switch_and_refresh)
    else:
        _do_switch()


def on_output_bit_depth_changed(app, dd, p):
    if getattr(app, "ignore_output_bit_depth_change", False):
        return
    selected = dd.get_selected_item()
    label = selected.get_string() if selected is not None else "Auto"
    app.settings["output_bit_depth"] = str(label or "Auto")
    app.save_settings()
    device_info = _current_selected_device_info(app)
    _apply_output_bit_depth_preference(app, device_info)
    app.update_tech_label(app.player.stream_info)

    drv_item = app.driver_dd.get_selected_item() if getattr(app, "driver_dd", None) is not None else None
    if drv_item is None:
        update_output_status_ui(app)
        return
    driver_label = drv_item.get_string()
    device_id = device_info.get("device_id") if isinstance(device_info, dict) else None
    ok = app.player.set_output(driver_label, device_id)
    if not ok and hasattr(app, "show_output_notice"):
        app.show_output_notice(
            f"Failed to apply {label or 'Auto'} output depth",
            "error",
            3600,
        )
    elif ok and hasattr(app, "_apply_viz_sync_offset_for_device"):
        app._apply_viz_sync_offset_for_device(
            driver_label,
            device_id=device_id,
            device_name=(device_info or {}).get("name"),
        )
    update_output_status_ui(app)


def on_output_state_transition(self, prev_state, state, detail=None):
    player = getattr(self, "player", None)
    if state == "switching":
        self.show_output_notice("Audio device changed, reconnecting...", "switching", 2400)
        return
    if state == "active" and prev_state in ("switching", "fallback", "error"):
        self.show_output_notice("Audio output reconnected", "ok", 2200)
        # USB Rawlink: the USB sink was rebuilt by set_output but the native
        # transport was stopped during the disconnect.  Resume automatically if
        # a track was loaded and the player is not already playing.
        if _driver_is_usb_rawlink_family(getattr(player, "requested_driver", "")):
            uri = str(getattr(player, "_last_loaded_uri", "") or "")
            if uri and not player.is_playing():
                pos_s = float(getattr(player, "_cached_pos_s", 0.0) or 0.0)
                logger.info(
                    "USB Rawlink reconnected; auto-resuming playback pos=%.1fs uri=%.60s",
                    pos_s, uri,
                )
                def _usb_resume():
                    try:
                        # Re-issue load() so Rust's engine.uri is (re-)populated.
                        # rac_set_uri clears engine.uri on a dead-pusher error, and
                        # set_output_tuned rebuilds the sink without restoring it, so a
                        # bare play() call would hit "rac_play: empty uri" (-2).
                        player.load(uri)
                        player.play()
                        if pos_s > 0.5:
                            def _restore_position():
                                player.seek(pos_s)
                                if hasattr(self, "_mpris_emit_seeked"):
                                    self._mpris_emit_seeked(pos_s)
                                return False

                            GLib.timeout_add(500, _restore_position)
                        if self.play_btn is not None:
                            self.play_btn.set_icon_name("media-playback-pause-symbolic")
                        update_output_status_ui(self)
                    except Exception:
                        logger.debug("USB Rawlink auto-resume failed", exc_info=True)
                    return False
                GLib.timeout_add(200, _usb_resume)
        return
    if state == "fallback":
        if self.play_btn is not None:
            self.play_btn.set_icon_name("media-playback-start-symbolic")
        detail_text = str(detail or "")
        if "disconnected" in detail_text.lower():
            # Remember the device that was active when disconnect happened, so
            # hotplug logic can detect "same device came back" and optionally
            # auto-rebind once.
            try:
                drv_item = self.driver_dd.get_selected_item() if self.driver_dd is not None else None
                dev_item = self.device_dd.get_selected_item() if self.device_dd is not None else None
                if drv_item is not None:
                    self._last_disconnected_driver = drv_item.get_string()
                if dev_item is not None:
                    self._last_disconnected_device_name = dev_item.get_string()
            except Exception:
                pass
            self.show_output_notice("USB audio device disconnected, rebinding to first available output", "warn", 3600)
            # Keep selected driver unchanged; refresh devices and bind to first available.
            try:
                refresh_devices_keep_driver_select_first(self, reason="usb-disconnect")
                start_output_hotplug_watch(
                    self,
                    seconds=60,
                    interval_ms=1000,
                    slow_interval_ms=5000,
                )
            except Exception:
                pass
        else:
            self.show_output_notice("Primary output unavailable, switched to fallback", "warn", 3200)
        return
    if state == "error":
        if self.play_btn is not None:
            self.play_btn.set_icon_name("media-playback-start-symbolic")
        msg = str(detail or "Unknown output error")
        self.show_output_notice(f"Output error: {msg}", "error", 3600)


def _get_output_status_interval_ms(self):
    try:
        is_settings = bool(
            getattr(self, "right_stack", None) is not None
            and self.right_stack.get_visible_child_name() == "settings"
        )
    except Exception:
        is_settings = False
    if is_settings:
        return 1000
    state = str(getattr(self.player, "output_state", "idle") or "idle")
    if state in ("fallback", "error", "switching"):
        return 1200
    try:
        is_playing = bool(self.player.is_playing())
    except Exception:
        is_playing = False
    return 2500 if is_playing else 6000


def _schedule_output_status_loop(self, delay_ms=None):
    source = getattr(self, "_output_status_source", 0)
    if source:
        try:
            GLib.source_remove(source)
        except Exception:
            pass
        self._output_status_source = 0
    next_delay = int(delay_ms if delay_ms is not None else self._get_output_status_interval_ms())

    def _tick():
        self._output_status_source = 0
        try:
            self._refresh_output_status_loop()
        except Exception:
            logger.exception("Output status loop tick failed")
        self._schedule_output_status_loop()
        return False

    self._output_status_source = GLib.timeout_add(max(250, next_delay), _tick)


def _force_driver_selection(self, keyword):
    model = self.driver_dd.get_model()
    for i in range(model.get_n_items()):
        if keyword in model.get_item(i).get_string(): self.driver_dd.set_selected(i); break


def update_tech_label(self, info):
    fmt = str(info.get('fmt_str', '') or '')
    fmt_norm = " ".join(fmt.replace("\\", " ").split())
    codec = info.get('codec', '-')
    if (not fmt_norm) and (not codec or codec in ["-", "Loading..."]):
        self.lbl_tech.set_text("")
        self.lbl_tech.set_tooltip_text(None)
        self.lbl_tech.remove_css_class("tech-label")
        for cls in ("tech-state-ok", "tech-state-mixed", "tech-state-warn"):
            self.lbl_tech.remove_css_class(cls)
        self.lbl_tech.set_visible(True)
        # Track changed — reset bitrate stability tracking state.
        self._bitrate_pending = 0
        self._bitrate_shown = 0
        return

    display_codec = codec if codec and codec not in ["-", "Loading..."] else "PCM"
    if isinstance(display_codec, str):
        codec_low = display_codec.lower()
        if "flac" in codec_low:
            display_codec = "FLAC"
        elif "aac" in codec_low:
            display_codec = "AAC"
        elif "alac" in codec_low:
            display_codec = "ALAC"
        else:
            display_codec = display_codec.replace("\\", " ").strip()

    # Prefer explicit numeric fields; fmt_str can be missing or escaped.
    def _pick_int(*keys):
        for k in keys:
            try:
                v = int(info.get(k, 0) or 0)
            except Exception:
                v = 0
            if v > 0:
                return v
        return 0

    src_rate = _pick_int("source_rate", "rate", "output_rate")
    src_depth = _pick_int("source_depth", "depth", "output_depth")

    if src_rate > 0 and src_depth > 0:
        rate_depth = f"{src_depth}-bit/{(src_rate / 1000.0):g}kHz"
    else:
        rate_depth = fmt_norm
        if "|" in fmt_norm:
            parts = [p.strip() for p in fmt_norm.split("|")]
            if len(parts) >= 2:
                rate = parts[0]
                depth = parts[1].replace("bit", "-bit")
                rate_depth = f"{depth}/{rate}"
        if not rate_depth:
            rate_depth = "-"

    bitrate = int(info.get("bitrate", 0) or 0)
    if bitrate > 0:
        # The bitrate estimate for lossless streams (FLAC) starts very low and
        # converges upward over several TAG events.  Only display the value
        # once two consecutive TAG events agree within ±40%, which means the
        # estimate has stabilised.  Until then keep the last stable value
        # (or show nothing if this is the very first track).
        pending = int(getattr(self, "_bitrate_pending", 0) or 0)
        shown   = int(getattr(self, "_bitrate_shown",   0) or 0)
        self._bitrate_pending = bitrate
        if pending > 0 and 0.6 <= bitrate / pending <= 1.67:
            # Two consecutive similar readings → stable; update display.
            self._bitrate_shown = bitrate
            shown = bitrate
        # If not yet stable: keep the previously confirmed value (or nothing).
        if shown > 0:
            kbps = max(1, int(round(shown / 1000.0)))
            bitrate_text = f" • {kbps}kbps"
        else:
            bitrate_text = ""
    else:
        self._bitrate_pending = 0
        self._bitrate_shown = 0
        bitrate_text = ""

    is_bp = bool(getattr(self.player, "bit_perfect_mode", False))
    is_ex = bool(getattr(self.player, "exclusive_lock_mode", False))
    output_state = str(getattr(self.player, "output_state", "idle"))

    mode_tag = "BP" if is_bp else "MIX"
    lock_tag = "EX" if is_ex else "SHR"
    self.lbl_tech.add_css_class("tech-label")
    self.lbl_tech.set_text(f"{mode_tag}/{lock_tag} • {rate_depth} • {display_codec}{bitrate_text}")

    # Full detail remains available on hover.
    dev_name = getattr(self, "current_device_name", "Default")
    self.lbl_tech.set_tooltip_text(
        f"{display_codec} | {rate_depth} | {bitrate//1000}kbps | {dev_name} | output={output_state}"
    )

    for cls in ("tech-state-ok", "tech-state-mixed", "tech-state-warn"):
        self.lbl_tech.remove_css_class(cls)
    if output_state in ("fallback", "error"):
        self.lbl_tech.add_css_class("tech-state-warn")
    elif is_bp:
        self.lbl_tech.add_css_class("tech-state-ok")
    else:
        self.lbl_tech.add_css_class("tech-state-mixed")

    self.lbl_tech.set_visible(True)


def on_bit_perfect_toggled(self, switch, state):
    self.settings["bit_perfect"] = state; self.save_settings()
    logger.info(
        "Bit-perfect toggle request state=%s current_dsp_enabled=%s",
        bool(state),
        bool(getattr(getattr(self, "player", None), "dsp_enabled", False)),
    )
    if state and bool(getattr(getattr(self, "player", None), "dsp_enabled", False)):
        try:
            dsp_disabled = bool(self.player.set_dsp_enabled(False))
        except Exception:
            dsp_disabled = False
        if dsp_disabled:
            self.settings["dsp_enabled"] = False
            self.save_settings()
        if dsp_disabled and hasattr(self, "show_output_notice"):
            self.show_output_notice("DSP disabled: Bit-Perfect mode enabled", "info", 2600)
    # Bit-Perfect now implies hardware exclusive: the two flags move
    # together so the legacy `Force Hardware Exclusive` switch can stay
    # removed without losing the D-Bus reservation / driver-filter
    # behavior the old switch provided.
    is_ex = bool(state)
    self.settings["exclusive_lock"] = is_ex
    self.save_settings()
    if state:
        # Hardware volume (e.g. USB Rawlink v2) doesn't touch PCM data,
        # so volume controls stay unlocked in bit-perfect mode.
        hw_vol = (
            hasattr(self, "player") and self.player is not None
            and hasattr(self.player, "usb_hw_volume_supported")
            and self.player.usb_hw_volume_supported()
        )
        if not hw_vol:
            self._lock_volume_controls(True)
        self.player.toggle_bit_perfect(True, exclusive_lock=is_ex)
    else:
        self.player.toggle_bit_perfect(False, exclusive_lock=is_ex)
        self._lock_volume_controls(False)
    logger.info(
        "Bit-perfect toggle applied state=%s player_dsp_enabled=%s player_bit_perfect=%s",
        bool(state),
        bool(getattr(getattr(self, "player", None), "dsp_enabled", False)),
        bool(getattr(getattr(self, "player", None), "bit_perfect_mode", False)),
    )
    for btn in (
        getattr(self, "eq_btn", None),
        getattr(self, "dsp_btn", None),
        getattr(self, "now_playing_dsp_btn", None),
    ):
        if btn is not None:
            btn.set_sensitive(not state)
    if state and getattr(self, "eq_pop", None) is not None:
        self.eq_pop.popdown()
    if hasattr(self, "_update_dsp_ui_state"):
        self._update_dsp_ui_state()
    elif hasattr(self, "_sync_playback_status_icon"):
        self._sync_playback_status_icon()
    if self.bp_label is not None: self.bp_label.set_visible(state)
    if is_ex:
        prev_driver = _selected_driver_name(self)
        _refresh_driver_dropdown_options(
            self,
            preferred_driver=prev_driver,
            exclusive_enabled=True,
        )
        self.on_driver_changed(self.driver_dd, None)
    else:
        _refresh_driver_dropdown_options(
            self,
            preferred_driver=_selected_driver_name(self),
            exclusive_enabled=False,
        )
        self.driver_dd.set_sensitive(True)
        drv_item = self.driver_dd.get_selected_item() if self.driver_dd is not None else None
        drv_name = drv_item.get_string() if drv_item is not None else ""
        if state and drv_name == "PipeWire" and hasattr(self.player, "ensure_pipewire_pro_audio"):
            def _switch_to_pro_audio():
                ok = False
                try:
                    ok = bool(self.player.ensure_pipewire_pro_audio())
                except Exception:
                    ok = False

                def _apply_ui():
                    try:
                        _refresh_devices_for_current_driver_ui_only(
                            self, reason="bit-perfect-pro-audio"
                        )
                    except Exception:
                        pass
                    if ok:
                        self.show_output_notice("Bit-perfect enabled: switched card profile to pro-audio.", "ok", 2800)
                    else:
                        self.show_output_notice(
                            "Bit-perfect enabled, but pro-audio switch failed. You can still choose device manually.",
                            "warn",
                            3800,
                        )
                    return False

                GLib.idle_add(_apply_ui)

            submit_daemon(_switch_to_pro_audio)


def on_auto_rebind_once_toggled(self, switch, state):
    self.settings["output_auto_rebind_once"] = bool(state)
    self.save_settings()

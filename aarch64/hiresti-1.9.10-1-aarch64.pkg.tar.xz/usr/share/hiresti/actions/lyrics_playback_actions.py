from threading import Thread
import logging
import os
import time

from gi.repository import Gtk, GLib, Gdk
from app.app_ui_loop import _is_now_playing_overlay_open, _ui_loop_has_high_frequency_consumer
from core.errors import classify_exception, user_message
from actions import audio_settings_actions
from models.playlist_queue import PlaylistQueueTrack

logger = logging.getLogger(__name__)
MAX_PREFETCH_CACHE = 6
# Cap the Previous back-stack so a long shuffle session can't grow it without
# bound; older entries fall off the front.
_MAX_PLAY_HISTORY = 500
# Tidal CDN stream URLs are pre-signed and expire; 20 min is a safe margin.
PREFETCH_URL_TTL_SECONDS = 20 * 60
NO_LYRICS_BOTTOM_HINT = "No usable lyrics for this track."


def _attach_lyric_seek_gesture(row, app, time_point):
    """Make a synced lyric row clickable: click → player.seek(time_point)."""
    gesture = Gtk.GestureClick.new()
    gesture.set_button(1)

    def _on_released(_g, n_press, _x, _y):
        if n_press != 1:
            return
        try:
            app.player.seek(float(time_point))
        except Exception:
            logger.exception("lyric seek failed")
            return
        if hasattr(app, "_mpris_emit_seeked"):
            app._mpris_emit_seeked(float(time_point))

    gesture.connect("released", _on_released)
    row.add_controller(gesture)
    row.add_css_class("lyric-row-clickable")
    try:
        row.set_cursor(Gdk.Cursor.new_from_name("pointer", None))
    except Exception:
        pass


def _apply_track_redirect(app, original_track):
    """If get_stream_url used an album fallback, update liked_tracks_data and fav_track_ids.

    Called from a daemon thread immediately after get_stream_url returns.
    """
    redirect = getattr(app.backend, "_last_track_redirect", None)
    if not redirect:
        return
    app.backend._last_track_redirect = None
    old_id_str, alt_track = redirect
    if str(getattr(original_track, "id", "") or "") != old_id_str:
        return
    new_id_str = str(getattr(alt_track, "id", "") or "")
    if not new_id_str:
        return

    try:
        app.backend.fav_track_ids.discard(old_id_str)
        app.backend.fav_track_ids.add(new_id_str)
    except Exception:
        pass

    def _update_liked_cache():
        cached = list(getattr(app, "liked_tracks_data", []) or [])
        updated = [alt_track if str(getattr(t, "id", "") or "") == old_id_str else t for t in cached]
        if updated != cached:
            app.liked_tracks_data = updated
            logger.info("Liked cache redirect: %s → %s (%r)", old_id_str, new_id_str, getattr(alt_track, "name", ""))
        return False

    GLib.idle_add(_update_liked_cache)


def _split_bilingual_line(text):
    if not text:
        return "", ""

    line = str(text).strip()
    if not line:
        return "", ""

    # Conservative separators to avoid over-splitting normal lyrics.
    for sep in (" / ", " | ", " ｜ ", " // "):
        if sep in line:
            left, right = line.split(sep, 1)
            left = left.strip()
            right = right.strip()
            if left and right:
                return left, right
    return line, ""


def _karaoke_markup(words, active_idx, active_color="#FFFFFF", inactive_color="#AEB8C8"):
    chunks = []
    for i, (_, token) in enumerate(words):
        txt = GLib.markup_escape_text(token)
        if i <= active_idx:
            chunks.append(f'<span foreground="{active_color}" weight="700">{txt}</span>')
        else:
            chunks.append(f'<span foreground="{inactive_color}">{txt}</span>')
    return "".join(chunks)


def _karaoke_active_idx(words, current_time):
    idx = -1
    for i, (t, _token) in enumerate(words):
        if t <= current_time:
            idx = i
        else:
            break
    return idx


def _prefetch_next_track(app, current_index):
    try:
        next_idx = app.get_next_index(direction=1)
        if next_idx < 0 or next_idx == current_index:
            return
        queue = app._get_active_queue() if hasattr(app, "_get_active_queue") else list(getattr(app, "current_track_list", []) or [])
        if next_idx >= len(queue):
            return

        next_track = queue[next_idx]
        if isinstance(next_track, PlaylistQueueTrack):
            next_track = next_track.resolve()
            if hasattr(app, "_refresh_queue_views"):
                GLib.idle_add(app._refresh_queue_views)
        track_id = getattr(next_track, "id", None)
        if track_id is None:
            return

        quality_key = str(getattr(app.backend, "quality", "unknown"))
        cache = getattr(app, "stream_prefetch_cache", {})
        cached = cache.get(track_id)
        if cached and cached.get("quality") == quality_key and cached.get("url"):
            return

        prefetch_url = app.backend.get_stream_url(next_track)
        _apply_track_redirect(app, next_track)
        if not prefetch_url:
            return

        meta = {
            "name": getattr(next_track, "name", ""),
            "artist": getattr(getattr(next_track, "artist", None), "name", ""),
            "album": getattr(getattr(next_track, "album", None), "name", ""),
            "artwork_url": app.backend.get_artwork_url(next_track, 320),
        }

        cache[track_id] = {
            "url": prefetch_url,
            "quality": quality_key,
            "meta": meta,
            "bit_depth": getattr(app.backend, "_last_stream_bit_depth", 0),
            "sample_rate": getattr(app.backend, "_last_stream_sample_rate", 0),
            "fetched_at": time.monotonic(),
        }
        if len(cache) > MAX_PREFETCH_CACHE:
            oldest_key = next(iter(cache))
            cache.pop(oldest_key, None)
        app.stream_prefetch_cache = cache
        logger.debug("Prefetched next track url: %s", track_id)
    except Exception as e:
        logger.debug("Next-track prefetch failed: %s", e)


def _cache_current_track_audio(app, track_id, quality_key, stream_url):
    try:
        max_tracks = int(getattr(app, "audio_cache_tracks", 0) or 0)
        if max_tracks <= 0:
            return
        cache_dir = getattr(app, "audio_cache_dir", "")
        if not cache_dir:
            return
        local_path = utils.cache_audio_from_url(cache_dir, track_id, quality_key, stream_url)
        if local_path:
            utils.prune_audio_cache(cache_dir, max_tracks=max_tracks)
    except Exception as e:
        logger.debug("Audio cache store failed: %s", e)


def render_lyrics_list(app, lyrics_obj=None, status_msg=None):
    logger.debug("Rendering lyrics. status=%s", status_msg)

    if not hasattr(app, "lyrics_vbox"):
        return

    if hasattr(app, "_render_now_playing_lyrics"):
        try:
            app._render_now_playing_lyrics(lyrics_obj, status_msg)
        except Exception as e:
            logger.debug("Now playing lyrics mirror render failed: %s", e)

    while child := app.lyrics_vbox.get_first_child():
        app.lyrics_vbox.remove(child)
    app.lyric_widgets = []
    app.current_lyric_index = -1

    if status_msg:
        if status_msg == NO_LYRICS_BOTTOM_HINT:
            spacer = Gtk.Box(vexpand=True)
            app.lyrics_vbox.append(spacer)
            bottom = Gtk.Label(label=status_msg, css_classes=["dim-label"], halign=Gtk.Align.CENTER)
            bottom.set_margin_bottom(20)
            app.lyrics_vbox.append(bottom)
            return

        lbl = Gtk.Label(label=status_msg, css_classes=["title-2"], valign=Gtk.Align.CENTER)
        lbl.set_opacity(0.5)
        center = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER, vexpand=True)
        center.append(lbl)
        app.lyrics_vbox.append(center)
        return

    # Keep a clean blank state with a small bottom breathing margin.
    if not lyrics_obj:
        spacer = Gtk.Box(vexpand=True)
        spacer.set_margin_bottom(20)
        app.lyrics_vbox.append(spacer)
        return

    if lyrics_obj:
        source = lyrics_obj.time_points if lyrics_obj.has_synced else [0]
        logger.debug("Drawing %s lyric lines", len(source))

        for t in source:
            text = lyrics_obj.lyrics_map.get(t, "") if lyrics_obj.has_synced else lyrics_obj.raw_text
            if not text:
                text = " "

            karaoke_words = []
            if lyrics_obj.has_synced and hasattr(lyrics_obj, "karaoke_map"):
                karaoke_words = list(lyrics_obj.karaoke_map.get(t, []))

            # Karaoke line: keep as a single main line and update words progressively.
            if karaoke_words:
                row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, css_classes=["lyric-row"])
                row.set_halign(Gtk.Align.CENTER)
                main_lbl = Gtk.Label(css_classes=["lyric-line"], wrap=True, max_width_chars=40)
                main_lbl.set_justify(Gtk.Justification.CENTER)
                main_lbl.set_use_markup(True)
                main_lbl.set_markup(_karaoke_markup(karaoke_words, -1))
                row.append(main_lbl)
                if lyrics_obj.has_synced:
                    _attach_lyric_seek_gesture(row, app, t)
                app.lyrics_vbox.append(row)

                if lyrics_obj.has_synced:
                    app.lyric_widgets.append(
                        {
                            "time": t,
                            "widget": row,
                            "main": main_lbl,
                            "sub": None,
                            "karaoke_words": karaoke_words,
                            "karaoke_last_idx": -2,
                        }
                    )
                continue

            primary, secondary = _split_bilingual_line(text)
            if not primary:
                primary = " "

            row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, css_classes=["lyric-row"])
            row.set_halign(Gtk.Align.CENTER)

            main_lbl = Gtk.Label(label=primary, css_classes=["lyric-line"], wrap=True, max_width_chars=40)
            main_lbl.set_justify(Gtk.Justification.CENTER)
            row.append(main_lbl)

            sub_lbl = None
            if secondary:
                sub_lbl = Gtk.Label(
                    label=secondary,
                    css_classes=["lyric-sub-line"],
                    wrap=True,
                    max_width_chars=42,
                )
                sub_lbl.set_justify(Gtk.Justification.CENTER)
                row.append(sub_lbl)

            if lyrics_obj.has_synced:
                _attach_lyric_seek_gesture(row, app, t)
            app.lyrics_vbox.append(row)

            if lyrics_obj.has_synced:
                app.lyric_widgets.append(
                    {
                        "time": t,
                        "widget": row,
                        "main": main_lbl,
                        "sub": sub_lbl,
                        "karaoke_words": [],
                        "karaoke_last_idx": -2,
                    }
                )

    if hasattr(app, "_apply_lyrics_font_layout"):
        try:
            app._apply_lyrics_font_layout()
        except Exception as e:
            logger.debug("Lyrics font layout apply failed: %s", e)


def play_track(app, index, from_history=False):
    logger.info("play_track called. index=%s", index)

    queue = app._get_active_queue() if hasattr(app, "_get_active_queue") else list(getattr(app, "current_track_list", []) or [])
    if not queue:
        return
    if index < 0 or index >= len(queue):
        return

    app._play_request_id = getattr(app, "_play_request_id", 0) + 1
    request_id = app._play_request_id
    track = queue[index]
    if isinstance(track, PlaylistQueueTrack):
        if track.resolved_track is None:
            from actions.playlist_playback import resolve_for_playback
            resolve_for_playback(app, track, index, request_id, from_history=from_history)
            return
        track = track.resolved_track
    # Record the track we're leaving so Previous can return to the track
    # actually heard, not a positional neighbour — this is what makes
    # "back" correct under shuffle, where play order != queue order. A
    # Previous navigation (from_history) must not re-push its own step.
    prev_index = getattr(app, "current_track_index", None)
    if not from_history and isinstance(prev_index, int) and 0 <= prev_index != index:
        history = getattr(app, "_play_history", None)
        if history is None:
            history = app._play_history = []
        history.append(prev_index)
        if len(history) > _MAX_PLAY_HISTORY:
            del history[:-_MAX_PLAY_HISTORY]
    app.current_track_index = index
    app.playing_track = track
    app.playing_track_id = track.id
    if hasattr(app, "_mpris_sync_metadata"):
        app._mpris_sync_metadata()
    if hasattr(app, "_mpris_sync_playback"):
        app._mpris_sync_playback()
    if hasattr(app, "refresh_dashboard_playing_state"):
        GLib.idle_add(lambda: (app.refresh_dashboard_playing_state(), False)[1])
    if hasattr(app, "refresh_current_track_favorite_state"):
        GLib.idle_add(app.refresh_current_track_favorite_state)
    if hasattr(app, "_remote_publish_track_event"):
        app._remote_publish_track_event("track_selected")

    logger.info("Playing: %s", track.name)

    if hasattr(app, "scrobbler"):
        app.scrobbler.on_track_started(track)

    try:
        title = getattr(track, "name", "Unknown Track")
        artist = getattr(track.artist, "name", "Unknown Artist")
        album = getattr(track.album, "name", "Unknown Album")
        app.lbl_title.set_label(title)
        app.lbl_artist._inner_label.set_label(artist)
        app.lbl_album._inner_label.set_label(album)
        app.lbl_title.set_tooltip_text(title)
        app.lbl_artist.set_tooltip_text(artist)
        app.lbl_album.set_tooltip_text(album)
    except Exception:
        fallback = getattr(track, "title", "Loading...")
        app.lbl_title.set_label(fallback)
        app.lbl_title.set_tooltip_text(fallback)

    GLib.idle_add(lambda: app._update_list_ui(index))
    GLib.idle_add(lambda: app._update_track_list_icon())
    if hasattr(app, "render_queue_drawer"):
        GLib.idle_add(app.render_queue_drawer)
    if hasattr(app, "_refresh_now_playing_from_track"):
        GLib.idle_add(lambda: (app._refresh_now_playing_from_track(), False)[1])

    cover_id = getattr(track, "cover", None) or getattr(track.album, "cover", None)
    cover_url = app._get_tidal_image_url(cover_id) if cover_id else None
    if hasattr(app, "bg_viz"):
        if cover_url:
            app.bg_viz.set_colors_from_cover(cover_url, app.cache_dir)
        else:
            app.bg_viz.randomize_colors()
    if hasattr(app, "_refresh_visualizer_cover_theme"):
        app._refresh_visualizer_cover_theme()

    if cover_id:
        Thread(target=lambda: app._load_cover_art(cover_id), daemon=True).start()
        if hasattr(app, "history_mgr"):
            app.history_mgr.add(track, cover_id)

    Thread(target=lambda: _prefetch_next_track(app, index), daemon=True).start()

    def task():
        logger.debug("Playback background task started")

        try:
            quality_key = str(getattr(app.backend, "quality", "unknown"))
            cache = getattr(app, "stream_prefetch_cache", {})
            cached = cache.get(track.id)
            url = None
            max_tracks = int(getattr(app, "audio_cache_tracks", 0) or 0)
            bit_depth = 0
            sample_rate = 0
            url_age = time.monotonic() - float(cached.get("fetched_at", 0) or 0) if cached else 0
            if (cached and cached.get("quality") == quality_key and cached.get("url")
                    and url_age < PREFETCH_URL_TTL_SECONDS):
                url = cached.get("url")
                bit_depth = int(cached.get("bit_depth", 0) or 0)
                sample_rate = int(cached.get("sample_rate", 0) or 0)
                cache.pop(track.id, None)
                logger.debug("Using prefetched stream url for track: %s (age %.0fs)", track.id, url_age)
            else:
                url = app.backend.get_stream_url(track)
                _apply_track_redirect(app, track)
                bit_depth = int(getattr(app.backend, "_last_stream_bit_depth", 0) or 0)
                sample_rate = int(getattr(app.backend, "_last_stream_sample_rate", 0) or 0)

            local_override = os.environ.get("HIRESTI_LOCAL_URI", "").strip()
            if local_override:
                if not local_override.startswith("file://"):
                    local_override = "file://" + os.path.abspath(os.path.expanduser(local_override))
                logger.warning("HIRESTI_LOCAL_URI override: %s", local_override)
                url = local_override
                bit_depth = 0
                sample_rate = 0

            if url and max_tracks > 0 and str(url).startswith("http"):
                Thread(
                    target=_cache_current_track_audio,
                    args=(app, track.id, quality_key, url),
                    daemon=True,
                ).start()
            if url:
                logger.debug("Stream URL resolved. Loading player")
                if hasattr(app, "set_diag_health"):
                    app.set_diag_health("network", "ok")
                    app.set_diag_health("decoder", "ok")

                # Drive load/play directly from the bg thread — these are Rust
                # FFI calls that don't need the GTK main loop. Going via
                # GLib.idle_add can stall behind heavier UI work
                # (render_queue_drawer / _refresh_now_playing_from_track) that
                # was scheduled earlier in this function, adding 100-300ms of
                # latency between click and audio.
                if request_id != getattr(app, "_play_request_id", 0):
                    return
                app._stream_missing_skip_count = 0
                prev_state = str(getattr(app.player, "output_state", "idle") or "idle")
                if hasattr(app.player, "hint_source_format") and (bit_depth or sample_rate):
                    app.player.hint_source_format(bit_depth, sample_rate)
                app.player.load(url)
                app.player.play()
                cur_state = str(getattr(app.player, "output_state", "idle") or "idle")
                cur_err = str(getattr(app.player, "output_error", "") or "").strip()
                blocked = bool(getattr(app.player, "_pipewire_rate_blocked", False))

                def apply_playback_ui():
                    if request_id != getattr(app, "_play_request_id", 0):
                        return False
                    audio_settings_actions.update_output_status_ui(app)
                    if blocked or cur_state == "error":
                        if app.play_btn is not None:
                            app.play_btn.set_icon_name("media-playback-start-symbolic")
                        msg = cur_err or "Audio output error."
                        if hasattr(app, "show_output_notice"):
                            app.show_output_notice(f"Output error: {msg}", "error", 4200)
                        if blocked and hasattr(app, "_show_simple_dialog"):
                            app._show_simple_dialog("Playback blocked", msg)
                        logger.warning(
                            "Playback blocked after load/play: prev_state=%s state=%s err=%s",
                            prev_state,
                            cur_state,
                            msg,
                        )
                        if hasattr(app, "_mpris_sync_playback"):
                            app._mpris_sync_playback()
                        if hasattr(app, "_mpris_sync_position"):
                            app._mpris_sync_position(force=True)
                        if hasattr(app, "_remote_publish_playback_event"):
                            app._remote_publish_playback_event("playback_error")
                        return False
                    app.play_btn.set_icon_name("media-playback-pause-symbolic")
                    if hasattr(app, "_mpris_sync_playback"):
                        app._mpris_sync_playback()
                    if hasattr(app, "_mpris_sync_position"):
                        app._mpris_sync_position(force=True)
                    if hasattr(app, "_remote_publish_playback_event"):
                        app._remote_publish_playback_event("track_started")
                    return False

                GLib.idle_add(apply_playback_ui)
            else:
                logger.warning("Stream URL is None")

                def apply_stream_missing():
                    if request_id != getattr(app, "_play_request_id", 0):
                        return False
                    app.render_lyrics_list(None, user_message("not_found", "playback"))
                    if hasattr(app, "_mpris_sync_playback"):
                        app._mpris_sync_playback()
                    if hasattr(app, "_remote_publish_playback_event"):
                        app._remote_publish_playback_event("stream_missing")
                    # Auto-skip unavailable tracks, but limit consecutive skips to
                    # avoid an infinite loop when many tracks in a row are missing.
                    skip_count = getattr(app, "_stream_missing_skip_count", 0) + 1
                    app._stream_missing_skip_count = skip_count
                    if skip_count <= 10 and hasattr(app, "on_next_track"):
                        logger.warning("Auto-skipping unavailable track (skip #%d)", skip_count)
                        app.on_next_track()
                    else:
                        if skip_count > 10:
                            logger.warning("Stopped auto-skip after %d consecutive unavailable tracks", skip_count)
                        app._stream_missing_skip_count = 0
                    return False

                GLib.idle_add(apply_stream_missing)
        except Exception as e:
            kind = classify_exception(e)
            logger.warning("Playback error [%s]: %s", kind, e)
            if hasattr(app, "record_diag_event"):
                app.record_diag_event(f"Playback error [{kind}]: {e}")
            if hasattr(app, "set_diag_health"):
                if kind in ("network", "server", "auth"):
                    app.set_diag_health("network", "error", kind)
                elif kind in ("parse", "not_found", "unknown"):
                    app.set_diag_health("decoder", "warn", kind)
                else:
                    app.set_diag_health("decoder", "warn", kind)

            def apply_playback_error():
                if request_id != getattr(app, "_play_request_id", 0):
                    return False
                app.render_lyrics_list(None, user_message(kind, "playback"))
                if hasattr(app, "_mpris_sync_playback"):
                    app._mpris_sync_playback()
                if hasattr(app, "_remote_publish_playback_event"):
                    app._remote_publish_playback_event("playback_error")
                return False

            GLib.idle_add(apply_playback_error)

        try:
            logger.debug("Starting lyrics sequence")

            def apply_loading_lyrics():
                if request_id != getattr(app, "_play_request_id", 0):
                    return False
                app.render_lyrics_list(None, "Loading Lyrics...")
                return False

            GLib.idle_add(apply_loading_lyrics)

            raw_lyrics = app.backend.get_lyrics(track.id)

            if raw_lyrics:
                logger.debug("Got lyrics data. length=%s", len(raw_lyrics))
                app.lyrics_mgr.load_lyrics(raw_lyrics)

                def apply_lyrics():
                    if request_id != getattr(app, "_play_request_id", 0):
                        return False
                    app.render_lyrics_list(app.lyrics_mgr, None)
                    return False

                GLib.idle_add(apply_lyrics)
            else:
                logger.debug("No lyrics returned")

                def apply_no_lyrics():
                    if request_id != getattr(app, "_play_request_id", 0):
                        return False
                    app.render_lyrics_list(None, NO_LYRICS_BOTTOM_HINT)
                    return False

                GLib.idle_add(apply_no_lyrics)

        except Exception as e:
            kind = classify_exception(e)
            logger.exception("Lyrics error [%s]: %s", kind, e)
            if hasattr(app, "record_diag_event"):
                app.record_diag_event(f"Lyrics error [{kind}]: {e}")
            if hasattr(app, "set_diag_health"):
                if kind in ("network", "server", "auth"):
                    app.set_diag_health("network", "warn", f"lyrics-{kind}")
                elif kind in ("parse", "not_found"):
                    app.set_diag_health("decoder", "warn", f"lyrics-{kind}")

            def apply_lyrics_error():
                if request_id != getattr(app, "_play_request_id", 0):
                    return False
                # No-lyrics states should show a subtle bottom hint.
                if kind == "not_found":
                    app.render_lyrics_list(None, NO_LYRICS_BOTTOM_HINT)
                else:
                    app.render_lyrics_list(None, user_message(kind, "lyrics"))
                return False

            GLib.idle_add(apply_lyrics_error)

    Thread(target=task, daemon=True).start()


def scroll_to_lyric(app, widget):
    if not hasattr(app, "lyrics_scroller") or not widget:
        return

    try:
        success, rect = widget.compute_bounds(app.lyrics_vbox)
        if not success:
            return

        label_center_y = rect.origin.y + (rect.size.height / 2)
        viewport_h = app.lyrics_scroller.get_height()
        # Keep active lyric near upper-middle area for smoother reading rhythm.
        anchor_ratio = 0.38
        target = label_center_y - (viewport_h * anchor_ratio)

        adj = app.lyrics_scroller.get_vadjustment()
        max_scroll = adj.get_upper() - adj.get_page_size()
        app.target_scroll_y = max(0, min(target, max_scroll))
    except Exception:
        pass


def _position_poll_due(app, now, last_poll, poll_interval, cached_pd):
    """Whether the UI tick must poll get_position() instead of using the cache.

    While a seek hold is active (adapter's _seek_target_s set), the cache
    still contains the pre-seek position and the wall-clock extrapolation
    would keep advancing it — that showed the old position for up to one
    poll interval after a seek, making the progress dot jump back before
    landing on the target. Polling during the hold returns the pinned seek
    target, so the dot never leaves it.
    """
    if cached_pd is None:
        return True
    if getattr(app.player, "_seek_target_s", None) is not None:
        return True
    return (now - last_poll) >= poll_interval


def update_ui_loop(app):
    now = GLib.get_monotonic_time() / 1_000_000.0
    try:
        playing_now = bool(app.player.is_playing())
        last_playing = getattr(app, "_last_playing_ui_state", None)
        if playing_now != last_playing:
            app._last_playing_ui_state = playing_now
            if getattr(app, "play_btn", None) is not None:
                app.play_btn.set_icon_name(
                    "media-playback-pause-symbolic" if playing_now else "media-playback-start-symbolic"
                )
            if hasattr(app, "_mpris_sync_playback"):
                app._mpris_sync_playback()
    except Exception:
        playing_now = False

    fast_ui_mode = _ui_loop_has_high_frequency_consumer(app)
    overlay_open = _is_now_playing_overlay_open(app)
    p = 0.0
    d = 0.0
    cached_pd = getattr(app, "_ui_cached_pd", None)
    last_poll = float(getattr(app, "_ui_last_pos_poll_ts", 0.0) or 0.0)
    if playing_now:
        poll_interval = 0.10 if fast_ui_mode else 0.45
    else:
        poll_interval = 0.25 if fast_ui_mode else 0.80

    if _position_poll_due(app, now, last_poll, poll_interval, cached_pd):
        p, d = app.player.get_position()
        app._ui_cached_pd = (p, d)
        app._ui_last_pos_poll_ts = now
    else:
        p, d = cached_pd
        if playing_now:
            p = max(0.0, float(p or 0.0) + max(0.0, now - last_poll))
            if float(d or 0.0) > 0.0:
                p = min(float(d), p)

    hold_pos = getattr(app, "_playback_rebind_hold_position_s", None)
    hold_dur = float(getattr(app, "_playback_rebind_hold_duration_s", 0.0) or 0.0)
    hold_until = float(getattr(app, "_playback_rebind_hold_until_s", 0.0) or 0.0)
    if hold_pos is not None:
        if now < hold_until and float(p or 0.0) + 0.75 < float(hold_pos):
            p = float(hold_pos)
            if hold_dur > 0.0:
                d = hold_dur
        else:
            app._playback_rebind_hold_position_s = None
            app._playback_rebind_hold_duration_s = 0.0
            app._playback_rebind_hold_until_s = 0.0

    if d > 0:
        if hasattr(app, "scrobbler"):
            app.scrobbler.check_scrobble(float(p), float(d))
        user_interacting_seek = bool(getattr(app, "_seek_user_interacting", False))
        if not user_interacting_seek:
            scale_changed = False
            try:
                last_max = float(getattr(app, "_ui_last_scale_max", 0.0) or 0.0)
            except Exception:
                last_max = 0.0
            # Range rarely changes during one track; avoid re-applying every tick.
            if abs(last_max - float(d)) >= 0.25:
                app.is_programmatic_update = True
                app.scale.set_range(0, d)
                app.is_programmatic_update = False
                app._ui_last_scale_max = float(d)

            # Avoid noisy tiny value pushes that still trigger redraw/layout work.
            try:
                cur_scale_v = float(app.scale.get_value() or 0.0)
            except Exception:
                cur_scale_v = 0.0
            scale_epsilon = 0.025 if fast_ui_mode else 0.18
            if abs(cur_scale_v - float(p)) >= scale_epsilon:
                if float(p) < cur_scale_v - 2.0:
                    # Diagnostic: the visible progress dot is about to jump
                    # backwards — record where the value came from.
                    logger.info(
                        "SeekTrace: UI backward jump scale=%.2f -> p=%.2f "
                        "(hold_target=%s cached=%.2f)",
                        cur_scale_v, float(p),
                        getattr(app.player, "_seek_target_s", None),
                        float(getattr(app.player, "_cached_pos_s", 0.0) or 0.0),
                    )
                app.is_programmatic_update = True
                app.scale.set_value(p)
                app.is_programmatic_update = False
                scale_changed = True
            if scale_changed and hasattr(app, "_update_progress_thumb_position"):
                app._update_progress_thumb_position()

        current_int_sec = int(p)
        if (not user_interacting_seek) and (not hasattr(app, "_last_sec") or app._last_sec != current_int_sec):
            app.lbl_current_time.set_text(f"{int(p//60)}:{int(p%60):02d}")
            app.lbl_total_time.set_text(f"{int(d//60)}:{int(d%60):02d}")
            app._last_sec = current_int_sec
        elif user_interacting_seek:
            app.lbl_total_time.set_text(f"{int(d//60)}:{int(d%60):02d}")

    lyrics_live = False
    try:
        revealer = getattr(app, "viz_revealer", None)
        lyrics_live = bool(
            revealer is not None
            and revealer.get_reveal_child()
            and str(getattr(app, "_viz_current_page", "spectrum") or "spectrum") == "lyrics"
        )
    except Exception:
        lyrics_live = False

    if lyrics_live and hasattr(app, "lyrics_mgr") and app.lyrics_mgr.has_synced and hasattr(app, "lyric_widgets") and app.lyric_widgets:
        offset_ms = int(getattr(app, "lyrics_user_offset_ms", 0) or 0)
        current_time = p + 0.3 + (offset_ms / 1000.0)
        active_idx = -1

        for i, item in enumerate(app.lyric_widgets):
            if item["time"] <= current_time:
                active_idx = i
            else:
                break

        current_idx = getattr(app, "current_lyric_index", -1)
        if active_idx != current_idx:
            if current_idx != -1 and current_idx < len(app.lyric_widgets):
                prev = app.lyric_widgets[current_idx]
                prev["widget"].remove_css_class("active")
                prev["main"].remove_css_class("active")
                if prev.get("sub") is not None:
                    prev["sub"].remove_css_class("active")
                if prev.get("karaoke_words"):
                    prev["main"].set_markup(_karaoke_markup(prev["karaoke_words"], -1))
                    prev["karaoke_last_idx"] = -1

            if active_idx != -1:
                cur = app.lyric_widgets[active_idx]
                w = cur["widget"]
                w.add_css_class("active")
                cur["main"].add_css_class("active")
                if cur.get("sub") is not None:
                    cur["sub"].add_css_class("active")
                if cur.get("karaoke_words"):
                    k_idx = _karaoke_active_idx(cur["karaoke_words"], current_time)
                    cur["main"].set_markup(_karaoke_markup(cur["karaoke_words"], k_idx))
                    cur["karaoke_last_idx"] = k_idx
                app._scroll_to_lyric(w)

            app.current_lyric_index = active_idx

        # Update karaoke progression while staying on the same active line.
        if active_idx != -1 and active_idx < len(app.lyric_widgets):
            cur = app.lyric_widgets[active_idx]
            if cur.get("karaoke_words"):
                k_idx = _karaoke_active_idx(cur["karaoke_words"], current_time)
                if k_idx != cur.get("karaoke_last_idx", -2):
                    cur["main"].set_markup(_karaoke_markup(cur["karaoke_words"], k_idx))
                    cur["karaoke_last_idx"] = k_idx

    if lyrics_live and hasattr(app, "target_scroll_y") and hasattr(app, "lyrics_scroller"):
        adj = app.lyrics_scroller.get_vadjustment()
        current_y = adj.get_value()
        target_y = app.target_scroll_y
        if abs(target_y - current_y) > 0.5:
            new_y = current_y + (target_y - current_y) * 0.08
            adj.set_value(new_y)

    if hasattr(app, "_mpris_sync_position"):
        mpris_interval = 0.25 if playing_now else 0.8
        last_mpris_sync = float(getattr(app, "_ui_last_mpris_sync_ts", 0.0) or 0.0)
        if (now - last_mpris_sync) >= mpris_interval:
            app._mpris_sync_position()
            app._ui_last_mpris_sync_ts = now

    if overlay_open and hasattr(app, "_sync_now_playing_overlay_state"):
        try:
            app._sync_now_playing_overlay_state(p, d, playing_now)
        except Exception as e:
            logger.debug("Now playing overlay ui sync failed: %s", e)

    return True

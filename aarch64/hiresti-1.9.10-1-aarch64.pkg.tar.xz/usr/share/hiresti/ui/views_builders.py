import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, Pango

from app.app_remote_control import REMOTE_ACCESS_MODES
import utils
from ui.track_table import build_tracks_header, append_header_action_spacers


def build_grid_view(app):
    grid_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["home-view"])
    title_box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=4,
        margin_start=32,
        margin_end=32,
        margin_top=28,
        margin_bottom=10,
        css_classes=["home-topbar"],
    )
    app.grid_title_box = title_box
    title_row = Gtk.Box(spacing=12)
    app.grid_title_row = title_row
    app.grid_title_label = Gtk.Label(label="Home", xalign=0, css_classes=["section-title"])
    app.grid_subtitle_label = Gtk.Label(
        label="Fresh picks and playlists tailored to your listening",
        xalign=1.0,
        ellipsize=3,
        max_width_chars=56,
        hexpand=True,
        halign=Gtk.Align.END,
        css_classes=["home-subtitle", "dim-label"],
    )
    app.artist_fav_btn = Gtk.Button(
        css_classes=["heart-btn"],
        icon_name="hiresti-favorite-symbolic",
        visible=False,
    )
    app.artist_fav_btn.connect("clicked", app.on_artist_fav_clicked)
    title_row.append(app.grid_title_label)
    title_row.append(Gtk.Box(hexpand=True))
    title_row.append(app.grid_subtitle_label)
    title_row.append(app.artist_fav_btn)
    title_box.append(title_row)
    grid_vbox.append(title_box)

    app.login_prompt_box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=20,
        hexpand=True,
        halign=Gtk.Align.FILL,
        valign=Gtk.Align.CENTER,
        vexpand=True,
    )
    app.login_prompt_box.set_visible(False)
    prompt_card = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=12,
        margin_top=12,
        margin_bottom=12,
        margin_start=18,
        margin_end=18,
        halign=Gtk.Align.CENTER,
        css_classes=["login-hero-card"],
    )
    # Avoid forcing a hard minimum width; small windows (e.g. mini mode / narrow
    # restored width) can otherwise trigger GtkStack measure warnings.
    prompt_card.set_size_request(-1, -1)
    prompt_icon = Gtk.Image(
        icon_name="hiresti",
        pixel_size=104,
        css_classes=["dim-label", "login-hero-icon"],
        halign=Gtk.Align.CENTER,
    )
    prompt_label = Gtk.Label(
        label="Please login to access your TIDAL collection",
        css_classes=["heading", "login-hero-title"],
        wrap=True,
        justify=Gtk.Justification.CENTER,
        xalign=0.5,
    )
    prompt_sub = Gtk.Label(
        label="Open TIDAL authentication to load your personalized home, library, and mixes.",
        css_classes=["dim-label", "login-hero-subtitle"],
        wrap=True,
        justify=Gtk.Justification.CENTER,
        xalign=0.5,
    )
    prompt_btn = Gtk.Button(
        label="Login to Tidal",
        css_classes=["pill", "suggested-action", "login-hero-btn"],
        halign=Gtk.Align.CENTER,
    )
    prompt_btn.set_size_request(220, 46)
    prompt_btn.connect("clicked", app.on_login_clicked)
    prompt_card.append(prompt_icon)
    prompt_card.append(prompt_label)
    prompt_card.append(prompt_sub)
    prompt_card.append(prompt_btn)
    app.login_prompt_box.append(prompt_card)
    grid_vbox.append(app.login_prompt_box)

    app.alb_scroll = Gtk.ScrolledWindow(vexpand=True)
    app.collection_content_box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=20,
        margin_start=20,
        margin_end=20,
        margin_bottom=32,
        css_classes=["home-content-box"],
    )
    app.collection_base_margin_start = 20
    app.collection_base_margin_end = 20
    app.collection_base_margin_bottom = 32
    app.alb_scroll.set_child(app.collection_content_box)
    grid_vbox.append(app.alb_scroll)
    app.right_stack.add_named(grid_vbox, "grid_view")


def toggle_login_view(app, logged_in):
    app.login_prompt_box.set_visible(not logged_in)
    app.alb_scroll.set_visible(logged_in)
    if hasattr(app, "search_entry") and app.search_entry is not None:
        app.search_entry.set_visible(logged_in)
    if hasattr(app, "sidebar_box") and app.sidebar_box is not None:
        app.sidebar_box.set_visible(logged_in)
    if not logged_in:
        app.login_btn.set_label("Login")
        app.grid_title_label.set_text("Welcome")
        if hasattr(app, "grid_subtitle_label") and app.grid_subtitle_label is not None:
            app.grid_subtitle_label.set_text("Sign in to load your personalized mixes and library picks")
        return

    display_name = "User"
    user = app.backend.user
    if user:
        meta = getattr(user, "profile_metadata", None)
        if meta:
            if isinstance(meta, dict):
                display_name = meta.get("name") or meta.get("firstName") or display_name
            else:
                display_name = getattr(meta, "name", None) or getattr(meta, "first_name", None) or display_name

        if display_name == "User" or display_name is None:
            candidates = [
                getattr(user, "first_name", None),
                getattr(user, "name", None),
                getattr(user, "firstname", None),
            ]
            for candidate in candidates:
                if candidate and isinstance(candidate, str) and candidate.strip():
                    display_name = candidate
                    break

        if (not display_name or display_name == "User") and hasattr(user, "username") and user.username:
            try:
                display_name = user.username.split("@")[0].capitalize()
            except Exception:
                display_name = user.username

    app.login_btn.set_label(f"Hi, {display_name}")
    app.grid_title_label.set_text("Home")
    if hasattr(app, "grid_subtitle_label") and app.grid_subtitle_label is not None:
        app.grid_subtitle_label.set_text("Fresh picks and playlists tailored to your listening")


def build_tracks_view(app):
    trk_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["tracks-view"])
    trk_scroll = Gtk.ScrolledWindow(vexpand=True)
    app.trk_scroll = trk_scroll
    trk_content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

    # Header: overlay with the dimmed album cover as background, content on top.
    # The overlay's natural size must be driven by the content box (so the
    # area below the action pills doesn't sit on the bg Picture's full
    # natural texture height ~640 px). Use an empty sizing anchor as the
    # main child and add the bg Picture as a non-measured overlay child;
    # only the content is measured.
    app.album_header_overlay = Gtk.Overlay(css_classes=["album-header-overlay"])
    bg_anchor = Gtk.Box(can_target=False)
    bg_anchor.set_size_request(-1, 200)  # min-height; content usually drives
    app.album_header_overlay.set_child(bg_anchor)

    app.album_header_bg = Gtk.Picture()
    app.album_header_bg.set_can_shrink(True)
    try:
        app.album_header_bg.set_content_fit(Gtk.ContentFit.COVER)
    except Exception:
        pass
    app.album_header_bg.add_css_class("album-header-bg")
    app.album_header_bg.set_can_target(False)
    app.album_header_overlay.add_overlay(app.album_header_bg)

    album_header_dim = Gtk.Box(
        css_classes=["album-header-bg-dim"], hexpand=True, vexpand=True,
        can_target=False,
    )
    app.album_header_overlay.add_overlay(album_header_dim)

    app.album_header_box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL, spacing=20,
        margin_top=32, margin_bottom=20, margin_start=32, margin_end=32,
        css_classes=["album-header-box"],
    )
    album_header_top = Gtk.Box(spacing=24, css_classes=["album-header-top"])
    app.header_art = Gtk.Picture()
    app.header_art.set_size_request(utils.COVER_SIZE, utils.COVER_SIZE)
    app.header_art.set_can_shrink(True)
    try:
        app.header_art.set_content_fit(Gtk.ContentFit.COVER)
    except Exception:
        pass
    app.header_art.add_css_class("header-art")

    info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, valign=Gtk.Align.CENTER, hexpand=True)
    app.header_kicker = Gtk.Label(label="Album", xalign=0, css_classes=["album-kicker"])
    app.header_title = Gtk.Label(xalign=0, wrap=True, css_classes=["album-title-large"])
    app.header_artist = Gtk.Label(xalign=0, css_classes=["album-artist-medium"])
    tap = Gtk.GestureClick()
    tap.connect("pressed", app.on_header_artist_clicked)
    app.header_artist.add_controller(tap)
    motion = Gtk.EventControllerMotion()
    motion.connect("enter", lambda c, x, y: utils.set_pointer_cursor(app.header_artist, True))
    motion.connect("leave", lambda c: utils.set_pointer_cursor(app.header_artist, False))
    app.header_artist.add_controller(motion)
    app.header_meta = Gtk.Label(xalign=0, css_classes=["album-meta", "album-meta-pill"])

    info.append(app.header_kicker)
    info.append(app.header_title)
    info.append(app.header_artist)
    info.append(app.header_meta)

    app.fav_btn = Gtk.Button(css_classes=["flat", "album-fav-btn"], icon_name="hiresti-favorite-outline-symbolic", valign=Gtk.Align.CENTER)
    app.fav_btn.connect("clicked", app.on_fav_clicked)
    app.add_playlist_btn = Gtk.Button(icon_name="list-add-symbolic", css_classes=["flat", "circular", "history-scroll-btn"], valign=Gtk.Align.CENTER)
    app.add_playlist_btn.set_tooltip_text("Add Album Tracks to Playlist")
    app.add_playlist_btn.connect("clicked", app.on_add_current_album_to_playlist)
    app.remote_playlist_edit_btn = Gtk.Button(icon_name="document-edit-symbolic", css_classes=["flat", "circular", "history-scroll-btn"], valign=Gtk.Align.CENTER)
    app.remote_playlist_edit_btn.set_tooltip_text("Edit Playlist")
    app.remote_playlist_edit_btn.set_visible(False)
    app.remote_playlist_edit_btn.connect("clicked", lambda _b: app.on_remote_playlist_rename_clicked())
    app.remote_playlist_visibility_btn = Gtk.Button(icon_name="changes-prevent-symbolic", css_classes=["flat", "circular", "history-scroll-btn"], valign=Gtk.Align.CENTER)
    app.remote_playlist_visibility_btn.set_tooltip_text("Set public/private")
    app.remote_playlist_visibility_btn.set_visible(False)
    app.remote_playlist_visibility_btn.connect("clicked", lambda _b: app.on_remote_playlist_toggle_public_clicked())
    app.remote_playlist_more_btn = Gtk.Button(icon_name="open-menu-symbolic", css_classes=["flat", "circular", "history-scroll-btn"], valign=Gtk.Align.CENTER)
    app.remote_playlist_more_btn.set_tooltip_text("More")
    app.remote_playlist_more_btn.set_visible(False)
    app.remote_playlist_more_pop = Gtk.Popover()
    app.remote_playlist_more_pop.set_parent(app.remote_playlist_more_btn)
    more_box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=0,
        margin_top=4,
        margin_bottom=4,
        margin_start=4,
        margin_end=4,
        css_classes=["playlist-more-menu"],
    )
    # Edit Playlist
    edit_menu_btn = Gtk.Button(css_classes=["flat"])
    edit_menu_row = Gtk.Box(spacing=8)
    edit_menu_row.append(Gtk.Image.new_from_icon_name("document-edit-symbolic"))
    edit_menu_row.append(Gtk.Label(label="Edit Playlist", xalign=0))
    edit_menu_btn.set_child(edit_menu_row)
    edit_menu_btn.connect("clicked", lambda _b: (app.remote_playlist_more_pop.popdown(), app.on_remote_playlist_rename_clicked()))
    more_box.append(edit_menu_btn)
    # Toggle Visibility
    vis_menu_btn = Gtk.Button(css_classes=["flat"])
    vis_menu_row = Gtk.Box(spacing=8)
    app._vis_menu_icon = Gtk.Image.new_from_icon_name("changes-prevent-symbolic")
    app._vis_menu_label = Gtk.Label(label="Make Public", xalign=0)
    vis_menu_row.append(app._vis_menu_icon)
    vis_menu_row.append(app._vis_menu_label)
    vis_menu_btn.set_child(vis_menu_row)
    vis_menu_btn.connect("clicked", lambda _b: (app.remote_playlist_more_pop.popdown(), app.on_remote_playlist_toggle_public_clicked()))
    more_box.append(vis_menu_btn)
    # Add to Playlist
    add_menu_btn = Gtk.Button(css_classes=["flat"])
    add_menu_row = Gtk.Box(spacing=8)
    add_menu_row.append(Gtk.Image.new_from_icon_name("list-add-symbolic"))
    add_menu_row.append(Gtk.Label(label="Add to Playlist", xalign=0))
    add_menu_btn.set_child(add_menu_row)
    add_menu_btn.connect("clicked", lambda _b: (app.remote_playlist_more_pop.popdown(), app.on_add_current_album_to_playlist()))
    more_box.append(add_menu_btn)
    more_box.append(Gtk.Separator())
    # Move to Folder
    move_btn = Gtk.Button(css_classes=["flat"])
    move_row = Gtk.Box(spacing=8)
    move_row.append(Gtk.Image.new_from_icon_name("folder-open-symbolic"))
    move_row.append(Gtk.Label(label="Move to Folder", xalign=0))
    move_btn.set_child(move_row)
    move_btn.connect("clicked", lambda _b: (app.remote_playlist_more_pop.popdown(), app.on_remote_playlist_move_to_folder_clicked()))
    more_box.append(move_btn)
    del_btn = Gtk.Button(css_classes=["flat"])
    del_row = Gtk.Box(spacing=8)
    del_row.append(Gtk.Image.new_from_icon_name("user-trash-symbolic"))
    del_row.append(Gtk.Label(label="Delete Playlist", xalign=0))
    del_btn.set_child(del_row)
    del_btn.connect("clicked", lambda _b: (app.remote_playlist_more_pop.popdown(), app.on_remote_playlist_delete_clicked()))
    more_box.append(del_btn)
    app.remote_playlist_more_pop.set_child(more_box)
    app.remote_playlist_more_btn.connect("clicked", lambda _b: app.remote_playlist_more_pop.popup())

    app.track_list_select_btn = Gtk.ToggleButton(
        icon_name="object-select-symbolic",
        css_classes=["flat", "circular", "history-scroll-btn"],
        valign=Gtk.Align.CENTER,
    )
    app.track_list_select_btn.set_tooltip_text("Select Multiple")
    app.track_list_select_btn.connect("toggled", app.on_track_list_select_mode_toggled)

    app.album_action_btns_box = Gtk.Box(spacing=4, valign=Gtk.Align.CENTER, halign=Gtk.Align.END, css_classes=["album-action-btns"])
    app.album_action_btns_box.append(app.remote_playlist_more_btn)
    app.album_action_btns_box.append(app.fav_btn)
    app.album_action_btns_box.append(app.track_list_select_btn)
    app.album_action_btns_box.append(app.add_playlist_btn)

    # Top row: cover + textual info (no action icons here anymore).
    album_header_top.append(app.header_art)
    album_header_top.append(info)
    app.album_header_box.append(album_header_top)

    # Bottom row: Play / Shuffle pills on the left, secondary icons on the right.
    album_header_actions = Gtk.Box(spacing=12, css_classes=["album-header-actions"])
    app.album_primary_actions_box = Gtk.Box(
        spacing=8, valign=Gtk.Align.CENTER, halign=Gtk.Align.START, hexpand=True,
        css_classes=["album-primary-actions"],
    )
    album_header_actions.append(app.album_primary_actions_box)
    album_header_actions.append(app.album_action_btns_box)
    app.album_header_box.append(album_header_actions)

    app.album_header_overlay.add_overlay(app.album_header_box)
    # By default Gtk.Overlay sizes to its main child only; without this the
    # content row spills below the 280 px bg Picture and overlaps the first
    # track row of trk_body.
    app.album_header_overlay.set_measure_overlay(app.album_header_box, True)
    trk_content.append(app.album_header_overlay)

    # Restore horizontal margin for the rest of the page below the header.
    trk_body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_top=20, margin_start=32, margin_end=32)
    trk_content.append(trk_body)

    # Column header (#/Title/Artist/Album/Time) intentionally hidden:
    # build the widget so app.album_sort_buttons stays populated for any
    # callers that look it up, but don't attach it to the body.
    _tracks_head, head_btns = build_tracks_header(
        on_sort_title=lambda _b: app.on_album_sort_clicked("title"),
        on_sort_artist=lambda _b: app.on_album_sort_clicked("artist"),
        on_sort_album=lambda _b: app.on_album_sort_clicked("album"),
        on_sort_time=lambda _b: app.on_album_sort_clicked("time"),
    )
    app.album_sort_buttons = head_btns

    app.track_list = Gtk.ListBox(css_classes=["tracks-list"], margin_start=0, margin_end=0, margin_bottom=32)
    app.track_list_base_margin_bottom = 32
    app.track_list.connect("row-activated", app.on_track_selected)
    trk_body.append(app.track_list)

    app.track_list_select_revealer = Gtk.Revealer(
        transition_type=Gtk.RevealerTransitionType.SLIDE_UP,
        transition_duration=180,
        reveal_child=False,
    )
    select_bar = Gtk.Box(
        spacing=12,
        margin_top=8, margin_bottom=8, margin_start=12, margin_end=12,
        css_classes=["select-action-bar"],
    )
    app.track_list_select_count_label = Gtk.Label(
        label="0 selected", xalign=0, hexpand=True, css_classes=["dim-label"],
    )
    select_bar.append(app.track_list_select_count_label)
    app.track_list_select_all_btn = Gtk.Button(label="Select All", css_classes=["flat", "pill"])
    app.track_list_select_all_btn.connect("clicked", app.on_track_list_select_all_clicked)
    select_bar.append(app.track_list_select_all_btn)
    app.track_list_add_selected_btn = Gtk.Button(label="Add to Playlist", css_classes=["pill", "suggested-action"])
    app.track_list_add_selected_btn.set_sensitive(False)
    app.track_list_add_selected_btn.connect("clicked", app.on_track_list_add_selected_clicked)
    select_bar.append(app.track_list_add_selected_btn)
    app.track_list_select_cancel_btn = Gtk.Button(label="Cancel", css_classes=["flat", "pill"])
    app.track_list_select_cancel_btn.connect("clicked", lambda _b: app.exit_track_list_select_mode())
    select_bar.append(app.track_list_select_cancel_btn)
    app.track_list_select_revealer.set_child(select_bar)
    trk_body.append(app.track_list_select_revealer)

    # Similar albums section (populated async in show_album_details).
    # Placed as a sibling of trk_content (not a child) so it can use its own
    # margin_start/end that matches collection_content_box (20 px each side),
    # giving the FlowBox the same available width as the main album grid.
    app.similar_albums_box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=12,
        margin_top=8,
        margin_bottom=32,
        margin_start=20,
        margin_end=20,
        visible=False,
        css_classes=["home-section", "home-generic-section"],
    )
    app.similar_albums_label = Gtk.Label(label="More by this Artist", xalign=0, css_classes=["home-section-title"])
    app.similar_albums_box.append(app.similar_albums_label)
    app.similar_albums_flow = Gtk.FlowBox(
        homogeneous=True,
        valign=Gtk.Align.START,
        min_children_per_line=4,
        max_children_per_line=10,
        column_spacing=16,
        row_spacing=16,
        selection_mode=Gtk.SelectionMode.NONE,
        css_classes=["home-flow"],
    )
    app.similar_albums_box.append(app.similar_albums_flow)
    app.similar_albums_more_row = Gtk.Box(
        orientation=Gtk.Orientation.HORIZONTAL,
        spacing=8,
        visible=False,
    )
    app.similar_albums_box.append(app.similar_albums_more_row)

    trk_scroll_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    trk_scroll_container.append(trk_content)
    trk_scroll_container.append(app.similar_albums_box)
    trk_scroll.set_child(trk_scroll_container)
    trk_vbox.append(trk_scroll)
    app.right_stack.add_named(trk_vbox, "tracks")


def build_settings_page(app):
    settings_scroll = Gtk.ScrolledWindow(vexpand=True)
    settings_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["settings-container"], spacing=20)
    settings_scroll.set_child(settings_vbox)
    settings_vbox.append(Gtk.Label(label="Settings", xalign=0, css_classes=["album-title-large"], margin_bottom=10))

    settings_vbox.append(Gtk.Label(label="General", xalign=0, css_classes=["section-title"]))
    group_cfg = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["settings-group"])

    row_window_size = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    window_size_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    window_size_info.append(Gtk.Label(label="Remember Window Size", xalign=0, css_classes=["settings-label"]))
    window_size_desc = Gtk.Label(
        label="Restore the last main window width and height on next launch",
        xalign=0,
        css_classes=["dim-label"],
    )
    window_size_desc.set_wrap(True)
    window_size_desc.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
    window_size_desc.set_max_width_chars(56)
    window_size_info.append(window_size_desc)
    row_window_size.append(window_size_info)
    row_window_size.append(Gtk.Box(hexpand=True))
    app.remember_window_size_switch = Gtk.Switch(valign=Gtk.Align.CENTER)
    app.remember_window_size_switch.set_active(bool(app.settings.get("remember_window_size", False)))
    app.remember_window_size_switch.connect("state-set", app.on_remember_window_size_toggled)
    row_window_size.append(app.remember_window_size_switch)
    group_cfg.append(row_window_size)
    settings_vbox.append(group_cfg)

    settings_vbox.append(Gtk.Label(label="Streaming", xalign=0, css_classes=["section-title"], margin_top=10))
    group_q = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["settings-group"])
    row_q = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    row_q.append(Gtk.Label(label="Audio Quality", hexpand=True, xalign=0))
    app.quality_dd = Gtk.DropDown(
        model=Gtk.StringList.new(
            ["Max (Up to 24-bit, 192 kHz)", "High (16-bit, 44.1 kHz)", "Low (320 kbps)"]
        )
    )
    app.quality_dd.connect("notify::selected-item", app.on_quality_changed)
    row_q.append(app.quality_dd)
    group_q.append(row_q)
    settings_vbox.append(group_q)

    settings_vbox.append(Gtk.Label(label="Audio Output", xalign=0, css_classes=["section-title"], margin_top=10))
    group_out = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["settings-group"])

    row_bp = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    bp_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    bp_title_box = Gtk.Box(spacing=6, orientation=Gtk.Orientation.HORIZONTAL)
    bp_title_box.append(Gtk.Label(label="Bit-Perfect Mode", xalign=0, css_classes=["settings-label"]))
    bp_help_btn = Gtk.Button(icon_name="dialog-question-symbolic", css_classes=["flat", "circular"])
    bp_help_btn.set_tooltip_text("Click for details")
    bp_help_pop = Gtk.Popover()
    bp_help_pop.set_parent(bp_help_btn)
    bp_help_pop.set_autohide(True)
    bp_pop_content = Gtk.Label(wrap=True, max_width_chars=44, xalign=0)
    bp_pop_content.set_markup(
        "<b>Bit-Perfect Mode</b>\n\n"
        "• <b>Always:</b> bypasses the app EQ and app volume processing.\n\n"
        "• <b>PipeWire mode:</b> shared output through the PipeWire graph. Convenient "
        "for sharing the device with other apps, but PipeWire resamples to its own "
        "session rate, so this path is not bit-perfect.\n\n"
        "• <b>ALSA（auto）/ALSA（mmap） + Exclusive mode:</b> bypasses the system mixer and is treated as "
        "true bit-perfect playback.\n\n"
        "• <b>USB Rawlink v2:</b> bypasses the kernel USB audio driver and lets hiresTI "
        "talk directly to a compatible external USB DAC. With Bit-Perfect Mode on, "
        "Rawlink uses the app's most direct player-to-device playback path."
    )
    bp_pop_box = Gtk.Box(margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
    bp_pop_box.append(bp_pop_content)
    bp_help_pop.set_child(bp_pop_box)
    bp_help_btn.connect("clicked", lambda x: bp_help_pop.popup())
    bp_title_box.append(bp_help_btn)
    bp_info.append(bp_title_box)
    bp_info.append(Gtk.Label(label="Bypass app EQ/volume; direct device path in USB Rawlink v2", xalign=0, css_classes=["dim-label"]))
    row_bp.append(bp_info)
    row_bp.append(Gtk.Box(hexpand=True))
    app.bp_switch = Gtk.Switch(valign=Gtk.Align.CENTER)
    app.bp_switch.set_active(app.settings.get("bit_perfect", False))
    app.bp_switch.connect("state-set", app.on_bit_perfect_toggled)
    row_bp.append(app.bp_switch)
    group_out.append(row_bp)

    # Bit-Perfect now implies hardware exclusive: when the user turns
    # Bit-Perfect on we filter the driver dropdown to ALSA(auto)/(mmap)/USB
    # Rawlink v2 and toggle the internal exclusive_lock_mode along with it,
    # so a separate "Force Hardware Exclusive" switch would just be a second
    # control wired to the same state. Keep `ex_switch` as a hidden stub so
    # the few remaining `getattr(app, "ex_switch", None)` call sites are
    # safe; the real intent now lives in `bp_switch`.
    app.ex_switch = None

    row_rt = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    rt_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    rt_info.append(Gtk.Label(label="Realtime Audio Priority", xalign=0, css_classes=["settings-label"]))
    rt_info.append(
        Gtk.Label(
            label="ALSA（mmap） writer thread only. Off disables SCHED_FIFO",
            xalign=0,
            css_classes=["dim-label"],
        )
    )
    row_rt.append(rt_info)
    row_rt.append(Gtk.Box(hexpand=True))
    app.mmap_realtime_priority_dd = Gtk.DropDown(
        model=Gtk.StringList.new(app.ALSA_MMAP_REALTIME_PRIORITY_OPTIONS)
    )
    app.mmap_realtime_priority_dd.set_valign(Gtk.Align.CENTER)
    saved_rt_profile = app.settings.get(
        "alsa_mmap_realtime_priority",
        app.ALSA_MMAP_REALTIME_PRIORITY_DEFAULT,
    )
    if saved_rt_profile not in app.ALSA_MMAP_REALTIME_PRIORITY_OPTIONS:
        saved_rt_profile = app.ALSA_MMAP_REALTIME_PRIORITY_DEFAULT
    try:
        target_idx = app.ALSA_MMAP_REALTIME_PRIORITY_OPTIONS.index(saved_rt_profile)
        app.mmap_realtime_priority_dd.set_selected(target_idx)
    except ValueError:
        app.mmap_realtime_priority_dd.set_selected(
            app.ALSA_MMAP_REALTIME_PRIORITY_OPTIONS.index(app.ALSA_MMAP_REALTIME_PRIORITY_DEFAULT)
        )
    app.mmap_realtime_priority_dd.connect(
        "notify::selected-item",
        app.on_mmap_realtime_priority_changed,
    )
    row_rt.append(app.mmap_realtime_priority_dd)

    row_lat = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    lat_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    lat_info.append(Gtk.Label(label="Output Latency", xalign=0, css_classes=["settings-label"]))
    lat_info.append(
        Gtk.Label(
            label="Target buffer size (Effective on ALSA output)",
            xalign=0,
            css_classes=["dim-label"],
        )
    )
    row_lat.append(lat_info)
    row_lat.append(Gtk.Box(hexpand=True))
    app.latency_dd = Gtk.DropDown(model=Gtk.StringList.new(app.LATENCY_OPTIONS))
    app.latency_dd.set_valign(Gtk.Align.CENTER)
    saved_driver = str(app.settings.get("driver", "") or "")
    app.latency_dd.set_sensitive(saved_driver in ("ALSA", "ALSA（auto）", "ALSA (mmap)", "ALSA（mmap）"))

    saved_profile = app.settings.get("latency_profile", "Standard (100ms)")
    if saved_profile not in app.LATENCY_OPTIONS:
        saved_profile = "Standard (100ms)"
    try:
        target_idx = app.LATENCY_OPTIONS.index(saved_profile)
        app.latency_dd.set_selected(target_idx)
    except ValueError:
        app.latency_dd.set_selected(1)
    app.latency_dd.connect("notify::selected-item", app.on_latency_changed)
    row_lat.append(app.latency_dd)
    group_out.append(row_lat)

    row_drv = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    drv_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    drv_title_box = Gtk.Box(spacing=6, orientation=Gtk.Orientation.HORIZONTAL)
    drv_title_box.append(Gtk.Label(label="Audio Driver", xalign=0, css_classes=["settings-label"]))
    drv_help_btn = Gtk.Button(icon_name="dialog-question-symbolic", css_classes=["flat", "circular"])
    drv_help_btn.set_tooltip_text("Click for details")
    drv_help_pop = Gtk.Popover()
    drv_help_pop.set_parent(drv_help_btn)
    drv_help_pop.set_autohide(True)
    drv_pop_content = Gtk.Label(wrap=True, max_width_chars=44, xalign=0)
    drv_pop_content.set_markup(
        "<b>Audio Driver Modes</b>\n\n"
        "• <b>ALSA（auto）:</b> Recommended for most setups. hiresTI chooses the most compatible ALSA path for your device automatically.\n\n"
        "• <b>ALSA（mmap）:</b> A zero-copy ALSA path with a more direct handoff to the device. Best for users who want a leaner playback path or prefer MMAP on their hardware.\n\n"
        "• <b>PipeWire:</b> Routes through the PipeWire shared graph (ALSA→PipeWire bridge). Shared with other apps and resampled to PipeWire's session rate — convenient, but not bit-perfect.\n\n"
        "• <b>USB Rawlink v2:</b> Bypasses the kernel USB audio driver and lets hiresTI talk directly to the USB device for playback. Best for users who want the most direct player-to-DAC path on a compatible external USB DAC."
    )
    drv_pop_box = Gtk.Box(margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
    drv_pop_box.append(drv_pop_content)
    drv_help_pop.set_child(drv_pop_box)
    drv_help_btn.connect("clicked", lambda x: drv_help_pop.popup())
    drv_title_box.append(drv_help_btn)
    drv_info.append(drv_title_box)
    drv_desc = Gtk.Label(
        label="ALSA（auto） for most setups. ALSA（mmap） for zero-copy tuning. USB Rawlink v2 for direct USB playback.",
        xalign=0,
        css_classes=["dim-label"],
    )
    drv_desc.set_wrap(True)
    drv_desc.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
    drv_desc.set_max_width_chars(56)
    drv_info.append(drv_desc)
    row_drv.append(drv_info)
    row_drv.append(Gtk.Box(hexpand=True))
    drivers = app.player.get_drivers()
    # Bit-Perfect mode hides the non-exclusive drivers (PipeWire shared sink
    # and Auto (Default) which routes through it). The legacy exclusive_lock
    # setting is treated as an alias here so users upgrading from older
    # builds still see the filter applied.
    if (app.settings.get("bit_perfect", False)
            or app.settings.get("exclusive_lock", False)):
        drivers = [
            drv
            for drv in drivers
            if drv in ("ALSA（auto）", "ALSA（mmap）", "USB Rawlink v2")
        ]
    app.driver_dd = Gtk.DropDown(model=Gtk.StringList.new(drivers))
    app.driver_dd.connect("notify::selected-item", app.on_driver_changed)
    row_drv.append(app.driver_dd)
    group_out.append(row_drv)

    row_depth = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    depth_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    depth_info.append(Gtk.Label(label="Output Bit Depth", xalign=0, css_classes=["settings-label"]))
    depth_info.append(
        Gtk.Label(
            label="ALSA（auto） / ALSA（mmap） only. Not applicable for USB Rawlink v2 (bit depth is fixed by the device).",
            xalign=0,
            css_classes=["dim-label"],
        )
    )
    row_depth.append(depth_info)
    row_depth.append(Gtk.Box(hexpand=True))
    app.bit_depth_dd = Gtk.DropDown(model=Gtk.StringList.new(["Auto"]))
    app.bit_depth_dd.set_valign(Gtk.Align.CENTER)
    app.bit_depth_dd.set_sensitive(False)
    app.bit_depth_dd.connect("notify::selected-item", app.on_output_bit_depth_changed)
    row_depth.append(app.bit_depth_dd)
    group_out.append(row_depth)

    saved_driver_init = app.settings.get("driver", "")
    app.mmap_realtime_priority_dd.set_sensitive(saved_driver_init == "ALSA（mmap）")
    group_out.append(row_rt)

    # ── USB Rawlink: Clock Alignment ────────────────────────────────────────
    from actions.audio_settings_actions import USB_CLOCK_OPTIONS, USB_CLOCK_DEFAULT
    row_usb_clk = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    usb_clk_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    usb_clk_info.append(Gtk.Label(label="USB Clock Alignment", xalign=0, css_classes=["settings-label"]))
    usb_clk_info.append(
        Gtk.Label(
            label="Push: clock driven by write position. Pull: clock driven by playback position. USB Rawlink v2 only.",
            xalign=0,
            css_classes=["dim-label"],
        )
    )
    row_usb_clk.append(usb_clk_info)
    row_usb_clk.append(Gtk.Box(hexpand=True))
    app.usb_clock_mode_dd = Gtk.DropDown(model=Gtk.StringList.new(USB_CLOCK_OPTIONS))
    app.usb_clock_mode_dd.set_valign(Gtk.Align.CENTER)
    saved_usb_clk = app.settings.get("usb_clock_mode", USB_CLOCK_DEFAULT)
    if saved_usb_clk not in USB_CLOCK_OPTIONS:
        saved_usb_clk = USB_CLOCK_DEFAULT
    app.usb_clock_mode_dd.set_selected(USB_CLOCK_OPTIONS.index(saved_usb_clk))
    app.usb_clock_mode_dd.set_sensitive(saved_driver_init == "USB Rawlink v2")
    app.usb_clock_mode_dd.connect("notify::selected-item", app.on_usb_clock_mode_changed)
    row_usb_clk.append(app.usb_clock_mode_dd)
    group_out.append(row_usb_clk)

    row_dev = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    row_dev.append(Gtk.Label(label="Output Device", hexpand=True, xalign=0))
    app.device_dd = Gtk.DropDown(model=Gtk.StringList.new(["Default"]))
    app.device_dd.set_sensitive(False)
    app.device_dd.connect("notify::selected-item", app.on_device_changed)
    from actions.audio_settings_actions import setup_device_dropdown_refresh_gesture
    setup_device_dropdown_refresh_gesture(app)
    row_dev.append(app.device_dd)
    group_out.append(row_dev)

    row_state = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    row_state.append(Gtk.Label(label="Output Status", xalign=0, valign=Gtk.Align.START))
    status_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, hexpand=True, halign=Gtk.Align.FILL)
    app.output_status_label = Gtk.Label(label="Idle", xalign=0, hexpand=True, css_classes=["dim-label"])
    app.output_status_label.set_wrap(True)
    app.output_status_label.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
    app.output_status_label.set_max_width_chars(72)
    status_box.append(app.output_status_label)
    app.usb_fix_perm_btn = Gtk.Button(label="Fix USB Permissions", css_classes=["flat"], valign=Gtk.Align.START)
    app.usb_fix_perm_btn.connect("clicked", app.on_usb_fix_permissions_clicked)
    app.usb_fix_perm_btn.set_visible(False)
    status_box.append(app.usb_fix_perm_btn)
    row_state.append(status_box)
    app.output_recover_btn = Gtk.Button(label="Recover", css_classes=["flat"], valign=Gtk.Align.START)
    app.output_recover_btn.connect("clicked", app.on_recover_output_clicked)
    app.output_recover_btn.set_sensitive(False)
    row_state.append(app.output_recover_btn)
    group_out.append(row_state)

    row_rebind = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    rebind_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    rebind_info.append(Gtk.Label(label="Auto Rebind Once", xalign=0, css_classes=["settings-label"]))
    rebind_info.append(
        Gtk.Label(
            label="When a disconnected device returns, auto switch back one time",
            xalign=0,
            css_classes=["dim-label"],
        )
    )
    row_rebind.append(rebind_info)
    row_rebind.append(Gtk.Box(hexpand=True))
    app.auto_rebind_once_switch = Gtk.Switch(valign=Gtk.Align.CENTER)
    app.auto_rebind_once_switch.set_active(bool(app.settings.get("output_auto_rebind_once", False)))
    app.auto_rebind_once_switch.connect("state-set", app.on_auto_rebind_once_toggled)
    row_rebind.append(app.auto_rebind_once_switch)
    group_out.append(row_rebind)

    settings_vbox.append(group_out)

    settings_vbox.append(Gtk.Label(label="Remote Control", xalign=0, css_classes=["section-title"], margin_top=10))
    group_remote = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["settings-group"])

    row_remote_enable = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    remote_enable_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    remote_enable_info.append(Gtk.Label(label="Enable Remote Control", xalign=0, css_classes=["settings-label"]))
    remote_enable_info.append(
        Gtk.Label(
            label="Expose playback and queue control over HTTP JSON-RPC",
            xalign=0,
            css_classes=["dim-label"],
        )
    )
    row_remote_enable.append(remote_enable_info)
    row_remote_enable.append(Gtk.Box(hexpand=True))
    app.remote_api_switch = Gtk.Switch(valign=Gtk.Align.CENTER)
    app.remote_api_switch.connect("state-set", app.on_remote_api_enabled_toggled)
    row_remote_enable.append(app.remote_api_switch)
    group_remote.append(row_remote_enable)

    row_remote_mode = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    mode_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    mode_info.append(Gtk.Label(label="Access Mode", xalign=0, css_classes=["settings-label"]))
    mode_info.append(
        Gtk.Label(
            label="Local only is for same-machine clients. LAN is for another device on your network.",
            xalign=0,
            css_classes=["dim-label"],
            wrap=True,
        )
    )
    row_remote_mode.append(mode_info)
    row_remote_mode.append(Gtk.Box(hexpand=True))
    app.remote_api_access_dd = Gtk.DropDown(model=Gtk.StringList.new(REMOTE_ACCESS_MODES))
    app.remote_api_access_dd.connect("notify::selected-item", app.on_remote_api_access_mode_changed)
    row_remote_mode.append(app.remote_api_access_dd)
    group_remote.append(row_remote_mode)

    row_remote_network = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    app.remote_api_network_row = row_remote_network
    network_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    network_info.append(Gtk.Label(label="Network Binding", xalign=0, css_classes=["settings-label"]))
    network_info.append(
        Gtk.Label(
            label="Configure the bind address and port. Apply is required before changes take effect.",
            xalign=0,
            css_classes=["dim-label"],
            wrap=True,
        )
    )
    row_remote_network.append(network_info)
    network_controls = Gtk.Box(spacing=8, hexpand=True, halign=Gtk.Align.END)
    app.remote_api_bind_entry = Gtk.Entry(placeholder_text="0.0.0.0")
    app.remote_api_bind_entry.set_width_chars(13)
    network_controls.append(app.remote_api_bind_entry)
    app.remote_api_port_spin = Gtk.SpinButton.new_with_range(1, 65535, 1)
    app.remote_api_port_spin.set_numeric(True)
    app.remote_api_port_spin.set_width_chars(6)
    network_controls.append(app.remote_api_port_spin)
    app.remote_api_apply_btn = Gtk.Button(label="Apply", css_classes=["flat"])
    app.remote_api_apply_btn.connect("clicked", app.on_remote_api_apply_network_settings)
    network_controls.append(app.remote_api_apply_btn)
    row_remote_network.append(network_controls)
    group_remote.append(row_remote_network)

    row_remote_allow = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    app.remote_api_allowlist_row = row_remote_allow
    allow_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    allow_info.append(Gtk.Label(label="Allowed Clients", xalign=0, css_classes=["settings-label"]))
    allow_info.append(
        Gtk.Label(
            label="Optional CIDRs, e.g. 192.168.1.0/24 or 192.168.1.50/32",
            xalign=0,
            css_classes=["dim-label"],
        )
    )
    row_remote_allow.append(allow_info)
    row_remote_allow.append(Gtk.Box(hexpand=True))
    app.remote_api_allowlist_entry = Gtk.Entry(placeholder_text="192.168.1.0/24, 192.168.1.50/32")
    app.remote_api_allowlist_entry.set_width_chars(28)
    row_remote_allow.append(app.remote_api_allowlist_entry)
    group_remote.append(row_remote_allow)

    row_remote_endpoint = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    row_remote_endpoint.append(Gtk.Label(label="MCP Endpoint", xalign=0, css_classes=["settings-label"]))
    row_remote_endpoint.append(Gtk.Box(hexpand=True))
    endpoint_controls = Gtk.Box(spacing=8, halign=Gtk.Align.END)
    app.remote_api_endpoint_label = Gtk.Label(label="", xalign=1, css_classes=["dim-label"])
    app.remote_api_endpoint_label.set_selectable(True)
    endpoint_controls.append(app.remote_api_endpoint_label)
    app.remote_api_endpoint_copy_btn = Gtk.Button(label="Copy", css_classes=["flat"])
    app.remote_api_endpoint_copy_btn.connect("clicked", app.on_remote_api_copy_endpoint_clicked)
    endpoint_controls.append(app.remote_api_endpoint_copy_btn)
    row_remote_endpoint.append(endpoint_controls)
    group_remote.append(row_remote_endpoint)

    row_remote_rpc_endpoint = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    row_remote_rpc_endpoint.append(Gtk.Label(label="RPC Endpoint", xalign=0, css_classes=["settings-label"]))
    row_remote_rpc_endpoint.append(Gtk.Box(hexpand=True))
    rpc_endpoint_controls = Gtk.Box(spacing=8, halign=Gtk.Align.END)
    app.remote_api_rpc_endpoint_label = Gtk.Label(label="", xalign=1, css_classes=["dim-label"])
    app.remote_api_rpc_endpoint_label.set_selectable(True)
    rpc_endpoint_controls.append(app.remote_api_rpc_endpoint_label)
    app.remote_api_rpc_endpoint_copy_btn = Gtk.Button(label="Copy", css_classes=["flat"])
    app.remote_api_rpc_endpoint_copy_btn.connect("clicked", app.on_remote_api_copy_rpc_endpoint_clicked)
    rpc_endpoint_controls.append(app.remote_api_rpc_endpoint_copy_btn)
    row_remote_rpc_endpoint.append(rpc_endpoint_controls)
    group_remote.append(row_remote_rpc_endpoint)

    row_remote_status = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    row_remote_status.append(Gtk.Label(label="Status", xalign=0, css_classes=["settings-label"]))
    row_remote_status.append(Gtk.Box(hexpand=True))
    app.remote_api_status_label = Gtk.Label(label="Stopped", xalign=1, css_classes=["dim-label"])
    app.remote_api_status_label.set_selectable(True)
    row_remote_status.append(app.remote_api_status_label)
    group_remote.append(row_remote_status)

    row_remote_key = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    key_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    key_info.append(Gtk.Label(label="API Key", xalign=0, css_classes=["settings-label"]))
    key_info.append(
        Gtk.Label(
            label="Use this bearer token from OpenClaw or the MCP bridge.",
            xalign=0,
            css_classes=["dim-label"],
        )
    )
    row_remote_key.append(key_info)
    key_controls = Gtk.Box(spacing=8, hexpand=True, halign=Gtk.Align.END)
    app.remote_api_key_entry = Gtk.Entry(editable=False, hexpand=True)
    app.remote_api_key_entry.set_width_chars(32)
    key_controls.append(app.remote_api_key_entry)
    app.remote_api_copy_btn = Gtk.Button(label="Copy", css_classes=["flat"])
    app.remote_api_copy_btn.connect("clicked", app.on_remote_api_copy_key_clicked)
    key_controls.append(app.remote_api_copy_btn)
    app.remote_api_generate_btn = Gtk.Button(label="Generate Key", css_classes=["flat"])
    app.remote_api_generate_btn.connect("clicked", app.on_remote_api_generate_key_clicked)
    key_controls.append(app.remote_api_generate_btn)
    row_remote_key.append(key_controls)
    group_remote.append(row_remote_key)

    settings_vbox.append(group_remote)

    # ---- Scrobbling section ----
    settings_vbox.append(Gtk.Label(label="Scrobbling", xalign=0, css_classes=["section-title"], margin_top=10))
    group_scrobble = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["settings-group"])

    # Last.fm enable
    row_lfm_enable = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    lfm_enable_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    lfm_enable_info.append(Gtk.Label(label="Last.fm", xalign=0, css_classes=["settings-label"]))
    lfm_enable_info.append(
        Gtk.Label(label="Scrobble played tracks to your Last.fm profile", xalign=0, css_classes=["dim-label"])
    )
    row_lfm_enable.append(lfm_enable_info)
    row_lfm_enable.append(Gtk.Box(hexpand=True))
    app.scrobble_lastfm_switch = Gtk.Switch(valign=Gtk.Align.CENTER)
    app.scrobble_lastfm_switch.connect("state-set", app.on_lastfm_enabled_toggled)
    row_lfm_enable.append(app.scrobble_lastfm_switch)
    group_scrobble.append(row_lfm_enable)

    # Last.fm Connect row
    row_lfm_connect = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=4, margin_bottom=8)
    app.scrobble_lastfm_status_label = Gtk.Label(label="Not connected", xalign=0, css_classes=["dim-label"], hexpand=True)
    row_lfm_connect.append(app.scrobble_lastfm_status_label)
    app.scrobble_lastfm_disconnect_btn = Gtk.Button(label="Disconnect", css_classes=["flat", "destructive-action"])
    app.scrobble_lastfm_disconnect_btn.set_sensitive(False)
    app.scrobble_lastfm_disconnect_btn.connect("clicked", app.on_lastfm_disconnect_clicked)
    row_lfm_connect.append(app.scrobble_lastfm_disconnect_btn)
    app.scrobble_lastfm_connect_btn = Gtk.Button(label="Connect", css_classes=["flat", "suggested-action"])
    app.scrobble_lastfm_connect_btn.connect("clicked", app.on_lastfm_connect_clicked)
    row_lfm_connect.append(app.scrobble_lastfm_connect_btn)
    group_scrobble.append(row_lfm_connect)

    sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL, margin_start=12, margin_end=12)
    group_scrobble.append(sep)

    # ListenBrainz enable
    row_lb_enable = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    lb_enable_info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
    lb_enable_info.append(Gtk.Label(label="ListenBrainz", xalign=0, css_classes=["settings-label"]))
    lb_enable_info.append(
        Gtk.Label(label="Submit listens to your ListenBrainz account", xalign=0, css_classes=["dim-label"])
    )
    row_lb_enable.append(lb_enable_info)
    row_lb_enable.append(Gtk.Box(hexpand=True))
    app.scrobble_lb_switch = Gtk.Switch(valign=Gtk.Align.CENTER)
    app.scrobble_lb_switch.connect("state-set", app.on_listenbrainz_enabled_toggled)
    row_lb_enable.append(app.scrobble_lb_switch)
    group_scrobble.append(row_lb_enable)

    # ListenBrainz token
    row_lb_token = Gtk.Box(spacing=12, margin_start=12, margin_end=12, margin_top=4, margin_bottom=8)
    row_lb_token.append(Gtk.Label(label="User Token", xalign=0, css_classes=["dim-label"], width_chars=12))
    app.scrobble_lb_token_entry = Gtk.Entry(hexpand=True, visibility=False, input_purpose=Gtk.InputPurpose.PASSWORD,
                                             placeholder_text="From listenbrainz.org/profile/")
    row_lb_token.append(app.scrobble_lb_token_entry)
    app.scrobble_lb_status_label = Gtk.Label(label="", css_classes=["dim-label"])
    row_lb_token.append(app.scrobble_lb_status_label)
    lb_save_btn = Gtk.Button(label="Save", css_classes=["flat"])
    lb_save_btn.connect("clicked", app.on_listenbrainz_token_saved)
    row_lb_token.append(lb_save_btn)
    group_scrobble.append(row_lb_token)

    settings_vbox.append(group_scrobble)

    # Sync scrobble UI to current settings
    if hasattr(app, "_init_scrobble_settings_ui"):
        app._init_scrobble_settings_ui()

    settings_vbox.append(Gtk.Label(label="Diagnostics", xalign=0, css_classes=["section-title"], margin_top=10))
    group_diag = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, css_classes=["settings-group"])
    row_diag = Gtk.Box(spacing=10, margin_start=12, margin_end=12, margin_top=8, margin_bottom=8)
    row_diag.append(Gtk.Label(label="Runtime Health", xalign=0, hexpand=True))
    app.network_status_label = Gtk.Label(label="NET IDLE", xalign=1, css_classes=["diag-chip", "status-idle"])
    app.decoder_status_label = Gtk.Label(label="DEC IDLE", xalign=1, css_classes=["diag-chip", "status-idle"])
    app.events_btn = Gtk.Button(label="Events", css_classes=["flat"])
    row_diag.append(app.network_status_label)
    row_diag.append(app.decoder_status_label)
    row_diag.append(app.events_btn)
    group_diag.append(row_diag)
    settings_vbox.append(group_diag)

    app._diag_pop = Gtk.Popover()
    app._diag_pop.set_parent(app.events_btn)
    pop_box = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=8,
        margin_top=10,
        margin_bottom=10,
        margin_start=10,
        margin_end=10,
    )
    pop_box.append(Gtk.Label(label="Recent Events", xalign=0, css_classes=["settings-label"]))
    sw = Gtk.ScrolledWindow(min_content_height=180, min_content_width=540)
    app._diag_text = Gtk.TextView(editable=False, cursor_visible=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD_CHAR)
    sw.set_child(app._diag_text)
    pop_box.append(sw)
    app._diag_pop.set_child(pop_box)
    app.events_btn.connect("clicked", app.show_diag_events)
    if hasattr(app, "_refresh_remote_api_settings_ui"):
        app._refresh_remote_api_settings_ui()
    app.right_stack.add_named(settings_scroll, "settings")


def build_search_view(app):
    content_max_width = 1180
    app.search_scroll = Gtk.ScrolledWindow(vexpand=True)
    vbox = Gtk.Box(
        orientation=Gtk.Orientation.VERTICAL,
        spacing=24,
        margin_top=32,
        margin_bottom=32,
        margin_start=32,
        margin_end=32,
        css_classes=["home-view", "search-view"],
    )
    search_clamp = Adw.Clamp(maximum_size=content_max_width, tightening_threshold=920)
    search_clamp.set_child(vbox)
    app.search_scroll.set_child(search_clamp)
    app.search_content_box = vbox
    app.search_base_margin_bottom = 32

    app.search_status_label = Gtk.Label(xalign=0, css_classes=["dim-label", "search-status-label"])
    app.search_status_label.set_visible(False)
    vbox.append(app.search_status_label)

    app.res_art_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, css_classes=["home-section"])
    app.res_art_box.append(Gtk.Label(label="Artists", xalign=0, css_classes=["home-section-title"]))
    app.res_art_flow = Gtk.FlowBox(
        max_children_per_line=10,
        selection_mode=Gtk.SelectionMode.NONE,
        column_spacing=24,
        row_spacing=24,
    )
    app.res_art_flow.connect("child-activated", app.on_grid_item_activated)
    app.res_art_box.append(app.res_art_flow)
    app.res_art_box.set_visible(False)
    vbox.append(app.res_art_box)

    app.res_alb_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, css_classes=["home-section"])
    app.res_alb_box.append(Gtk.Label(label="Albums", xalign=0, css_classes=["home-section-title"]))
    app.res_alb_flow = Gtk.FlowBox(
        max_children_per_line=10,
        selection_mode=Gtk.SelectionMode.NONE,
        column_spacing=24,
        row_spacing=24,
    )
    app.res_alb_flow.connect("child-activated", app.on_grid_item_activated)
    app.res_alb_box.append(app.res_alb_flow)
    app.res_alb_box.set_visible(False)
    vbox.append(app.res_alb_box)

    app.res_pl_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, css_classes=["home-section"])
    app.res_pl_box.append(Gtk.Label(label="Playlists", xalign=0, css_classes=["home-section-title"]))
    app.res_pl_flow = Gtk.FlowBox(
        max_children_per_line=10,
        selection_mode=Gtk.SelectionMode.NONE,
        column_spacing=24,
        row_spacing=24,
    )
    app.res_pl_box.append(app.res_pl_flow)
    app.res_pl_box.set_visible(False)
    vbox.append(app.res_pl_box)

    app.res_trk_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, css_classes=["home-section"])
    trk_head = Gtk.Box(spacing=8)
    trk_head.append(Gtk.Label(label="Tracks", xalign=0, hexpand=True, css_classes=["home-section-title"]))
    app.search_tracks_page_label = Gtk.Label(label="Page 1/1", css_classes=["dim-label"], valign=Gtk.Align.CENTER)
    trk_head.append(app.search_tracks_page_label)
    app.search_prev_page_btn = Gtk.Button(label="Prev", css_classes=["flat"])
    app.search_prev_page_btn.set_sensitive(False)
    app.search_prev_page_btn.connect("clicked", app.on_search_tracks_prev_page)
    trk_head.append(app.search_prev_page_btn)
    app.search_next_page_btn = Gtk.Button(label="Next", css_classes=["flat"])
    app.search_next_page_btn.set_sensitive(False)
    app.search_next_page_btn.connect("clicked", app.on_search_tracks_next_page)
    trk_head.append(app.search_next_page_btn)
    app.like_selected_tracks_btn = Gtk.Button(label="Like Selected", css_classes=["flat", "pill"])
    app.like_selected_tracks_btn.set_sensitive(False)
    app.like_selected_tracks_btn.connect("clicked", app.on_like_selected_search_tracks)
    trk_head.append(app.like_selected_tracks_btn)
    app.add_selected_tracks_btn = Gtk.Button(label="Add Selected", css_classes=["flat", "pill"])
    app.add_selected_tracks_btn.set_sensitive(False)
    app.add_selected_tracks_btn.connect("clicked", app.on_add_selected_search_tracks)
    trk_head.append(app.add_selected_tracks_btn)
    app.res_trk_box.append(trk_head)
    app.res_trk_list = Gtk.ListBox(css_classes=["boxed-list", "tracks-list", "search-tracks-list"])
    app.res_trk_list.connect("row-activated", app.on_search_track_selected)
    app.res_trk_box.append(app.res_trk_list)
    app.res_trk_box.set_visible(False)
    vbox.append(app.res_trk_box)

    app.right_stack.add_named(app.search_scroll, "search_view")

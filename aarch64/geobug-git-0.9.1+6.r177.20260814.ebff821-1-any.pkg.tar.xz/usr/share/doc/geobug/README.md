# Geobug

Geobug is an adaptive client for GeoClue, the geolocation D-bus server from
freedesktop.org. It can display your location information (coordinates, speed
etc.) and save a track of your movements to a GPX-file.

## License

GPL-3.0

## Screenshots

![Main view](https://tpikonen.codeberg.page/geobug/img/screenshot-default.png)
![Expanded view](https://tpikonen.codeberg.page/geobug/img/screenshot-expanded.png)
![Landscape view, dark mode](https://tpikonen.codeberg.page/geobug/img/screenshot-landscape-dark.png)

## Dependencies:

    python 3.6+, PyGObject, GTK4, libadwaita, Geoclue, gpxpy

## Installing and running

### Flathub

<a href='https://flathub.org/apps/details/page.codeberg.tpikonen.geobug'>
<img width='240' alt='Get it on Flathub' src='https://flathub.org/api/badge?locale=en'/>
</a>

Geobug is
[in flathub](https://flathub.org/apps/details/page.codeberg.tpikonen.geobug)
and can be installed from there, or from a software manager like Gnome software.
The direct install link is
[here](https://dl.flathub.org/repo/appstream/page.codeberg.tpikonen.geobug.flatpakref).

Run

    flatpak run page.codeberg.tpikonen.geobug

to execute from the command line.

### From source tree

Run the script `bin/geobug`.

### pipx install from source tree

Run

    pipx install --system-site-packages ./

The `--system-site-packages` option allows the created venv to use PyGObject from your distribution.

A link to an executable entry point script is created in `$HOME/.local/bin/geobug`.
Links to `.desktop` or icon files are not created by pipx, but you can create them manually:

    ln -s ~/.local/pipx/venvs/geobug/share/applications/geobug.desktop ~/.local/share/applications/geobug.desktop
    ln -s ~/.local/pipx/venvs/geobug/share/icons/hicolor/scalable/apps/page.codeberg.tpikonen.geobug.svg ~/.local/share/icons

### Flatpak from source tree

Run

    flatpak-builder --install --user build-dir flatpak/page.codeberg.tpikonen.geobug.yaml

in the source tree root. Then run

    flatpak run page.codeberg.tpikonen.geobug

to execute.

## Hints

You can start recording a GPX track by selecting 'Record track' from the main menu. The GPX file is saved in `$HOME/Documents/geobug-tracks`.

<center>
  <img src="https://tpikonen.codeberg.page/geobug/img/page.codeberg.tpikonen.geobug.svg" alt="Geobug logo" style="width:128px;height:128px;" />
</center>

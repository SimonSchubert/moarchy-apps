# SPDX-FileCopyrightText: 2026 Kreuder <mk@singular.de>
# SPDX-License-Identifier: GPL-3.0-only

APP_ID = "de.singular.drew"
APP_NAME = "Drew"
VERSION = "0.3.0"
LOCALEDIR = "/usr/share/locale"

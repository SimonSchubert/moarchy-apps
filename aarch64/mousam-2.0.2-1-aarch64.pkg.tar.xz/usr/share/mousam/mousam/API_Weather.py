import requests
import datetime

from .settings import settings
from .CORE_Cache import cached
from .CORE_Helpers import TIMEOUT
from .configs import HPA_TO_INHG, OPEN_METEO_BASE_URL
from .CORE_Logging import get_logger

logger = get_logger("API_Weather")

extend_url = ""


class Weather:
    """
    See Documentation at: https://open-meteo.com/en/docs
    """

    def __init__(self) -> None:
        global extend_url

        if settings.unit == "imperial":
            extend_url = "&temperature_unit=fahrenheit&wind_speed_unit=mph"
        else:
            extend_url = ""

    # Current Weather =============================================
    @classmethod
    @cached()
    def current_weather(cls,latitude: float, longitude: float, **kwargs):
        url = OPEN_METEO_BASE_URL + f"?latitude={latitude}&longitude={longitude}"

        # Check for kwargs keyword parameters
        if "current" in kwargs:
            current_fields = ",".join(kwargs.get("current"))
            url = url + f"&current={current_fields}" + extend_url

        try:
            url = url + "&timeformat=unixtime"
            response = requests.get(url, timeout=TIMEOUT)
            response.raise_for_status()  # Raise an exception if the request was unsuccessful
            data = response.json()
            if settings.unit == "imperial":
                inHg = data['current']['surface_pressure'] * HPA_TO_INHG
                data['current']['surface_pressure'] = inHg
                data['current_units']['surface_pressure'] = 'inHg'
            return data
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch current weather data: {e}")

    def _get_current_weather(self, lat, lon):
        current_args = [
            "temperature_2m",
            "relativehumidity_2m",
            "apparent_temperature",
            "is_day",
            "uv_index",
            "precipitation",
            "weathercode",
            "surface_pressure",
            "windspeed_10m",
            "winddirection_10m",
        ]
        return self.current_weather(lat, lon, current=current_args)

    # Hourly Forecast ==============================================
    @classmethod
    @cached()
    def forecast_hourly(cls,latitude: float, longitude: float, **kwargs):
        url = OPEN_METEO_BASE_URL + f"?latitude={latitude}&longitude={longitude}&timezone=auto"

        # Check for kwargs keyword parameters
        if "hourly" in kwargs:
            hourly_fields = ",".join(kwargs.get("hourly"))
            url = url + f"&hourly={hourly_fields}" + extend_url

        try:
            url = url + "&timeformat=unixtime"
            response = requests.get(url, timeout=TIMEOUT)
            response.raise_for_status()  # Raise an exception if the request was unsuccessful
            data = response.json()
            if settings.unit == "imperial":
                for i in range(len(data['hourly']['surface_pressure'])):
                    inHg = data['hourly']['surface_pressure'][i] * HPA_TO_INHG
                    data['hourly']['surface_pressure'][i] = inHg
                data['hourly_units']['surface_pressure'] = 'inHg'
            return data
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch data: {e}")

    def _get_hourly_forecast(self, lat, lon):
        hourly_args = [
            "temperature_2m",
            "relativehumidity_2m",
            "dewpoint_2m",
            "apparent_temperature",
            "weathercode",
            "precipitation",
            "precipitation_probability",
            "surface_pressure",
            "visibility",
            "windspeed_10m",
            "wind_direction_10m",
            "uv_index",
            "is_day",
        ]

        today = datetime.datetime.today().date()
        tomorrow = today + datetime.timedelta(days=1)
        return self.forecast_hourly(
            lat, lon, hourly=hourly_args, start_date=today, end_date=tomorrow
        )

    # Forecast daily ====================================================
    @classmethod
    @cached()
    def forecast_daily(cls,latitude: float, longitude: float, **kwargs):
        url = OPEN_METEO_BASE_URL + f"?latitude={latitude}&longitude={longitude}"
        if "daily" in kwargs:
            hourly_fields = ",".join(kwargs.get("daily"))
            url = url + f"&daily={hourly_fields}"

        if "timezone" in kwargs:
            url = url + f"&timezone={kwargs.get('timezone')}"
        if "start_date" in kwargs:
            url = url + f"&start_date={kwargs.get('start_date')}"

        if "end_date" in kwargs:
            url = url + f"&end_date={kwargs.get('end_date')}" 

        try:
            url = url + "&timeformat=unixtime" + extend_url
            response = requests.get(url, timeout=TIMEOUT)
            response.raise_for_status()  # Raise an exception if the request was unsuccessful
            data = response.json()
            return data
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to fetch data: {e}")

    def _get_daily_forecast(self, lat, lon):
        daily_args = [
            "weathercode",
            "temperature_2m_max",
            "temperature_2m_min",
            "sunrise",
            "sunset",
            "uv_index_max",
            "precipitation_sum",
            "windspeed_10m_max",
        ]

        return self.forecast_daily(lat, lon, daily=daily_args, timezone="GMT")

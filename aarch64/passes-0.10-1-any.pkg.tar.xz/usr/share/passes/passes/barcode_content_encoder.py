# barcode_content_encoder.py
#
# Copyright 2022-2023 Pablo Sánchez Rodríguez
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import ctypes
import math

from enum import IntEnum


class BarcodeType(IntEnum):
    AZTEC = 0
    CODE128 = 1
    PDF417 = 2
    QRCODE = 3


class BarcodeContentEncoder():

    native_implementation = ctypes.CDLL('/usr/lib/passes/libbarcode-content-encoder.so')

    # arguments to encode_a_barcode
    native_implementation.encode_barcode.argtypes = [ctypes.c_char_p,
                                                     ctypes.c_uint,
                                                     ctypes.c_uint,
                                                     ctypes.POINTER(ctypes.c_uint),
                                                     ctypes.POINTER(ctypes.c_uint)]

    # return type after encoding a barcode
    native_implementation.encode_barcode.restype = ctypes.c_char_p

    @classmethod
    def encode_barcode(this_class, text, barcode_type, encoding):
        if not encoding:
            encoding = 'iso-8859-1'

        encoded_text = text.encode(encoding)

        code_width = ctypes.c_uint()
        code_height = ctypes.c_uint()

        module_list = this_class.native_implementation\
            .encode_barcode(encoded_text,
                            len(encoded_text),
                            barcode_type,
                            ctypes.byref(code_width),
                            ctypes.byref(code_height))\
            .decode()

        this_class.native_implementation.free_last_result()

        return module_list, code_width.value, code_height.value

    @classmethod
    def encode_aztec_code(this_class, text, encoding):
        return this_class.encode_barcode(text, BarcodeType.AZTEC, encoding)

    @classmethod
    def encode_code128_code(this_class, text, encoding):
        return this_class.encode_barcode(text, BarcodeType.CODE128, encoding)

    @classmethod
    def encode_pdf417_code(this_class, text, encoding):
        return this_class.encode_barcode(text, BarcodeType.PDF417, encoding)

    @classmethod
    def encode_qr_code(this_class, text, encoding):
        return this_class.encode_barcode(text, BarcodeType.QRCODE, encoding)


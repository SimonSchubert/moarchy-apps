# SPDX-License-Identifier: GPL-3.0-or-later
"""Leggio - a sheet music viewer for Linux."""

__version__ = "0.1.0"
APP_ID = "io.github.MrGilfy.Leggio"

![Azbuka](data/icons/hicolor/scalable/apps/com.github.naregderlevonean.Azbuka.svg)





# Azbuka

**Azbuka** provides a streamlined interface for converting Russian Cyrillic text using a vast library of international and historical standards:

- Soviet 1
- Soviet 2
- Soviet 3 Yanalif
- Cranberry Internal
- Passport 2013 ICAO
- Passport 2010
- Passport 1997
- GOST R 52535.1 2006
- GOST R 52290 2004
- GOST 7.79 2000
- UNGEGN 1987
- ISO 9 1995
- ISO 9 1968 Base
- ISO 9 1968 Alt 1
- ISO 9 1968 Alt 2
- ISO 9 1954
- Scientific 1951
- Scientific 1939
- Scientific 1905
- ALA LC
- OST 8483
- BGN PCGN
- BS 2979 1958
- GOST 16876 71
- ST SEV 1362




## Installation



### Arch GNU/Linux (AUR)

Install the development version via your favorite AUR helper:

```bash
yay -S azbuka-git
```



### From Source

```bash
git clone https://github.com/naregderlevonean/azbuka.git
cd azbuka
cargo build --release
cargo install --path .
```

*(Ensure `~/.cargo/bin` is in your `$PATH`)*




## License

This project is licensed under the **GPL-3.0 License**. See the `LICENSE` file for details.


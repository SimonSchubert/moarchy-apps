# Copyright 2023, tfuxu <https://github.com/tfuxu>
# SPDX-License-Identifier: GPL-3.0-or-later

rootdir          = '/io/github/tfuxu/Halftone'
datadir          = '/usr/share'
pkgdatadir       = '/usr/share/halftone'
localedir        = '/usr/share/locale'

app_id           = 'io.github.tfuxu.Halftone'
rel_ver          = '0.6.0'
version          = '0.6.0'
build_type       = 'plain'

project_url      = 'https://github.com/tfuxu/halftone'
bugtracker_url   = 'https://github.com/tfuxu/halftone/issues'
help_url         = 'https://github.com/tfuxu/halftone/discussions'
#translate_url    = ''

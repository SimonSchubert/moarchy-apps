# dockerd

> هي عملية مستمرة تعمل في الخلفية تبدأها لتتحكم في حاويات الدوكر.
> لمزيد من التفاصيل: <https://docs.docker.com/reference/cli/dockerd/>.

- قم بتشغيل دوكر في الخلفية:

`dockerd`

- قم بتشغيل دوكر في الخلفية واجعله يستمع علي منفذ معين (يونكس وبروتوكول ضبط الإرسال):

`dockerd {{[-H|--host]}} unix://{{path/to/tmp.sock}} {{[-H|--host]}} tcp://{{ip}}`

- قم بتشغيل دوكر في الخلفية برقم عملية معين:

`dockerd {{[-p|--pidfile]}} {{path/to/pid_file}}`

- قم بتشغيل دوكر في وضع التصحيح واكتشاف الأخطاء:

`dockerd {{[-D|--debug]}}`

- قم بتشغيل دوكر وحدد له مستوي سجل معين:

`dockerd {{[-l|--log-level]}} {{debug|info|warn|error|fatal}}`

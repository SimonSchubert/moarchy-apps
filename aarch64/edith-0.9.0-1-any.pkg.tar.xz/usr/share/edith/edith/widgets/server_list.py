# SPDX-FileCopyrightText: 2025 Kreuder <mk@singular.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gio, Gtk, GObject, Gdk

from edith.models.server import FolderInfo
from edith.services.config import ConfigService
from edith.widgets.folder_row import FolderRow
from edith.widgets.file_dialogs import NameDialog
from edith.i18n import _


class ServerList(Gtk.Box):
    """Sidebar widget showing server groups for navigation."""

    __gsignals__ = {
        "group-selected": (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        "selection-changed": (GObject.SignalFlags.RUN_FIRST, None, (bool,)),
        "add-server-to-folder": (GObject.SignalFlags.RUN_FIRST, None, (str,)),
    }

    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)

        self._servers = []
        self._folders = []
        self._row_keys = {}   # Gtk.ListBoxRow → group key str
        self._folder_rows = {}

        # Scrolled list
        sw = Gtk.ScrolledWindow(
            vexpand=True,
            hscrollbar_policy=Gtk.PolicyType.NEVER,
        )

        self._list_box = Gtk.ListBox(
            selection_mode=Gtk.SelectionMode.SINGLE,
            css_classes=["navigation-sidebar"],
        )
        self._list_box.connect("row-activated", self._on_row_activated)
        self._list_box.connect("row-selected", self._on_row_selected)

        sw.set_child(self._list_box)
        self.append(sw)

        self._setup_context_menus()

        self.load_servers()

    # ------------------------------------------------------------------
    # Context menus
    # ------------------------------------------------------------------

    def _setup_context_menus(self):
        # --- Folder context menu ---
        folder_menu = Gio.Menu()
        folder_menu.append(_("Add Server Here\u2026"), "folder.add-server")
        folder_menu.append(_("Rename Group\u2026"), "folder.rename")
        folder_menu.append(_("Delete Group"), "folder.delete-folder")

        self._folder_menu = Gtk.PopoverMenu(menu_model=folder_menu, has_arrow=False)
        self._folder_menu.set_parent(self._list_box)

        folder_group = Gio.SimpleActionGroup()

        add_server_action = Gio.SimpleAction.new("add-server", None)
        add_server_action.connect("activate", self._on_folder_add_server)
        folder_group.add_action(add_server_action)

        rename_action = Gio.SimpleAction.new("rename", None)
        rename_action.connect("activate", self._on_folder_rename)
        folder_group.add_action(rename_action)

        delete_folder_action = Gio.SimpleAction.new("delete-folder", None)
        delete_folder_action.connect("activate", self._on_folder_delete)
        folder_group.add_action(delete_folder_action)

        self._list_box.insert_action_group("folder", folder_group)

        # --- Empty area context menu ---
        empty_menu = Gio.Menu()
        empty_menu.append(_("New Server Group\u2026"), "area.new-folder")

        self._empty_menu = Gtk.PopoverMenu(menu_model=empty_menu, has_arrow=False)
        self._empty_menu.set_parent(self._list_box)

        area_group = Gio.SimpleActionGroup()

        new_folder_action = Gio.SimpleAction.new("new-folder", None)
        new_folder_action.connect("activate", lambda *_: self.show_new_folder_dialog())
        area_group.add_action(new_folder_action)

        self._list_box.insert_action_group("area", area_group)

        # Right-click gesture
        gesture = Gtk.GestureClick(button=Gdk.BUTTON_SECONDARY)
        gesture.connect("pressed", self._on_right_click)
        self._list_box.add_controller(gesture)

        self._context_row = None

    def _on_right_click(self, gesture, n_press, x, y):
        row = self._list_box.get_row_at_y(int(y))
        rect = Gdk.Rectangle()
        rect.x = int(x)
        rect.y = int(y)
        rect.width = 1
        rect.height = 1

        if row is None:
            self._empty_menu.set_pointing_to(rect)
            self._empty_menu.popup()
            return

        self._context_row = row
        child = row.get_child()

        if isinstance(child, FolderRow):
            self._folder_menu.set_pointing_to(rect)
            self._folder_menu.popup()
        # Special rows (All Servers, Without Group): no context menu

    # ------------------------------------------------------------------
    # Context menu actions — folder
    # ------------------------------------------------------------------

    def _on_folder_add_server(self, action, param):
        if not self._context_row:
            return
        child = self._context_row.get_child()
        if isinstance(child, FolderRow):
            self.emit("add-server-to-folder", child.folder_info.id)

    def _on_folder_rename(self, action, param):
        if not self._context_row:
            return
        child = self._context_row.get_child()
        if not isinstance(child, FolderRow):
            return
        folder = child.folder_info
        win = self.get_root()
        dialog = NameDialog("Rename Group", "Group name", folder.name)
        dialog.connect("submitted", self._on_folder_rename_submitted, folder)
        dialog.present(win)

    def _on_folder_rename_submitted(self, dialog, new_name, folder):
        current_key = self._get_selected_key()
        folder.name = new_name
        self._folders = ConfigService.update_folder(folder)
        self._rebuild_list()
        self.select_group(current_key or "__all__")

    def _on_folder_delete(self, action, param):
        if not self._context_row:
            return
        child = self._context_row.get_child()
        if not isinstance(child, FolderRow):
            return
        folder = child.folder_info
        win = self.get_root()
        dlg = Adw.AlertDialog(
            heading=_("Delete Group?"),
            body=_("Delete \u201c{name}\u201d? Servers inside will become ungrouped.").format(name=folder.name),
        )
        dlg.add_response("cancel", _("Cancel"))
        dlg.add_response("delete", _("Delete"))
        dlg.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
        dlg.connect("response", self._on_folder_delete_response, folder)
        dlg.present(win)

    def _on_folder_delete_response(self, dialog, response, folder):
        if response == "delete":
            current_key = self._get_selected_key()
            # Ungroup member servers
            for s in self._servers:
                if s.folder_id == folder.id:
                    s.folder_id = ""
            ConfigService.save_servers(self._servers)
            self._folders = ConfigService.delete_folder(folder.id)
            self._servers = ConfigService.load_servers()
            self._rebuild_list()
            # If the deleted folder was selected, fall back to All Servers
            if current_key == folder.id:
                self.select_group("__all__")
            else:
                self.select_group(current_key or "__all__")

    # ------------------------------------------------------------------
    # New folder dialog
    # ------------------------------------------------------------------

    def show_new_folder_dialog(self):
        win = self.get_root()
        dialog = NameDialog("New Server Group", "Group name", "")
        dialog.connect("submitted", self._on_new_folder_submitted)
        dialog.present(win)

    def _on_new_folder_submitted(self, dialog, name):
        current_key = self._get_selected_key()
        folder = FolderInfo(name=name)
        self._folders = ConfigService.add_folder(folder)
        self._rebuild_list()
        self.select_group(current_key or "__all__")

    # ------------------------------------------------------------------
    # Loading and rebuilding the list
    # ------------------------------------------------------------------

    def load_servers(self):
        self._servers = ConfigService.load_servers()
        self._folders = ConfigService.load_folders()
        self._rebuild_list()

    def _rebuild_list(self):
        # Remove all rows
        while True:
            row = self._list_box.get_row_at_index(0)
            if row is None:
                break
            self._list_box.remove(row)
        self._row_keys.clear()
        self._folder_rows.clear()

        # Compute per-folder and ungrouped counts
        folder_ids = {f.id for f in self._folders}
        folder_counts = {f.id: 0 for f in self._folders}
        ungrouped_count = 0
        for s in self._servers:
            if s.folder_id and s.folder_id in folder_ids:
                folder_counts[s.folder_id] += 1
            else:
                ungrouped_count += 1

        # "All Servers" row
        all_widget = self._make_nav_row("edith-server-symbolic", "All Servers", len(self._servers))
        self._list_box.append(all_widget)
        lbr = all_widget.get_parent()
        if lbr:
            self._row_keys[lbr] = "__all__"

        # "Without Group" row — only when ungrouped servers exist
        if ungrouped_count > 0:
            ug_widget = self._make_nav_row("edith-folder-striped-symbolic", "Without Group", ungrouped_count)
            self._list_box.append(ug_widget)
            lbr = ug_widget.get_parent()
            if lbr:
                self._row_keys[lbr] = "__ungrouped__"

        # One FolderRow per folder, in config order (user-defined via drag-and-drop)
        for folder in self._folders:
            folder_row = FolderRow(folder)
            folder_row.set_count(folder_counts.get(folder.id, 0))
            self._list_box.append(folder_row)
            lbr = folder_row.get_parent()
            if lbr:
                self._row_keys[lbr] = folder.id
                self._setup_folder_dnd(lbr, folder)
            self._folder_rows[folder.id] = folder_row

    # ------------------------------------------------------------------
    # Folder drag-and-drop reordering
    # ------------------------------------------------------------------

    def _setup_folder_dnd(self, list_box_row, folder: "FolderInfo"):
        """Attach DragSource and DropTarget to a folder's ListBoxRow for reordering."""

        # Drag source
        drag = Gtk.DragSource(actions=Gdk.DragAction.MOVE)

        def on_drag_prepare(d, x, y):
            return Gdk.ContentProvider.new_for_value(
                GObject.Value(GObject.TYPE_STRING, folder.id)
            )

        def on_drag_begin(d, gdk_drag):
            drag_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            drag_box.append(Gtk.Image(icon_name="edith-folder-symbolic", pixel_size=16))
            drag_box.append(Gtk.Label(label=folder.name))
            Gtk.DragIcon.get_for_drag(gdk_drag).set_child(drag_box)

        drag.connect("prepare", on_drag_prepare)
        drag.connect("drag-begin", on_drag_begin)
        list_box_row.add_controller(drag)

        # Drop target
        drop = Gtk.DropTarget.new(GObject.TYPE_STRING, Gdk.DragAction.MOVE)

        def on_drop_enter(d, x, y):
            list_box_row.add_css_class("drop-target")
            return Gdk.DragAction.MOVE

        def on_drop_leave(d):
            list_box_row.remove_css_class("drop-target")

        def on_drop(d, value, x, y):
            list_box_row.remove_css_class("drop-target")
            source_id = value
            target_id = folder.id
            if source_id == target_id:
                return False
            # Reorder: move source to target's position
            ordered_ids = [f.id for f in self._folders]
            if source_id not in ordered_ids:
                return False
            ordered_ids.remove(source_id)
            target_idx = ordered_ids.index(target_id)
            ordered_ids.insert(target_idx, source_id)
            current_key = self._get_selected_key()
            self._folders = ConfigService.reorder_folders(ordered_ids)
            self._rebuild_list()
            self.select_group(current_key or "__all__")
            return True

        drop.connect("enter", on_drop_enter)
        drop.connect("leave", on_drop_leave)
        drop.connect("drop", on_drop)
        list_box_row.add_controller(drop)

    def _make_nav_row(self, icon_name: str, label: str, count: int) -> "Gtk.Box":
        box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL,
            spacing=8,
            margin_start=8,
            margin_end=8,
            margin_top=8,
            margin_bottom=8,
        )
        icon = Gtk.Image(icon_name=icon_name)
        box.append(icon)
        name_label = Gtk.Label(
            label=label,
            xalign=0,
            hexpand=True,
            css_classes=["heading"],
        )
        box.append(name_label)
        count_label = Gtk.Label(
            label=str(count),
            css_classes=["dim-label", "caption"],
            valign=Gtk.Align.CENTER,
        )
        box.append(count_label)
        return box

    # ------------------------------------------------------------------
    # Row activation / selection
    # ------------------------------------------------------------------

    def _on_row_activated(self, list_box, row):
        key = self._row_keys.get(row)
        if key is not None:
            self.emit("group-selected", key)

    def _on_row_selected(self, list_box, row):
        self.emit("selection-changed", row is not None)

    # ------------------------------------------------------------------
    # Programmatic selection
    # ------------------------------------------------------------------

    def _get_selected_key(self) -> str | None:
        row = self._list_box.get_selected_row()
        if row:
            return self._row_keys.get(row)
        return None

    def get_selected_key(self) -> str | None:
        """Public accessor for the currently selected group key."""
        return self._get_selected_key()

    def select_group(self, key: str):
        """Programmatically select a group row by key and emit group-selected."""
        for lbr, k in self._row_keys.items():
            if k == key:
                self._list_box.select_row(lbr)
                self.emit("group-selected", key)
                return
        # Fallback: select first row
        first = self._list_box.get_row_at_index(0)
        if first:
            self._list_box.select_row(first)
            k = self._row_keys.get(first)
            if k:
                self.emit("group-selected", k)

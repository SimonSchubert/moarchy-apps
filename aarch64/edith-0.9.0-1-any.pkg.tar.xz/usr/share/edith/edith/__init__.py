# SPDX-FileCopyrightText: 2025 Kreuder <mk@singular.de>
# SPDX-License-Identifier: GPL-3.0-or-later

APP_ID = "de.singular.edith"
VERSION = "0.9.0"
APP_NAME = "Edith"
LOCALEDIR = "/usr/share/locale"

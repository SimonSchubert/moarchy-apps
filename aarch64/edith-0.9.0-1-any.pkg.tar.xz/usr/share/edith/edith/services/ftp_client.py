# SPDX-FileCopyrightText: 2025 Kreuder <mk@singular.de>
# SPDX-License-Identifier: GPL-3.0-or-later

"""FTP/FTPS client with the same interface as SftpClient."""

import os
import socket
import stat as stat_module
import threading
from ftplib import FTP, FTP_TLS, error_perm  # nosec B402
from io import BytesIO
from pathlib import Path

from edith.services.transfer_queue import TransferAborted


class _ImplicitFTP_TLS(FTP_TLS):
    """FTP_TLS subclass for implicit FTPS (TLS on connect, port 990)."""

    def connect(self, host="", port=0, timeout=-999, source_address=None):
        if host:
            self.host = host
        if port:
            self.port = port
        if timeout != -999:
            self.timeout = timeout
        if source_address is not None:
            self.source_address = source_address

        sock = socket.create_connection(
            (self.host, self.port), self.timeout, self.source_address
        )
        self.af = sock.family
        self.sock = self.context.wrap_socket(sock, server_hostname=self.host)
        self.file = self.sock.makefile("r", encoding=self.encoding)
        self.welcome = self.getresp()
        return self.welcome


class FtpFileAttr:
    """Mimics paramiko SFTPAttributes for FTP directory entries."""

    def __init__(self, filename, facts, owner="", group=""):
        self.filename = filename
        self.st_size = int(facts.get("size", 0))
        self.st_mode = 0

        entry_type = facts.get("type", "file").lower()
        if entry_type in ("dir", "cdir", "pdir"):
            self.st_mode = stat_module.S_IFDIR | 0o755
        else:
            self.st_mode = stat_module.S_IFREG | 0o644

        modify = facts.get("modify")
        if modify:
            import calendar
            import time
            try:
                t = time.strptime(modify, "%Y%m%d%H%M%S")
                self.st_mtime = calendar.timegm(t)
            except ValueError:
                self.st_mtime = 0
        else:
            self.st_mtime = 0

        unix_mode = facts.get("unix.mode")
        if unix_mode:
            try:
                mode_bits = int(unix_mode, 8)
                if entry_type in ("dir", "cdir", "pdir"):
                    self.st_mode = stat_module.S_IFDIR | mode_bits
                else:
                    self.st_mode = stat_module.S_IFREG | mode_bits
            except ValueError:
                pass

        # Textual names: explicit (parsed from LIST) or MLSD *name facts.
        self.ownername = owner or facts.get("unix.ownername", "") or facts.get("unix.owner", "")
        self.groupname = group or facts.get("unix.groupname", "") or facts.get("unix.group", "")
        # Numeric ids only when the server actually sent them; otherwise leave
        # unset (None) so ownership renders as "unknown" rather than root (0).
        self.st_uid = int(facts["unix.uid"]) if "unix.uid" in facts else None
        self.st_gid = int(facts["unix.gid"]) if "unix.gid" in facts else None
        self.st_atime = self.st_mtime


class FtpClient:
    """Thread-safe FTP client matching the SftpClient interface."""

    # Seconds between keep-alive NOOPs on an idle control connection.
    _KEEPALIVE_INTERVAL = 30

    def __init__(self):
        self._ftp = None
        self._lock = threading.Lock()
        self._use_tls = False
        self._keepalive_thread = None
        self._keepalive_stop = None

    def connect(
        self,
        host: str,
        port: int = 21,
        username: str = "",
        password: str | None = None,
        encryption: str = "none",
        timeout: float = 10,
        **kwargs,
    ):
        """Connect to an FTP server.

        encryption: "none", "explicit_optional", "explicit_required", "implicit"
        """
        self._use_tls = encryption != "none"

        if encryption == "implicit":
            ftp = _ImplicitFTP_TLS(timeout=timeout)
        elif encryption in ("explicit_required", "explicit_optional"):
            ftp = FTP_TLS(timeout=timeout)
        else:
            ftp = FTP(timeout=timeout)  # nosec B321

        ftp.connect(host, port)

        if encryption == "explicit_required":
            ftp.auth()
        elif encryption == "explicit_optional":
            try:
                ftp.auth()
            except OSError:
                pass  # server doesn't support TLS, continue unencrypted

        ftp.login(username or "anonymous", password or "")

        if encryption != "none" and isinstance(ftp, FTP_TLS):
            ftp.prot_p()

        # Check for MLSD support
        self._has_mlsd = self._check_mlsd(ftp)

        with self._lock:
            self._ftp = ftp

        self._start_keepalive()

    def _start_keepalive(self):
        """Start a background thread that sends NOOP on an idle connection.

        Unlike paramiko's transport (which has set_keepalive), ftplib has no
        built-in keep-alive, so an idle control connection gets dropped by the
        server's idle timeout. This thread sends a periodic NOOP to keep it
        alive, mirroring SftpClient's transport.set_keepalive(30).
        """
        self._keepalive_stop = threading.Event()
        self._keepalive_thread = threading.Thread(
            target=self._keepalive_loop,
            args=(self._keepalive_stop,),
            daemon=True,
        )
        self._keepalive_thread.start()

    def _keepalive_loop(self, stop: threading.Event):
        while not stop.wait(self._KEEPALIVE_INTERVAL):
            # Try the lock without blocking: if a transfer or command is in
            # flight, traffic is already flowing and no NOOP is needed.
            if not self._lock.acquire(blocking=False):
                continue
            try:
                if self._ftp is None:
                    return
                try:
                    self._ftp.voidcmd("NOOP")
                except Exception:
                    # Connection is gone or unhealthy; stop pinging it.
                    return
            finally:
                self._lock.release()

    def _stop_keepalive(self):
        if self._keepalive_stop:
            self._keepalive_stop.set()
        self._keepalive_thread = None
        self._keepalive_stop = None

    @staticmethod
    def _check_mlsd(ftp):
        try:
            feat = ftp.sendcmd("FEAT")
            return "MLST" in feat.upper()
        except Exception:
            return False

    def close(self):
        self._stop_keepalive()
        with self._lock:
            if self._ftp:
                try:
                    self._ftp.quit()
                except OSError:
                    try:
                        self._ftp.close()
                    except OSError:
                        pass
                self._ftp = None

    @property
    def is_connected(self) -> bool:
        with self._lock:
            if not self._ftp:
                return False
            try:
                self._ftp.voidcmd("NOOP")
                return True
            except Exception:
                return False

    def normalize(self, path: str) -> str:
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if path == ".":
                return self._ftp.pwd()
            # FTP has no realpath; resolve relative to cwd
            old = self._ftp.pwd()
            try:
                self._ftp.cwd(path)
                resolved = self._ftp.pwd()
            finally:
                self._ftp.cwd(old)
            return resolved

    def listdir_attr(self, path: str) -> list:
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if self._has_mlsd:
                return self._listdir_mlsd(path)
            return self._listdir_list(path)

    def _listdir_mlsd(self, path: str) -> list:
        results = []
        for name, facts in self._ftp.mlsd(path):
            if name in (".", ".."):
                continue
            results.append(FtpFileAttr(name, facts))
        return results

    def _listdir_list(self, path: str) -> list:
        """Fallback parser for servers without MLSD (Unix-style LIST)."""
        lines = []
        self._ftp.retrlines(f"LIST {path}", lines.append)
        results = []
        for line in lines:
            parts = line.split(None, 8)
            if len(parts) < 9:
                continue
            name = parts[8]
            if name in (".", ".."):
                continue
            perms = parts[0]
            owner = parts[2]
            group = parts[3]
            size = int(parts[4]) if parts[4].isdigit() else 0
            facts = {"size": str(size)}
            if perms.startswith("d"):
                facts["type"] = "dir"
            else:
                facts["type"] = "file"
            # Parse permission bits from rwxrwxrwx string
            mode = self._parse_permission_string(perms[1:10]) if len(perms) >= 10 else 0
            if mode:
                facts["unix.mode"] = oct(mode)[2:]
            results.append(FtpFileAttr(name, facts, owner=owner, group=group))
        return results

    @staticmethod
    def _parse_permission_string(s: str) -> int:
        """Convert 'rwxrwxrwx' to an octal mode integer."""
        if len(s) != 9:
            return 0
        mode = 0
        mapping = [
            (0o400, 0), (0o200, 1), (0o100, 2),
            (0o040, 3), (0o020, 4), (0o010, 5),
            (0o004, 6), (0o002, 7), (0o001, 8),
        ]
        for bit, idx in mapping:
            if s[idx] != "-":
                mode |= bit
        return mode

    def download(self, remote_path: str, local_path: str, progress_cb=None,
                 cancel_event=None, set_channel=None):
        """Download a remote file to a local path.

        cancel_event/set_channel mirror SftpClient.download(): the cancel
        event is checked between chunks and the connection is registered for
        force-close so a stalled transfer can be interrupted.
        """
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if set_channel:
                set_channel(self._ftp)
            file_size = self._size_unlocked(remote_path)
            received = 0
            with open(local_path, "wb") as f:
                def callback(chunk):
                    nonlocal received
                    if cancel_event is not None and cancel_event.is_set():
                        raise TransferAborted()
                    f.write(chunk)
                    received += len(chunk)
                    if progress_cb:
                        progress_cb(received, file_size)
                self._ftp.retrbinary(f"RETR {remote_path}", callback)

    def download_recursive(self, remote_path: str, local_path: str, progress_cb=None,
                           cancel_event=None, set_channel=None):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if set_channel:
                set_channel(self._ftp)
            if self._is_dir_unlocked(remote_path):
                self._download_dir_unlocked(remote_path, local_path, progress_cb,
                                            cancel_event)
            else:
                file_size = self._size_unlocked(remote_path)
                Path(local_path).parent.mkdir(parents=True, exist_ok=True)
                received = 0
                with open(local_path, "wb") as f:
                    def callback(chunk):
                        nonlocal received
                        if cancel_event is not None and cancel_event.is_set():
                            raise TransferAborted()
                        f.write(chunk)
                        received += len(chunk)
                        if progress_cb:
                            progress_cb(received, file_size)
                    self._ftp.retrbinary(f"RETR {remote_path}", callback)

    def download_many(self, items, progress_cb=None, cancel_event=None, set_channel=None):
        """Download several remote paths.

        Mirrors SftpClient.download_many() so callers need no protocol
        branch.  FTP has no channels to conserve, so this is a plain loop
        over the single control connection.
        """
        for remote_path, local_path in items:
            if cancel_event is not None and cancel_event.is_set():
                raise TransferAborted()
            self.download_recursive(remote_path, local_path, progress_cb=progress_cb,
                                    cancel_event=cancel_event, set_channel=set_channel)

    def _download_dir_unlocked(self, remote_path: str, local_path: str, progress_cb=None,
                               cancel_event=None):
        Path(local_path).mkdir(parents=True, exist_ok=True)
        if self._has_mlsd:
            entries = list(self._ftp.mlsd(remote_path))
        else:
            entries = self._listdir_list_raw(remote_path)

        for name, facts in entries:
            if name in (".", ".."):
                continue
            child_remote = f"{remote_path.rstrip('/')}/{name}"
            child_local = os.path.join(local_path, name)
            entry_type = facts.get("type", "file").lower()
            if entry_type in ("dir", "cdir", "pdir"):
                self._download_dir_unlocked(child_remote, child_local, progress_cb,
                                            cancel_event)
            else:
                file_size = int(facts.get("size", 0))
                received = [0]
                with open(child_local, "wb") as f:
                    def make_callback(r, s):
                        def callback(chunk):
                            if cancel_event is not None and cancel_event.is_set():
                                raise TransferAborted()
                            f.write(chunk)
                            r[0] += len(chunk)
                            if progress_cb:
                                progress_cb(r[0], s)
                        return callback
                    self._ftp.retrbinary(f"RETR {child_remote}", make_callback(received, file_size))

    def _listdir_list_raw(self, path: str) -> list:
        """LIST fallback returning (name, facts) tuples like mlsd."""
        lines = []
        self._ftp.retrlines(f"LIST {path}", lines.append)
        results = []
        for line in lines:
            parts = line.split(None, 8)
            if len(parts) < 9:
                continue
            name = parts[8]
            facts = {"type": "dir" if parts[0].startswith("d") else "file",
                     "size": parts[4] if parts[4].isdigit() else "0"}
            results.append((name, facts))
        return results

    def upload(self, local_path: str, remote_path: str, progress_cb=None, overwrite=False):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if not overwrite and self._exists_unlocked(remote_path):
                name = remote_path.rsplit("/", 1)[-1]
                raise FileExistsError(f"'{name}' already exists on the server")
            file_size = os.path.getsize(local_path)
            sent = 0
            with open(local_path, "rb") as f:
                if progress_cb:
                    def callback(chunk):
                        nonlocal sent
                        sent += len(chunk)
                        progress_cb(sent, file_size)
                    self._ftp.storbinary(f"STOR {remote_path}", f, callback=callback)
                else:
                    self._ftp.storbinary(f"STOR {remote_path}", f)

    def stat(self, path: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if self._has_mlsd:
                parent = path.rsplit("/", 1)[0] or "/"
                name = path.rsplit("/", 1)[-1]
                for entry_name, facts in self._ftp.mlsd(parent):
                    if entry_name == name:
                        return FtpFileAttr(name, facts)
                raise FileNotFoundError(f"No such file or directory: '{path}'")
            # Fallback: try SIZE + MDTM + check if directory
            found = False
            facts = {"size": "0", "type": "file"}
            try:
                self._ftp.voidcmd("TYPE I")
                size = self._ftp.size(path)
                if size is not None:
                    facts["size"] = str(size)
                found = True
            except (OSError, error_perm):
                pass
            try:
                mdtm_resp = self._ftp.sendcmd(f"MDTM {path}")
                # Response: "213 YYYYMMDDHHMMSS"
                if mdtm_resp.startswith("213 "):
                    facts["modify"] = mdtm_resp[4:].strip()
                    found = True
            except (OSError, error_perm):
                pass
            if self._is_dir_unlocked(path):
                facts["type"] = "dir"
                found = True
            if not found:
                raise FileNotFoundError(f"No such file or directory: '{path}'")
            return FtpFileAttr(path.rsplit("/", 1)[-1], facts)

    def mkdir(self, path: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            self._ftp.mkd(path)

    def rename(self, old_path: str, new_path: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if self._exists_unlocked(new_path):
                name = new_path.rsplit("/", 1)[-1]
                raise FileExistsError(f"'{name}' already exists at the destination")
            self._ftp.rename(old_path, new_path)

    def chmod(self, path: str, mode: int):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            mode_str = oct(mode)[2:]
            resp = self._ftp.sendcmd(f"SITE CHMOD {mode_str} {path}")
            if not resp.startswith("2"):
                raise OSError(f"SITE CHMOD not supported by this server: {resp}")

    def remove(self, path: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            self._ftp.delete(path)

    def rmdir(self, path: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            self._ftp.rmd(path)

    def rmdir_recursive(self, path: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            self._rmdir_recursive_unlocked(path)

    def _rmdir_recursive_unlocked(self, path: str):
        if self._has_mlsd:
            entries = list(self._ftp.mlsd(path))
        else:
            entries = self._listdir_list_raw(path)
        for name, facts in entries:
            if name in (".", ".."):
                continue
            child = f"{path.rstrip('/')}/{name}"
            entry_type = facts.get("type", "file").lower()
            if entry_type in ("dir", "cdir", "pdir"):
                self._rmdir_recursive_unlocked(child)
            else:
                self._ftp.delete(child)
        self._ftp.rmd(path)

    def copy_remote(self, src: str, dst: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if self._exists_unlocked(dst):
                name = dst.rsplit("/", 1)[-1]
                raise FileExistsError(f"'{name}' already exists at the destination")
            self._copy_file_unlocked(src, dst)

    def copy_remote_recursive(self, src: str, dst: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if self._exists_unlocked(dst):
                name = dst.rsplit("/", 1)[-1]
                raise FileExistsError(f"'{name}' already exists at the destination")
            self._copy_recursive_unlocked(src, dst)

    def _copy_file_unlocked(self, src: str, dst: str):
        """Copy by downloading to memory and re-uploading."""
        buf = BytesIO()
        self._ftp.retrbinary(f"RETR {src}", buf.write)
        buf.seek(0)
        self._ftp.storbinary(f"STOR {dst}", buf)

    def _copy_recursive_unlocked(self, src: str, dst: str):
        if self._is_dir_unlocked(src):
            try:
                self._ftp.mkd(dst)
            except OSError:
                pass  # directory may already exist
            if self._has_mlsd:
                entries = list(self._ftp.mlsd(src))
            else:
                entries = self._listdir_list_raw(src)
            for name, facts in entries:
                if name in (".", ".."):
                    continue
                child_src = f"{src.rstrip('/')}/{name}"
                child_dst = f"{dst.rstrip('/')}/{name}"
                self._copy_recursive_unlocked(child_src, child_dst)
        else:
            self._copy_file_unlocked(src, dst)

    def create_file(self, path: str):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            self._ftp.storbinary(f"STOR {path}", BytesIO(b""))

    def upload_directory(self, local_dir: str, remote_dir: str, overwrite=False):
        with self._lock:
            if not self._ftp:
                raise RuntimeError("Not connected")
            if not overwrite and self._exists_unlocked(remote_dir):
                name = remote_dir.rsplit("/", 1)[-1]
                raise FileExistsError(f"'{name}' already exists on the server")
            self._upload_directory_unlocked(local_dir, remote_dir)

    def _upload_directory_unlocked(self, local_dir: str, remote_dir: str):
        try:
            self._ftp.mkd(remote_dir)
        except OSError:
            pass  # directory may already exist
        for entry in os.listdir(local_dir):
            local_path = os.path.join(local_dir, entry)
            remote_path = f"{remote_dir.rstrip('/')}/{entry}"
            if os.path.isdir(local_path):
                self._upload_directory_unlocked(local_path, remote_path)
            else:
                with open(local_path, "rb") as f:
                    self._ftp.storbinary(f"STOR {remote_path}", f)

    def is_dir(self, path: str) -> bool:
        with self._lock:
            if not self._ftp:
                return False
            return self._is_dir_unlocked(path)

    def _is_dir_unlocked(self, path: str) -> bool:
        old = self._ftp.pwd()
        try:
            self._ftp.cwd(path)
            self._ftp.cwd(old)
            return True
        except Exception:
            return False

    def _exists_unlocked(self, path: str) -> bool:
        try:
            self._ftp.voidcmd("TYPE I")
            self._ftp.size(path)
            return True
        except (OSError, error_perm):
            pass
        return self._is_dir_unlocked(path)

    def _size_unlocked(self, path: str) -> int:
        try:
            self._ftp.voidcmd("TYPE I")
            size = self._ftp.size(path)
            return size if size is not None else 0
        except Exception:
            return 0

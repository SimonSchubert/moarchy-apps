# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

from collections.abc import Callable
import os
import traceback

import gi
gi.require_versions({'Adw': '1', 'Gdk': '4.0', 'Gio': '2.0', 'GLib': '2.0',
                     'Gtk': '4.0'})  # noqa: E402
from gi.repository import Adw, Gdk, Gio, GLib, Gtk

from .action import Action
from .close_dialog import CloseDialog
from .document import Document
from .file_info import FileInfo
from .file_filters import FILE_FILTERS_JSON, FILE_FILTERS_PDF
from .page_widget import PageWidget


# Translators: this suffix is automatically added to the file name before the
# `.pdf` extension on saving. Please keep it short to allow quick deletion.
# E.g., `Document.pdf` is suggested to be saved as `Document-redacted.pdf`
SUFFIX_REDACTED = _('-redacted')

# Translators: this suffix is automatically added to the file name before the
# `.json` extension on exporting redactions. Please keep it short to allow
# quick deletion. E.g., redactions of `Document.pdf` are suggested to be saved
# as `Document-redactions.json`
SUFFIX_REDACTIONS = _('-redactions')

# Translators: this suffix is automatically added to the file name before the
# `.pdf` extension on saving drafts. Please keep it short to allow quick
# deletion. E.g., `Document.pdf` is suggested to be saved as
# `Document-redaction-draft.pdf`
SUFFIX_DRAFT = _('-redaction-draft')


@Gtk.Template(resource_path='/page/codeberg/censor/Censor/window.ui')
class Window(Adw.ApplicationWindow):
    __gtype_name__ = 'Window'

    window_title = Gtk.Template.Child()
    status_page = Gtk.Template.Child()
    open_button = Gtk.Template.Child()
    undo_button = Gtk.Template.Child()
    redo_button = Gtk.Template.Child()
    page_spin_button = Gtk.Template.Child()

    dpi_values = [12, 14, 17, 20, 24, 29, 34, 40, 48, 57, 68, 81, 96, 114, 136,
                  161, 192, 228, 272, 323, 384, 457, 543, 646, 768]
    # DPI value of “normal zoom” (Ctrl+0)
    dpi_normal = 96

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.scrolled_window = Gtk.ScrolledWindow()

        # CTRL+Scrolling for zooming
        event_controller_scroll = Gtk.EventControllerScroll.new(
                Gtk.EventControllerScrollFlags.VERTICAL)
        event_controller_scroll.connect("scroll", self.on_scroll)
        self.scrolled_window.add_controller(event_controller_scroll)

        # 2-finger pinch to zoom
        event_controller_gesture = Gtk.GestureZoom.new()
        event_controller_gesture.connect("begin", self.on_gesture_begin)
        event_controller_gesture.connect("end", self.on_gesture_end)
        event_controller_gesture.connect("scale-changed", self.on_gesture_zoom)
        self.scrolled_window.add_controller(event_controller_gesture)

        self.page_spin_button.connect("value-changed",
                                      self.on_page_spin_button_value_change)
        self.page_spin_button.connect("query-tooltip",
                                      self.on_page_spin_button_query_tooltip)
        event_controller_key = Gtk.EventControllerKey()
        # Prevent Up/Down keys change pages unnaturally
        event_controller_key.connect("key-pressed",
                                     lambda c, keyval, *_:
                                     keyval in (Gdk.KEY_Up, Gdk.KEY_Down))
        self.page_spin_button.add_controller(event_controller_key)

        # Drop files for opening
        drop_formats = Gdk.ContentFormats.new_for_gtype(Gdk.FileList)
        drop_target = Gtk.DropTarget(formats=drop_formats,
                                     actions=Gdk.DragAction.COPY)
        drop_target.connect("enter", self.on_enter)
        drop_target.connect("leave", self.on_leave)
        drop_target.connect("drop", self.on_drop)
        self.add_controller(drop_target)

        self.file_info = None
        self._dpi = self.dpi_normal
        self.document_saved_once = False

        self.create_action('save', self.on_save, ['<Ctrl>s'], False)
        self.create_action('save-as', self.on_save_as, ['<Ctrl><Shift>s'],
                           False)
        self.create_action('save-draft', self.on_save_draft, ['<Ctrl>d'],
                           False)
        self.create_action('save-rasterized', self.on_save_rasterized,
                           ['<Ctrl>p'], False)
        self.create_action('import-redactions', self.on_import_redactions,
                           ['<Ctrl>i'], False)
        self.create_action('export-redactions', self.on_export_redactions,
                           ['<Ctrl>e'], False)
        self.create_action('undo', self.on_undo, ['<Ctrl>z'], False)
        self.create_action('redo', self.on_redo, ['<Ctrl><Shift>z'], False)
        self.create_action('zoom-in', self.on_zoom_in, ['<Ctrl>plus', 'plus'],
                           False)
        self.create_action('zoom-out', self.on_zoom_out,
                           ['<Ctrl>minus', 'minus'], False)
        self.create_action('zoom-normal', self.on_zoom_normal, ['<Ctrl>0'],
                           False)
        self.create_action('zoom-real', self.on_zoom_real, ['<Ctrl>1'], False)
        self.create_action('page-previous', self.on_page_previous,
                           ['<Ctrl>Page_Up', 'p'], False)
        self.create_action('page-next', self.on_page_next,
                           ['<Ctrl>Page_Down', 'n'], False)
        self.create_action('fullscreen-toggle', self.on_fullscreen_toggle,
                           ['F11'], True)
        self.create_action('close', self.on_close, ['<Ctrl>w'], True)

        css_provider = Gtk.CssProvider()
        css_provider.load_from_resource(
            '/page/codeberg/censor/Censor/window.css')
        Gtk.StyleContext.add_provider_for_display(
            self.get_display(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )

    def open(self, file: Gio.File, page_number: int = 0):
        print("INFO: Opening file", file.get_path())
        try:
            self.file_info = FileInfo(file)
            self.document = Document(file.get_path())
            self.page_number = page_number
            self.undo_button.set_visible(True)
            self.redo_button.set_visible(True)
            self.page_spin_button.set_visible(True)
            self.page_spin_button.get_adjustment().set_upper(
                    len(self.document))
            for action in self.list_actions():
                self.lookup_action(action).set_enabled(True)
            self.update_window_title()
        except Exception as exception:
            if hasattr(self, 'document'):
                self.alert(exception, _("Opening Document Failed"))
            else:
                try:
                    self.window_title.set_title(self.file_info.name)
                    self.window_title.set_subtitle(self.file_info.directory)
                except Exception:
                    pass
                self.status_page.set_title(_("Opening Document Failed"))
                self.status_page.set_description(str(exception))
                self.status_page.set_icon_name("dialog-error-symbolic")
                self.open_button.set_label(_("Open Another File…"))

    def save(self, file: Gio.File):
        print("INFO: Saving document", file.get_path())
        try:
            self.document.save(file.get_path())
        except Warning as warning:
            self.alert(warning, _("Warning"))
            self.open(file, page_number=self.page_number)
            self.document_saved_once = True
        except Exception as exception:
            self.alert(exception, _("Saving Document Failed"))
        else:
            self.open(file, page_number=self.page_number)
            self.document_saved_once = True

    def save_draft(self, file):
        print("INFO: Saving draft", file.get_path())
        try:
            try:
                self.document.save_draft(file.get_path())
            except Warning as warning:
                self.alert(warning, _("Warning"))
            # TODO: open draft, but keep history, following not working
            # history = self.document._history
            # self.open(file, page_number=self.page_number)
            # self.document._history = history
        except Exception as exception:
            self.alert(exception, _("Saving Draft Failed"))

    def save_rasterized(self, file):
        print("INFO: Saving rasterized", file.get_path())
        try:
            try:
                self.document.save_rasterized(file.get_path())
            except Warning as warning:
                self.alert(warning, _("Warning"))
            self.open(file, page_number=self.page_number)
            self.document_saved_once = True
        except Exception as exception:
            self.alert(exception, _("Saving Rasterized Document Failed"))

    def import_redactions(self, file):
        print("INFO: Importing redactions", file.get_path())
        try:
            try:
                self.document.import_redactions(file.get_path())
            except Warning as warning:
                self.alert(warning, _("Warning"))
            self.page_widget.area_redactions.queue_draw()
            self.update_window_title()
        except Exception as exception:
            self.alert(exception, _("Importing Redactions Failed"))

    def export_redactions(self, file):
        print("INFO: Exporting redactions", file.get_path())
        try:
            try:
                self.document.export_redactions(
                    file.get_path(),
                    creator=self.get_application().get_application_id(),
                    creator_version=self.get_application().get_version())
            except Warning as warning:
                self.alert(warning, _("Warning"))
        except Exception as exception:
            self.alert(exception, _("Exporting Redactions Failed"))

    @property
    def page_number(self) -> int:
        return self._page_number

    @page_number.setter
    def page_number(self, value: int) -> None:
        if not hasattr(self, "page_widget"):
            self.page_widget = PageWidget(perform=self.perform)
            self.scrolled_window.set_child(self.page_widget)
            self.get_content().set_content(self.scrolled_window)
        self.page_widget.page = self.document[value]
        self.page_spin_button.set_value(value + 1)
        self._page_number = value

    @property
    def dpi(self) -> int | float:
        return self._dpi

    @dpi.setter
    def dpi(self, value: int | float) -> None:
        if not hasattr(self, "page_widget"):
            return
        self.page_widget.dpi = value
        self._dpi = value

    def on_page_previous(self, *args) -> bool:
        if self.page_number == 0:
            return False
        self.page_number -= 1
        return True

    def on_page_next(self, *args) -> bool:
        if self.page_number == len(self.document) - 1:
            return False
        self.page_number += 1
        return True

    def on_zoom_in(self, *args):
        for dpi in self.dpi_values:
            if dpi > self.dpi + 1:
                self.dpi = dpi
                return

    def on_zoom_out(self, *args):
        for dpi in reversed(self.dpi_values):
            if dpi < self.dpi - 1:
                self.dpi = dpi
                return

    def on_zoom_normal(self, *args):
        self.dpi = self.dpi_normal

    def on_zoom_real(self, *args):
        try:
            display = self.get_display()
            message = _(
                    'Could not determine screen dot density: {obj} not found')
            if display is None:
                raise RuntimeError(message.format(obj='Gdk.Display'))
            surface = self.get_surface()
            if surface is None:
                raise RuntimeError(message.format(obj='Gdk.Surface'))
            monitor = display.get_monitor_at_surface(surface)
            if monitor is None:
                raise RuntimeError(message.format(obj='Gdk.Monitor'))
            geometry = monitor.get_geometry()
            dpi_x = geometry.width * 25.4 / monitor.get_width_mm()
            dpi_y = geometry.height * 25.4 / monitor.get_height_mm()
            self.dpi = (geometry.width * dpi_x + geometry.height * dpi_y) / (
                    geometry.width + geometry.height)
        except Exception as exception:
            self.alert(exception, _('Zooming to Original Size Failed'))

    def on_fullscreen_toggle(self, *args):
        if self.is_fullscreen():
            self.unfullscreen()
        else:
            self.fullscreen()

    def perform(self, action: Action) -> bool:
        if self.document.perform(action):
            self.page_widget.area_redactions.queue_draw()
            self.update_window_title()
            return True
        return False

    def on_undo(self, *args) -> bool:
        if not hasattr(self, "document"):
            return
        if self.document.undo():
            self.page_widget.area_redactions.queue_draw()
            self.update_window_title()
            return True
        return False

    def on_redo(self, *args) -> bool:
        if not hasattr(self, "document"):
            return
        if self.document.redo():
            self.page_widget.area_redactions.queue_draw()
            self.update_window_title()
            return True
        return False

    def update_window_title(self):
        title = self.file_info.name
        subtitle = self.file_info.directory
        if self.document.modified:
            title = "• " + title
        undo_action = self.lookup_action("undo")
        undo_action.set_enabled(self.document.modified)
        self.undo_button.set_sensitive(self.document.modified)
        redo_action = self.lookup_action("redo")
        redo_action.set_enabled(self.document.has_future)
        self.redo_button.set_sensitive(self.document.has_future)
        self.window_title.set_title(title)
        self.window_title.set_subtitle(subtitle)

    def on_save(self, *args):
        if not hasattr(self, "document"):
            return
        if not self.document_saved_once:
            return self.on_save_as(self, *args)
        self.save(self.file_info.file)

    def on_save_as(self, *args):
        dialog = Gtk.FileDialog()
        dialog.set_filters(FILE_FILTERS_PDF)
        path_no_suffix, ext = os.path.splitext(self.file_info.path)
        for suffix in [SUFFIX_REDACTED, SUFFIX_DRAFT]:
            path_no_suffix = path_no_suffix.removesuffix(suffix)
        initial_path = f'{path_no_suffix}{SUFFIX_REDACTED}.pdf'
        dialog.set_initial_file(Gio.File.new_for_path(initial_path))
        dialog.save(self, None, self.on_save_as_dialog)

    def on_save_as_dialog(self, dialog, result):
        file = dialog.save_finish(result)
        self.save(file)

    def on_save_draft(self, *args):
        dialog = Gtk.FileDialog()
        dialog.set_filters(FILE_FILTERS_PDF)
        path_no_suffix, ext = os.path.splitext(self.file_info.path)
        for suffix in [SUFFIX_REDACTED, SUFFIX_DRAFT]:
            path_no_suffix = path_no_suffix.removesuffix(suffix)
        initial_path = f'{path_no_suffix}{SUFFIX_DRAFT}.pdf'
        dialog.set_initial_file(Gio.File.new_for_path(initial_path))
        dialog.save(self, None, self.on_save_draft_dialog)

    def on_save_draft_dialog(self, dialog, result):
        file = dialog.save_finish(result)
        self.save_draft(file)

    def on_save_rasterized(self, *args):
        dialog = Gtk.FileDialog()
        dialog.set_filters(FILE_FILTERS_PDF)
        path_no_suffix, ext = os.path.splitext(self.file_info.path)
        for suffix in [SUFFIX_REDACTED, SUFFIX_DRAFT]:
            path_no_suffix = path_no_suffix.removesuffix(suffix)
        initial_path = f'{path_no_suffix}{SUFFIX_REDACTED}.pdf'
        dialog.set_initial_file(Gio.File.new_for_path(initial_path))
        dialog.save(self, None, self.on_save_rasterized_dialog)

    def on_save_rasterized_dialog(self, dialog, result):
        file = dialog.save_finish(result)
        self.save_rasterized(file)

    def on_import_redactions(self, *args):
        dialog = Gtk.FileDialog()
        dialog.set_filters(FILE_FILTERS_JSON)
        dialog.open_multiple(self, None, self.on_import_redactions_dialog)

    def on_import_redactions_dialog(self, dialog, result):
        files = dialog.open_multiple_finish(result)
        for file in files:
            self.import_redactions(file)

    def on_export_redactions(self, *args):
        dialog = Gtk.FileDialog()
        dialog.set_filters(FILE_FILTERS_JSON)
        path_no_suffix, ext = os.path.splitext(self.file_info.path)
        for suffix in [SUFFIX_REDACTED, SUFFIX_DRAFT]:
            path_no_suffix = path_no_suffix.removesuffix(suffix)
        initial_path = f'{path_no_suffix}{SUFFIX_REDACTIONS}.json'
        dialog.set_initial_file(Gio.File.new_for_path(initial_path))
        dialog.save(self, None, self.on_export_redactions_dialog)

    def on_export_redactions_dialog(self, dialog, result):
        file = dialog.save_finish(result)
        self.export_redactions(file)

    def on_close(self, *_):
        self.close()

    def do_close_request(self):
        if not hasattr(self, 'document') or not self.document.modified:
            return False
        dialog = CloseDialog()
        dialog.choose(self, None, self.on_close_request_dialog)
        return True

    def on_close_request_dialog(self, dialog, result):
        response = dialog.choose_finish(result)
        if response == "close":
            self.destroy()
        if response == "save":
            self.on_save()

    def on_scroll(self, controller, dx, dy):
        if (not controller.get_current_event_state()
                & Gdk.ModifierType.CONTROL_MASK):
            return False
        alpha = 20 if abs(dy) == 1 else 200
        if dy > 0:
            self.dpi = max(self.dpi * (1 - dy / alpha), self.dpi_values[0])
        else:
            self.dpi = min(self.dpi / (1 + dy / alpha), self.dpi_values[-1])
        return True

    def on_gesture_begin(self, controller, *_):
        self._dpi_gesture_zoom_orig = self.dpi

    def on_gesture_zoom(self, controller, scale_delta):
        if not hasattr(self, '_dpi_gesture_zoom_orig'):
            self._dpi_gesture_zoom_orig = self.dpi
        self.dpi = min(max(self._dpi_gesture_zoom_orig * scale_delta,
                           self.dpi_values[0]),
                       self.dpi_values[-1])

    def on_gesture_end(self, controller, *_):
        if hasattr(self, '_dpi_gesture_zoom_orig'):
            del self._dpi_gesture_zoom_orig

    def on_page_spin_button_value_change(self, spin_button) -> bool:
        self.page_number = int(spin_button.get_value()) - 1
        return True

    def on_page_spin_button_query_tooltip(self, widget, x, y, keyboard_mode,
                                          tooltip) -> bool:
        tooltip.set_text(_('Page {page_number} of {number_of_pages}').format(
                page_number=self.page_number + 1,
                number_of_pages=len(self.document)))
        return True

    def on_enter(self, target, x, y):
        self.get_content().get_content().add_css_class("overlay-drag-area")
        return Gdk.DragAction.COPY

    def on_leave(self, target):
        self.get_content().get_content().remove_css_class("overlay-drag-area")

    def on_drop(self, target, file_list: Gdk.FileList, x, y):
        files = file_list.get_files()
        self.get_application().open(files=files, hint="dropped")

    def create_action(self, name: str, callback: Callable,
                      accels: list[str] = [], enabled: bool = True):
        """Create a window action

        Parameters
        ----------
        name: the name of the action (without prefix)
        callback: the function to be called when the action is activated
        accels: a list of accelerators (keyboard shortcuts)
        enabled: whether the action should be enabled on creation
        """
        action = Gio.SimpleAction.new(name)
        action.connect("activate", callback)
        action.set_enabled(enabled)
        self.add_action(action)
        self.get_application().set_accels_for_action(f"win.{name}", accels)

    def alert(self, exception, heading=None):
        show_dialog = True
        if isinstance(exception, GLib.GError):
            message = exception.message
            if exception.code in {
                    Gtk.DialogError.CANCELLED,
                    Gtk.DialogError.DISMISSED}:
                show_dialog = False
        else:
            message = str(exception)
        if heading is None:
            heading = message
            body = None
            print(f'WARNING: {message}')
        else:
            body = message
            print(f'WARNING: {heading}: {message}')
        if show_dialog:
            print(traceback.format_exc())
            dialog = Adw.AlertDialog(heading=heading, body=body)
            dialog.add_response('dismiss', _('Dismiss'))
            dialog.set_close_response('dismiss')
            dialog.present(self)

# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import datetime
import gettext
import json
import pathlib
import tempfile

import pymupdf

from .action import Action
from .exceptions import format_exception
from .history import History
from .page import Page
from .pymupdf_helpers import (
        clean_page, add_redaction_annotations, get_redactions,
        redact_annotations, redact_links, redact_widgets, apply_redactions,
        draw_redactions, sanitize_safer, sanitize_standard,
        validate_redactions)
from .redaction import Redaction
from .warnings import RedactionWarning, SanitizationWarning


class Document:
    def __init__(self, path: str | pathlib.Path | pymupdf.Document) -> None:
        if isinstance(path, pymupdf.Document):
            mupdf_document = path
            if mupdf_document.name is None:
                self._path = None
            else:
                self._path = pathlib.Path(mupdf_document.name)
        else:
            try:
                mupdf_document = pymupdf.Document(path)
            except Exception as exception:
                raise RuntimeError(
                        _('Failed to open document from path: {error}'
                          ).format(error=format_exception(exception)))
            self._path = pathlib.Path(path)
        try:
            if mupdf_document.is_pdf:
                stream = mupdf_document.tobytes()
            else:
                stream = mupdf_document.convert_to_pdf()
        except Exception as exception:
            raise RuntimeError(
                    _('Failed to write document bytes to stream: {error}'
                      ).format(error=format_exception(exception)))
        try:
            self.mupdf_document = pymupdf.Document(stream=stream)
        except Exception as exception:
            raise RuntimeError(
                    _('Failed to open document from bytes stream: {error}'
                      ).format(error=format_exception(exception)))
        self.pages = [Page(mupdf_page) for mupdf_page in self.mupdf_document]
        self._history = History()
        # Dummy redaction annotations for failing to open broken documents,
        # see https://codeberg.org/censor/Censor/issues/198
        for mupdf_page in pymupdf.Document(stream=stream):
            try:
                mupdf_page.add_redact_annot(pymupdf.Rect(0, 0, 1, 1))
            except Exception as exception:
                raise RuntimeError(
                        _('Failed to add test redactions on page\xa0{page}: '
                          + '{error}').format(
                              page=mupdf_page.number,
                              error=format_exception(exception)))
            try:
                apply_redactions(
                        mupdf_page,
                        images=pymupdf.PDF_REDACT_IMAGE_PIXELS,
                        graphics=pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED,
                        text=pymupdf.PDF_REDACT_TEXT_REMOVE)
            except Exception as exception:
                raise RuntimeError(
                        _('Failed to apply test redactions on page \xa0{page}:'
                          + ' {error}').format(
                              page=mupdf_page.number,
                              error=format_exception(exception)))
        redactions = []
        for page in self.pages:
            redactions.extend(get_redactions(page.mupdf_page, page))
            for annotation in page.mupdf_page.annots(
                    types=[pymupdf.PDF_ANNOT_REDACT]):
                page.mupdf_page.delete_annot(annotation)
        if redactions:
            self.perform(Action(None, redactions))

    def __getitem__(self, key: int | slice) -> Page | list[Page]:
        "Return page(s) for page number(s)"
        return self.pages[key]

    def __len__(self) -> int:
        "Return number of pages"
        return len(self.pages)

    @property
    def maximum_height(self) -> int | float:
        "Maximum page height in pixels"
        return max(p.height for p in self)

    @property
    def maximum_width(self) -> int | float:
        "Maximum page width in pixels"
        return max(p.width for p in self)

    def get_maximum_height(self, dpi: int | float) -> int | float:
        "Maximum page height in pixels for given dot density in dpi"
        return max(p.get_height(dpi) for p in self)

    def get_maximum_width(self, dpi: int | float) -> int | float:
        "Maximum page width in pixels for given dot density in dpi"
        return max(p.get_width(dpi) for p in self)

    @property
    def title(self) -> str:
        "Title from metadata"
        return self.mupdf_document.metadata['title']

    @property
    def path(self) -> pathlib.Path:
        "File path"
        return self._path

    @property
    def basename(self) -> str:
        "File name"
        return self._path.name

    @property
    def modified(self) -> bool:
        "Whether the document is modified"
        return bool(self._history)

    @property
    def has_future(self) -> bool:
        "Whether the document has future modifications"
        return bool(self._history.future)

    def perform(self, action: Action) -> bool:
        "Perform an action of redaction (add/modify/delete)"
        if self._perform(action):
            self._history.append(action)
            return True
        return False

    def undo(self) -> bool:
        "Undo last action"
        action = self._history.undo()
        if action is None:
            return False
        if not self._perform(action.reversed()):
            self._history.redo()
            return False
        return True

    def redo(self) -> bool:
        action = self._history.redo()
        if action is None:
            return False
        if not self._perform(action):
            self._history.undo()
            return False
        return True

    def _perform(self, action: Action) -> bool:
        def _add(redaction):
            if isinstance(redaction, Redaction):
                redaction.page.append(redaction)
                print("INFO: added", redaction)

        def _delete(redaction):
            if isinstance(redaction, Redaction):
                redaction.page.remove(redaction)
                print("INFO: removed", redaction)

        if type(action.after) is list:
            for after in action.after:
                _add(after)
        else:
            _add(action.after)
        if type(action.before) is list:
            for before in action.before:
                _delete(before)
        else:
            _delete(action.before)
        return True

    def save(self, path: str | pathlib.Path, garbage: int = 3,
             clean: bool = True, deflate: bool = True,
             deflate_images: bool = True, deflate_fonts: bool = True, **kwargs
             ) -> None:
        mupdf_document = pymupdf.Document(stream=self.mupdf_document.tobytes())
        warnings = []
        redactions_total = {}
        for i, page in enumerate(self):
            mupdf_page = mupdf_document[i]
            try:
                clean_page(mupdf_page)
            except SanitizationWarning as warning:
                warnings.append(str(warning))
            # Add redactions without color (let Censor draw them later),
            # include adding outside-page redactions
            try:
                add_redaction_annotations(mupdf_page, redactions=list(page),
                                          with_color=False,
                                          add_outside_page_redactions=True)
            except RedactionWarning as warning:
                warnings.append(str(warning))
            # Save redactions for later validation
            redactions_total[i] = get_redactions(mupdf_page)
            # Perform additional redactions before letting PyMuPDF apply the
            # redactions
            try:
                redact_annotations(mupdf_page)
            except RedactionWarning as warning:
                warnings.append(str(warning))
            try:
                redact_links(mupdf_page, redactions_total[i])
            except RedactionWarning as warning:
                warnings.append(str(warning))
            try:
                redact_widgets(mupdf_page, redactions_total[i])
            except RedactionWarning as warning:
                warnings.append(str(warning))
            # Redact images with cropping, and graphics and text characters
            # when touched by redaction rectangles
            try:
                apply_redactions(
                        mupdf_page,
                        images=pymupdf.PDF_REDACT_IMAGE_PIXELS,
                        graphics=pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED,
                        text=pymupdf.PDF_REDACT_TEXT_REMOVE)
            except RedactionWarning as warning:
                warnings.append(str(warning))
            # Draw redaction rectangles
            try:
                draw_redactions(mupdf_page, list(page))
            except RedactionWarning as warning:
                warnings.append(str(warning))
        # Safer sanitization with copying pages. This removes also metadata.
        # If this fails, fall back to standard sanitization.
        try:
            mupdf_document = sanitize_safer(mupdf_document,
                                            keep_links=True,
                                            keep_annotations=True,
                                            keep_widgets=True)
        except SanitizationWarning as warning:
            warnings.append(str(warning))
        # Standard sanitization
        try:
            sanitize_standard(mupdf_document,
                              remove_attached_files=True,
                              clean_pages=True,
                              remove_embedded_files=True,
                              remove_hidden_text=True,
                              remove_javascript=True,
                              remove_metadata=True,
                              # Links should be kept by default
                              # TODO: add setting for links removal
                              remove_links=False,
                              # TODO: maybe add setting for response removal?
                              reset_fields=False,
                              reset_responses=True,
                              remove_thumbnails=True,
                              remove_xml_metadata=True)
        except SanitizationWarning as warning:
            warnings.append(str(warning))
        # A temporary file is used to fix PyMuPDF ValueError "save to original
        # must be incremental",
        # see https://codeberg.org/censor/Censor/issues/78
        # and https://codeberg.org/censor/Censor/issues/90
        with tempfile.TemporaryFile('wb+') as tmp:
            # TODO: investigate options for saving
            # Garbage is collected for safer text redaction, see note at
            # https://pymupdf.readthedocs.io/en/latest/page.html#Page.apply_redactions
            tmp.write(mupdf_document.tobytes(garbage=garbage, clean=clean,
                                             deflate=deflate,
                                             deflate_images=deflate_images,
                                             deflate_fonts=deflate_fonts,
                                             **kwargs))
            tmp.flush()
            tmp.seek(0)
            with open(path, 'wb') as file:
                file.write(tmp.read())
        # Validate redactions to warn user if some redactions were not applied
        # properly, see https://codeberg.org/censor/Censor/issues/134 and
        # https://codeberg.org/censor/Censor/issues/158
        for i in range(len(mupdf_document)):
            try:
                validate_redactions(
                        mupdf_document[i], redactions_total[i],
                        images=pymupdf.PDF_REDACT_IMAGE_PIXELS,
                        graphics=pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED,
                        text=pymupdf.PDF_REDACT_TEXT_REMOVE,
                        annotations=True, links=True, widgets=True)
            except RedactionWarning as warning:
                warnings.append(str(warning))
        if len(warnings) != 0:
            raise UserWarning('\n'.join(warnings))

    def save_draft(self, path: str | pathlib.Path, garbage: int = 3,
                   clean: bool = True, deflate: bool = True,
                   deflate_images: bool = True, deflate_fonts: bool = True,
                   **kwargs
                   ) -> None:
        warnings = []
        mupdf_document = pymupdf.Document(stream=self.mupdf_document.tobytes())
        for i, page in enumerate(self):
            mupdf_page = mupdf_document[i]
            # Add redactions with color, do not add outside-page redactions
            try:
                add_redaction_annotations(mupdf_page, redactions=page,
                                          with_color=True,
                                          add_outside_page_redactions=False)
            except RedactionWarning as warning:
                warnings.append(str(warning))
        # A temporary file is used to fix PyMuPDF ValueError "save to original
        # must be incremental",
        # see https://codeberg.org/censor/Censor/issues/78
        # and https://codeberg.org/censor/Censor/issues/90
        with tempfile.TemporaryFile('wb+') as tmp:
            # TODO: investigate options for saving
            # Garbage is collected for safer text redaction, see note at
            # https://pymupdf.readthedocs.io/en/latest/page.html#Page.apply_redactions
            tmp.write(mupdf_document.tobytes(garbage=garbage, clean=clean,
                                             deflate=deflate,
                                             deflate_images=deflate_images,
                                             deflate_fonts=deflate_fonts,
                                             **kwargs))
            tmp.flush()
            tmp.seek(0)
            with open(path, 'wb') as file:
                file.write(tmp.read())
        if len(warnings) != 0:
            raise UserWarning('\n'.join(warnings))

    def save_rasterized(self, path: str | pathlib.Path, garbage: int = 3,
                        clean: bool = True, deflate: bool = True,
                        deflate_images: bool = True,
                        deflate_fonts: bool = True, **kwargs) -> None:
        warnings = []
        mupdf_document = pymupdf.Document(stream=self.mupdf_document.tobytes())
        mupdf_document_rasterized = pymupdf.Document()
        for i, page in enumerate(self):
            mupdf_page = mupdf_document[i]
            # Add redactions without color (let Censor draw them later),
            # include adding outside-page redactions
            try:
                add_redaction_annotations(mupdf_page, redactions=page,
                                          with_color=False,
                                          add_outside_page_redactions=True)
            except RedactionWarning as warning:
                warnings.append(str(warning))
            # Perform additional redactions before drawing the rectangles, in
            # particular, annotations are drawn above the redaction rectangles
            try:
                redact_annotations(mupdf_page)
            except RedactionWarning as warning:
                warnings.append(str(warning))
            # Remove redaction annotations
            for annot in mupdf_page.annots(types=[pymupdf.PDF_ANNOT_REDACT]):
                mupdf_page.delete_annot(annot)
            # Draw redaction rectangles
            try:
                draw_redactions(mupdf_page, list(page))
            except RedactionWarning as warning:
                warnings.append(str(warning))
            # TODO: investigate options for Pixmap extraction (dpi, etc.),
            # potentially make it configurable in advanced settings
            pixmap = mupdf_page.get_pixmap(dpi=150)
            mupdf_page_rasterized = mupdf_document_rasterized.new_page(
                    width=mupdf_page.rect.width, height=mupdf_page.rect.height)
            mupdf_page_rasterized.insert_image(mupdf_page.rect, pixmap=pixmap)
        # A temporary file is used to fix PyMuPDF ValueError "save to original
        # must be incremental",
        # see https://codeberg.org/censor/Censor/issues/78
        # and https://codeberg.org/censor/Censor/issues/90
        with tempfile.TemporaryFile('wb+') as tmp:
            # TODO: investigate options for saving
            # Garbage is collected for safer text redaction, see note at
            # https://pymupdf.readthedocs.io/en/latest/page.html#Page.apply_redactions
            tmp.write(mupdf_document_rasterized.tobytes(
                garbage=garbage, clean=clean, deflate=deflate,
                deflate_images=deflate_images, deflate_fonts=deflate_fonts,
                **kwargs))
            tmp.flush()
            tmp.seek(0)
            with open(path, 'wb') as file:
                file.write(tmp.read())
        if len(warnings) != 0:
            raise UserWarning('\n'.join(warnings))

    def export_redactions(self, path: str | pathlib.Path,
                          creator: str = 'page.codeberg.censor.Censor',
                          creator_version: str | None = None,
                          created: str | None = None) -> None:
        data = {'creator': creator}
        if creator_version is not None:
            data['creator_version'] = creator_version
        if created is None:
            created = datetime.datetime.now().astimezone().isoformat(
                timespec='seconds')
        data['created'] = created
        data['redactions'] = []
        for i, page in enumerate(self):
            for redaction in page:
                data['redactions'].append({
                    'rect': [redaction.x0, redaction.y0,
                             redaction.x1, redaction.y1],
                    'page': i,
                    'color': redaction.color,
                })
        with open(path, 'w') as file:
            json.dump(data, file)

    def import_redactions(self, path: str | pathlib.Path) -> None:
        redactions = []
        count_redactions_without_page = 0
        try:
            with open(path, 'r') as file:
                data = json.load(file)
            for redaction in data['redactions']:
                if redaction['page'] >= len(self):
                    count_redactions_without_page += 1
                    continue
                page = self[redaction['page']]
                x0, y0, x1, y1 = redaction['rect']
                color = tuple(redaction.get('color', [0., 0., 0.]))
                redactions.append(Redaction(x0, y0, x1, y1, page=page,
                                            color=color))
        except Exception as exception:
            raise UserWarning(_(
                'Failed to import redactions from file “{file}”: {error}'
            ).format(file=pathlib.Path(path).name,
                     error=format_exception(exception)))
        if len(redactions) == 0:
            raise UserWarning(_(
                'Found no redactions to import in file “{file}”'
            ).format(file=pathlib.Path(path).name))
        try:
            self.perform(Action(None, redactions))
        except Exception as exception:
            raise UserWarning(_(
                'Failed to apply imported redactions from file “{file}”:'
                + ' {error}'
            ).format(file=pathlib.Path(path).name,
                     error=format_exception(exception)))
        if count_redactions_without_page > 0:
            raise UserWarning(gettext.ngettext(
                'Failed to import {count}\xa0redaction on missing pages'
                + ' from file “{file}”',
                'Failed to import {count}\xa0redactions on missing pages'
                + ' from file “{file}”',
                count_redactions_without_page
            ).format(count=count_redactions_without_page,
                     file=pathlib.Path(path).name))

    def __repr__(self) -> str:
        return repr(self.mupdf_document)

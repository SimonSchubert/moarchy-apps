# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

import math

import gi
gi.require_versions({'Gdk': '4.0', 'Rsvg': '2.0'})  # noqa: E402
from gi.repository import Gdk, Rsvg

import pymupdf


GDK_INT_MIN = -2147483648   # C minimum integer number, used by Cairo/Gdk
GDK_INT_MAX = 2147483647    # C maximum integer number, used by Cairo/Gdk
GDK_MIN_INF_RECT = GDK_INT_MIN // 2
GDK_MAX_INF_RECT = GDK_INT_MAX // 2


class Rectangle:
    def __init__(self,
                 x0: int | float | Rectangle | pymupdf.Rect = 0,
                 y0: int | float = 0,
                 x1: int | float | None = None,
                 y1: int | float | None = None):
        if isinstance(x0, Rectangle):
            self._x0 = x0._x0
            self._x1 = x0._x1
            self._y0 = x0._y0
            self._y1 = x0._y1
            return
        if isinstance(x0, pymupdf.Rect):
            def convert(x):
                if math.isclose(x, pymupdf.FZ_MIN_INF_RECT, rel_tol=0,
                                abs_tol=0.001):
                    return -math.inf
                if math.isclose(x, pymupdf.FZ_MAX_INF_RECT, rel_tol=0,
                                abs_tol=0.001):
                    return math.inf
                if math.isclose(x, -pymupdf.FZ_MAX_INF_RECT, rel_tol=0,
                                abs_tol=0.001):
                    return -math.inf
                if math.isclose(x, -pymupdf.FZ_MIN_INF_RECT, rel_tol=0,
                                abs_tol=0.001):
                    return math.inf
                return x
            self._x0 = convert(x0.x0)
            self._y0 = convert(x0.y0)
            self._x1 = convert(x0.x1)
            self._y1 = convert(x0.y1)
            return
        if x1 is None:
            self._x0 = self._x1 = x0
        elif x0 < x1:
            self._x0 = x0
            self._x1 = x1
        else:
            self._x0 = x1
            self._x1 = x0
        if y1 is None:
            self._y0 = self._y1 = y0
        elif y0 < y1:
            self._y0 = y0
            self._y1 = y1
        else:
            self._y0 = y1
            self._y1 = y0

    @property
    def x0(self):
        return self._x0

    @property
    def x1(self):
        return self._x1

    @property
    def y0(self):
        return self._y0

    @property
    def y1(self):
        return self._y1

    @property
    def x(self):
        return self._x0

    @property
    def y(self):
        return self._y0

    @property
    def width(self):
        return self._x1 - self._x0

    @property
    def height(self):
        return self._y1 - self._y0

    @property
    def gdk_rectangle(self) -> Gdk.Rectangle:
        rectangle = Gdk.Rectangle()

        def convert_xy(x):
            if math.isinf(x):
                if x < 0:
                    return GDK_MIN_INF_RECT
                return GDK_MAX_INF_RECT
            return math.floor(x + 0.5)

        rectangle.x = convert_xy(self._x0)
        rectangle.y = convert_xy(self._y0)

        def convert_wh(x):
            if math.isinf(x):
                return GDK_INT_MAX
            return math.floor(x + 0.5)

        rectangle.width = convert_wh(self.width)
        rectangle.height = convert_wh(self.height)
        return rectangle

    @property
    def rsvg_rectangle(self) -> Rsvg.Rectangle:
        rectangle = Rsvg.Rectangle()
        rectangle.x = self._x0
        rectangle.y = self._y0
        rectangle.width = self.width
        rectangle.height = self.height
        return rectangle

    @property
    def pymupdf_rect(self) -> pymupdf.Rect:
        def convert(x):
            if math.isinf(x):
                if x < 0:
                    return pymupdf.FZ_MIN_INF_RECT
                return pymupdf.FZ_MAX_INF_RECT
            return x
        return pymupdf.Rect(convert(self._x0), convert(self._y0),
                            convert(self._x1), convert(self._y1))

    def contains(self, other: Rectangle) -> bool:
        return (self._x0 <= other._x0 and other._x1 <= self._x1
                and self._y0 <= other._y0 and other._y1 <= self._y1)

    def isclose(self, other: Rectangle, *, rel_tol: float = 0.0,
                abs_tol: float = 0.001) -> bool:
        return all(math.isclose(s, o, rel_tol=rel_tol, abs_tol=abs_tol)
                   for s, o in ((self._x0, other._x0),
                                (self._x1, other._x1),
                                (self._y0, other._y0),
                                (self._y1, other._y1)))

    def intersection(self, other: Rectangle) -> Rectangle | None:
        x0 = max(self._x0, other._x0)
        x1 = min(self._x1, other._x1)
        y0 = max(self._y0, other._y0)
        y1 = min(self._y1, other._y1)
        if x1 < x0 or y1 < y0:
            return None
        rectangle = self.__class__(self)
        rectangle._x0 = x0
        rectangle._x1 = x1
        rectangle._y0 = y0
        rectangle._y1 = y1
        return rectangle

    def intersects(self, other: Rectangle) -> bool:
        return (self._x0 <= other._x1 and other._x0 <= self._x1
                and self._y0 <= other._y1 and other._y0 <= self._y1)

    def overlaps(self, other: Rectangle) -> bool:
        """intersects truly excluding touching only with borders"""
        return (self._x0 < other._x1 and other._x0 < self._x1
                and self._y0 < other._y1 and other._y0 < self._y1)

    def overlaps_or_contains(self, other: Rectangle) -> bool:
        """intersects excluding touching only with borders or contains other"""
        return self.overlaps(other) or self.contains(other)

    def __and__(self, other: Rectangle) -> Rectangle | None:
        return self.intersection(other)

    def __or__(self, other: Rectangle) -> Rectangle:
        x0 = min(self._x0, other._x0)
        x1 = max(self._x1, other._x1)
        y0 = min(self._y0, other._y0)
        y1 = max(self._y1, other._y1)
        rectangle = self.__class__(self)
        rectangle._x0 = x0
        rectangle._x1 = x1
        rectangle._y0 = y0
        rectangle._y1 = y1
        return rectangle

    def __contains__(self, other: Rectangle) -> bool:
        return self.contains(other)

    def __eq__(self, other: Rectangle) -> bool:
        return (self._x0 == other._x0 and self._y0 == other._y0
                and self._x1 == other._x1 and self._y1 == other._y1)

    def __repr__(self):
        return f'Rectangle({self._x0}, {self._y0}, {self._x1}, {self._y1})'

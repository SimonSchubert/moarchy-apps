# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

from collections.abc import Callable
import os

import gi
gi.require_versions({'Adw': '1', 'Gio': '2.0', 'Gtk': '4.0'})  # noqa: E402
from gi.repository import Adw, Gio, Gtk

from .about_dialog import AboutDialog
from .file_info import FileInfo
from .file_filters import FILE_FILTER_JSON, FILE_FILTERS_PDF
from .window import Window


class Application(Adw.Application):
    def __init__(self, version):
        app_id_default = 'page.codeberg.censor.Censor'
        app_id = os.environ.get("FLATPAK_ID", app_id_default)
        if app_id != app_id_default:
            version += '-' + app_id.removeprefix(app_id_default + '.').lower()
        super().__init__(application_id=app_id,
                         flags=Gio.ApplicationFlags.HANDLES_OPEN,
                         resource_base_path='/page/codeberg/censor/Censor',
                         version=version)
        self.create_action('open', self.on_open, ['<Ctrl>o'])
        self.create_action('quit', self.on_quit, ['<Ctrl>q'])
        self.create_action('about', self.on_about)

    def do_activate(self, files=[]):
        window = self.get_active_window()
        if window is None:
            window = Window(application=self)
        window.present()

    def do_open(self, files, n_files, hint):
        window_active = self.get_active_window()
        infos = [FileInfo(file) for file in files]
        # If all files are JSON and active window with file, import redactions
        if (window_active is not None
                and hasattr(window_active, 'document')
                and all(info.match(FILE_FILTER_JSON) for info in infos)):
            for file in files:
                window_active.import_redactions(file)
            window_active.present()
            return
        windows_without_file = [window for window in self.get_windows()
                                if not hasattr(window, 'document')]
        for file, info in zip(files, infos):
            # If window for file exists already, open this window,
            # else, open file in active window if it is without file,
            # else, open file in another window without file if there is,
            # else, open file in a new window
            windows_for_file = [
                window for window in self.get_windows()
                if window.file_info is not None
                and window.file_info.host_path == info.host_path
            ]
            if len(windows_for_file) > 0:
                window = windows_for_file[0]
            else:
                if window_active in windows_without_file:
                    window = window_active
                    windows_without_file.remove(window)
                elif len(windows_without_file) > 0:
                    window = windows_without_file.pop()
                else:
                    window = Window(application=self)
                window.open(file)
            window.present()

    def on_open(self, *_):
        dialog = Gtk.FileDialog()
        dialog.set_filters(FILE_FILTERS_PDF)
        window = self.get_active_window()
        dialog.open_multiple(window, None, self.on_open_dialog)

    def on_open_dialog(self, dialog, result):
        files = dialog.open_multiple_finish(result)
        self.open(files=files, hint="dialog")

    def on_quit(self, *_):
        no_window = True
        for window in self.get_windows():
            no_window = False
            window.close()
        if no_window:
            super().quit()

    def on_about(self, *_):
        about_dialog = AboutDialog(self.get_version())
        about_dialog.present(self.get_active_window())

    def create_action(self, name: str, callback: Callable,
                      accels: list[str] = []):
        """Create a application action

        Parameters
        ----------
        name: the name of the action (without prefix)
        callback: the function to be called when the action is activated
        accels: a list of accelerators (keyboard shortcuts)
        """
        action = Gio.SimpleAction.new(name)
        action.connect("activate", callback)
        self.add_action(action)
        self.set_accels_for_action(f"app.{name}", accels)

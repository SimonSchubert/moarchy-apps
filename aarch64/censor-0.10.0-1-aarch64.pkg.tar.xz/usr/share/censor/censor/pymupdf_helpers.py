# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2026 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import gettext
import traceback

import pymupdf

from .page import Page
from .rectangle import Rectangle
from .redaction import Redaction
from .warnings import RedactionWarning, SanitizationWarning


def clean_page(mupdf_page: pymupdf.Page) -> None:
    try:
        mupdf_page.clean_contents(sanitize=True)
    except Exception:
        print(traceback.format_exc())
        try:
            mupdf_page.clean_contents(sanitize=False)
            raise SanitizationWarning(
                    _('Failed to clean page\xa0{number} with sanitization.'
                      ).format(number=mupdf_page.number + 1))
        except Exception as exception:
            if isinstance(exception, SanitizationWarning):
                raise exception
            print(traceback.format_exc())
            raise SanitizationWarning(
                    _('Failed to clean page\xa0{number} with and without '
                      + 'sanitization.'
                      ).format(number=mupdf_page.number + 1))


def add_redaction_annotations(mupdf_page: pymupdf.Page,
                              redactions: list[Redaction],
                              with_color: bool = False,
                              add_outside_page_redactions: bool = True
                              ) -> None:
    """Add PDF redaction annotations

    Parameters
    ----------
    mupdf_page: the page
    redactions: the list of redactions
    with_color: whether the redactions should be added with fill color
    add_outside_page_redactions: whether additional redaction annotations
        outside of the page’s borders should be added
    """
    try:
        derotation_matrix = _derotation_matrix(mupdf_page)
        for redaction in redactions:
            # TODO: custom annotation rendering, see
            # https://codeberg.org/censor/Censor/issues/11
            redaction_rotated = redaction.pymupdf_rect.transform(
                    derotation_matrix)
            fill = redaction.color if with_color else False
            mupdf_page.add_redact_annot(redaction_rotated, fill=fill)
        # Workaround for elements not redacted if located outside of page,
        # see https://codeberg.org/censor/Censor/issues/121. Alternatively,
        # there is `mupdf_page.clip_to_rect(mupdf_page.bound())`, but it did
        # not remove content outside of page borders reliably
        if add_outside_page_redactions:
            inf_neg = pymupdf.FZ_MIN_INF_RECT
            inf_pos = pymupdf.FZ_MAX_INF_RECT
            x0, y0, x1, y1 = pymupdf.Rect(mupdf_page.rect).transform(
                    derotation_matrix)
            delta = 1e-9
            for rect in [
                pymupdf.Rect(inf_neg, inf_neg, x0 - delta, inf_pos),
                pymupdf.Rect(x1 + delta, inf_neg, inf_pos, inf_pos),
                pymupdf.Rect(inf_neg, inf_neg, inf_pos, y0 - delta),
                pymupdf.Rect(inf_neg, y1 + delta, inf_pos, inf_pos),
            ]:
                mupdf_page.add_redact_annot(rect, fill=False)
    except Exception:
        print(traceback.format_exc())
        raise RedactionWarning(
                _('Failed to add outside-page redactions on page\xa0{number}.'
                  ).format(number=mupdf_page.number + 1))


def get_redactions(mupdf_page: pymupdf.Page, page: Page = None
                   ) -> list[Redaction]:
    """Get redactions from PDF redaction annotations"""
    redactions = []
    for annotation in mupdf_page.annots(types=[pymupdf.PDF_ANNOT_REDACT]):
        color = annotation.colors['fill']
        if color == []:
            color = None
        page = mupdf_page if page is None else page
        redactions.append(Redaction(annotation.rect, page=page, color=color))
    return redactions


def redact_annotations(mupdf_page: pymupdf.Page) -> None:
    # This should not raise an exception, but it does sometimes
    # See https://codeberg.org/censor/Censor/issues/134
    # and https://github.com/pymupdf/PyMuPDF/issues/4936
    try:
        annots = list(mupdf_page.annots())
        redactions = [Rectangle(annot.rect) for annot in annots
                      if annot.type[0] == pymupdf.PDF_ANNOT_REDACT]
        annotations = [annot for annot in annots
                       if annot.type[0] != pymupdf.PDF_ANNOT_REDACT]
    except Exception:
        print(traceback.format_exc())
        raise RedactionWarning(
                _('Failed to redact annotations on page\xa0{number}.'
                  ).format(number=mupdf_page.number + 1))
    failed_delete_some = False
    for annot in annotations:
        annot_rectangle = Rectangle(annot.rect)
        if any(redaction.overlaps_or_contains(annot_rectangle)
               for redaction in redactions):
            try:
                mupdf_page.delete_annot(annot)
            except Exception:
                failed_delete_some = True
    if failed_delete_some:
        raise RedactionWarning(
                _('Failed to redact some annotations on page\xa0{number}.'
                  ).format(number=mupdf_page.number + 1))


def redact_links(mupdf_page: pymupdf.Page,
                 redactions: list[Redaction] = None) -> None:
    # This should not raise an exception, but it does sometimes
    # See https://codeberg.org/censor/Censor/issues/134
    # and https://github.com/pymupdf/PyMuPDF/issues/4936
    # Note, in case if a link is referenced on multiple pages with the same
    # xref, if it is deleted from one page it is also deleted from other pages.
    try:
        if redactions is None:
            redactions = [Rectangle(r.rect) for r in mupdf_page.annots(
                    types=[pymupdf.PDF_ANNOT_REDACT])]
        links = mupdf_page.get_links()
    except Exception:
        print(traceback.format_exc())
        raise RedactionWarning(
                _('Failed to redact links on page\xa0{number}.'
                  ).format(number=mupdf_page.number + 1))
    failed_delete_some = False
    for link in links:
        link_rectangle = Rectangle(link['from'])
        if any(redaction.overlaps_or_contains(link_rectangle)
               for redaction in redactions):
            try:
                mupdf_page.delete_link(link)
            except Exception:
                failed_delete_some = True
    if failed_delete_some:
        raise RedactionWarning(
                _('Failed to redact some links on page\xa0{number}.'
                  ).format(number=mupdf_page.number + 1))


def redact_widgets(mupdf_page: pymupdf.Page,
                   redactions: list[Redaction] = None) -> None:
    # This should not raise an exception, but it does sometimes
    # See https://codeberg.org/censor/Censor/issues/134
    # and https://github.com/pymupdf/PyMuPDF/issues/4936
    try:
        if redactions is None:
            redactions = [Rectangle(r.rect) for r in mupdf_page.annots(
                    types=[pymupdf.PDF_ANNOT_REDACT])]
        widgets = mupdf_page.widgets()
        derotation_matrix = _derotation_matrix(mupdf_page)
        redactions_rotated = [Rectangle(redaction.pymupdf_rect.transform(
                derotation_matrix)) for redaction in redactions]
    except Exception:
        print(traceback.format_exc())
        raise RedactionWarning(
                _('Failed to redact widgets (form fields, signatures, etc.)'
                  + ' on page\xa0{number}.'
                  ).format(number=mupdf_page.number + 1))
    failed_delete_some = False
    for widget in widgets:
        widget_rectangle = Rectangle(widget.rect)
        if any(redaction.overlaps_or_contains(widget_rectangle)
               for redaction in redactions_rotated):
            try:
                mupdf_page.delete_widget(widget)
            except Exception:
                failed_delete_some = True
    if failed_delete_some:
        raise RedactionWarning(
                _('Failed to redact some widgets (form field, signatures,'
                  + ' etc.) on page\xa0{number}.'
                  ).format(number=mupdf_page.number + 1))


def apply_redactions(
        mupdf_page: pymupdf.Page,
        images: int = pymupdf.PDF_REDACT_IMAGE_PIXELS,
        graphics: int = pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED,
        text: int = pymupdf.PDF_REDACT_TEXT_REMOVE) -> None:
    try:
        mupdf_page.apply_redactions(
                images=images,
                graphics=graphics,
                text=text)
    except pymupdf.mupdf.FzErrorBase as fz_error:
        print(traceback.format_exc())
        if images != pymupdf.PDF_REDACT_IMAGE_PIXELS:
            raise fz_error
        mupdf_page.apply_redactions(
                images=pymupdf.PDF_REDACT_IMAGE_REMOVE,
                graphics=graphics,
                text=text)
        raise RedactionWarning(
                _('Failed to partially redact raster images on '
                  + 'page\xa0{number}: {error_message}. Images were fully '
                  + 'removed instead.'
                  ).format(number=mupdf_page.number + 1,
                           error_message=fz_error.m_text.strip('.')))


def _rotation_matrix(mupdf_page: pymupdf.Page):
    rotation_matrix = pymupdf.Matrix(mupdf_page.rotation_matrix)
    if (mupdf_page.rotation - 90) % 360 == 0:
        rotation_matrix.e = mupdf_page.rect.x1
    if (mupdf_page.rotation - 180) % 360 == 0:
        rotation_matrix.e = mupdf_page.rect.x1
        rotation_matrix.f = mupdf_page.rect.y1
    if (mupdf_page.rotation - 270) % 360 == 0:
        rotation_matrix.f = mupdf_page.rect.y1
    return rotation_matrix


def _derotation_matrix(mupdf_page: pymupdf.Page):
    derotation_matrix = pymupdf.Matrix(_rotation_matrix(mupdf_page))
    derotation_matrix.invert()
    return derotation_matrix


def _scales(mupdf_page: pymupdf.Page):
    rotation = mupdf_page.rotation
    mupdf_page.set_rotation(0)
    scales = (mupdf_page.transformation_matrix.a,
              -mupdf_page.transformation_matrix.d)
    mupdf_page.set_rotation(rotation)
    return scales


def draw_redactions(mupdf_page: pymupdf.Page,
                    redactions: list[Redaction]) -> None:
    # Draw redactions ourself, because PyMuPDF’s redaction drawing for rotated
    # pages is buggy (puts rectangles on wrong position for rotated pages)
    if len(redactions) == 0:
        return
    derotation_matrix = _derotation_matrix(mupdf_page)
    scale_x, scale_y = _scales(mupdf_page)
    rects_colors = []
    for redaction in redactions:
        if redaction.color is None:
            continue
        rect_derotated = redaction.pymupdf_rect.transform(derotation_matrix)
        rect = pymupdf.Rect(rect_derotated).transform(
                pymupdf.Matrix(1/scale_x, 0, 0, 1/scale_y,
                               rect_derotated.x0 * (1 - 1 / scale_x),
                               rect_derotated.y1 * (1 - 1 / scale_y)))
        rects_colors.append((rect, redaction.color))
    if len(rects_colors) == 0:
        return
    rotation = mupdf_page.rotation
    mupdf_page.set_rotation(0)
    shape = mupdf_page.new_shape()
    for rect, color in rects_colors:
        shape.draw_rect(rect)
        shape.finish(width=0, fill=color)
    shape.commit()
    mupdf_page.set_rotation(rotation)


def _sanitize_safer(mupdf_document: pymupdf.Document,
                    keep_links: bool = True, keep_annotations: bool = True,
                    keep_widgets: bool = True) -> pymupdf.Document:
    mupdf_document_copy = pymupdf.Document()
    mupdf_document_copy.insert_pdf(mupdf_document, links=False,
                                   annots=keep_annotations,
                                   widgets=keep_widgets)
    for page, page_copy in zip(mupdf_document, mupdf_document_copy):
        if keep_links:
            page_copy.set_rotation(0)
            for link in page.get_links():
                link['from'] = link['from'].transform(_derotation_matrix(page))
                page_copy.insert_link(link)
            page_copy.set_rotation(page.rotation)
        if keep_widgets:
            for widget in page.widgets():
                page_copy.add_widget(widget)
    return pymupdf.Document(stream=mupdf_document_copy.tobytes(),
                            filetype='pdf')


def sanitize_safer(mupdf_document: pymupdf.Document,
                   keep_links: bool = True, keep_annotations: bool = True,
                   keep_widgets: bool = True) -> pymupdf.Document:
    """Safer sanitization with copying pages. This removes also metadata."""
    # Try first with all enabled
    try:
        return _sanitize_safer(mupdf_document, keep_links=keep_links,
                               keep_annotations=keep_annotations,
                               keep_widgets=keep_widgets)
    except Exception:
        pass
    # If failed, try now with one by one enabled, only
    if keep_links:
        try:
            _sanitize_safer(mupdf_document, keep_links=True,
                            keep_annotations=False, keep_widgets=False)
        except Exception:
            print(traceback.format_exc())
            print('WARNING: Failed to sanitize safer keeping links.')
            keep_links = False
    if keep_annotations:
        try:
            _sanitize_safer(mupdf_document, keep_links=False,
                            keep_annotations=True, keep_widgets=False)
        except Exception:
            print(traceback.format_exc())
            print('WARNING: Failed to sanitize safer keeping annotations.')
            keep_annotations = False
    if keep_widgets:
        try:
            _sanitize_safer(mupdf_document, keep_links=False,
                            keep_annotations=False, keep_widgets=True)
        except Exception:
            print(traceback.format_exc())
            print('WARNING: Failed to sanitize safer keeping widgets.')
            keep_widgets = False
    # Try now again with failing options disabled
    try:
        return _sanitize_safer(mupdf_document, keep_links=keep_links,
                               keep_annotations=keep_annotations,
                               keep_widgets=keep_widgets)
    except Exception:
        print(traceback.format_exc())
        raise SanitizationWarning(
                _('Failed to safer sanitize the document with page copying.'))


def sanitize_standard(mupdf_document: pymupdf.Document,
                      remove_attached_files: bool = True,
                      clean_pages: bool = True,
                      remove_embedded_files: bool = True,
                      remove_hidden_text: bool = True,
                      remove_javascript: bool = True,
                      remove_metadata: bool = True,
                      remove_links: bool = False,
                      reset_fields: bool = True,
                      reset_responses: bool = True,
                      remove_thumbnails: bool = True,
                      remove_xml_metadata: bool = True
                      ):
    """Standard sanitization"""
    # Try first with all enabled
    try:
        mupdf_document.scrub(
                attached_files=remove_attached_files,
                clean_pages=clean_pages,
                embedded_files=remove_embedded_files,
                hidden_text=remove_hidden_text,
                javascript=remove_javascript,
                metadata=remove_metadata,
                # Already done during redaction application
                redactions=False,
                redact_images=0,
                remove_links=remove_links,
                reset_fields=reset_fields,
                reset_responses=reset_responses,
                thumbnails=remove_thumbnails,
                xml_metadata=remove_xml_metadata)
    except Exception:
        pass
    kwargs_all_false = {'attached_files': False,
                        'clean_pages': False,
                        'embedded_files': False,
                        'hidden_text': False,
                        'javascript': False,
                        'metadata': False,
                        # Already done during redaction application
                        'redactions': False,
                        'redact_images': 0,
                        'remove_links': False,
                        'reset_fields': False,
                        'reset_responses': False,
                        'thumbnails': False,
                        'xml_metadata': False
                        }
    failed_actions = []
    if remove_attached_files:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['attached_files'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            remove_attached_files = False
            failed_actions.append(_('attached files removal'))
    if clean_pages:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['clean_pages'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            clean_pages = False
            failed_actions.append(_('page cleaning'))
    if remove_embedded_files:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['embedded_files'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            remove_embedded_files = False
            failed_actions.append(_('embedded files removal'))
    if remove_hidden_text:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['hidden_text'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            remove_hidden_text = False
            failed_actions.append(_('hidden text removal'))
    if remove_javascript:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['javascript'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            remove_javascript = False
            failed_actions.append(_('JavaScript sources removal'))
    if remove_metadata:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['metadata'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            remove_metadata = False
            failed_actions.append(_('metadata removal'))
    if remove_links:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['links'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            remove_links = False
            failed_actions.append(_('links removal'))
    if reset_fields:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['reset_fields'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            reset_fields = False
            failed_actions.append(_('resetting fields'))
    if reset_responses:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['reset_responses'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            reset_responses = False
            failed_actions.append(_('resetting responses'))
    if remove_thumbnails:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['thumbnails'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            remove_thumbnails = False
            failed_actions.append(_('page thumbnail removal'))
    if remove_xml_metadata:
        try:
            kwargs = kwargs_all_false.copy()
            kwargs['xml_metadata'] = True
            pymupdf.Document(stream=mupdf_document.tobytes(), filetype='pdf'
                             ).scrub(**kwargs)
        except Exception:
            print(traceback.format_exc())
            remove_xml_metadata = False
            failed_actions.append(_('XML metadata removal'))
    try:
        mupdf_document.scrub(
                attached_files=remove_attached_files,
                clean_pages=clean_pages,
                embedded_files=remove_embedded_files,
                hidden_text=remove_hidden_text,
                javascript=remove_javascript,
                metadata=remove_metadata,
                # Already done during redaction application
                redactions=False,
                redact_images=0,
                remove_links=remove_links,
                reset_fields=reset_fields,
                reset_responses=reset_responses,
                thumbnails=remove_thumbnails,
                xml_metadata=remove_xml_metadata)
    except Exception:
        print(traceback.format_exc())
        raise SanitizationWarning(
                _('Failed to sanitize the document.'))
    if len(failed_actions) != 0:
        # Translators: the joining separator for lists of items, e.g., apples,
        # pears, oranges
        joiner = _(', ')
        raise SanitizationWarning(
                _('The document was sanitized, but without: {failed_actions}'
                  ).format(failed_actions=joiner.join(failed_actions)))


def validate_redactions(
        mupdf_page: pymupdf.Page,
        redactions: list[Redaction],
        images: int = pymupdf.PDF_REDACT_IMAGE_PIXELS,
        graphics: int = pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED,
        text: int = pymupdf.PDF_REDACT_TEXT_REMOVE,
        annotations: bool = True,
        links: bool = True,
        widgets: bool = True) -> None:
    warnings = []
    derotation_matrix = _derotation_matrix(mupdf_page)
    redactions_rotated = [Rectangle(redaction.pymupdf_rect.transform(
            derotation_matrix)) for redaction in redactions]
    # Check images redaction
    count_images_not_redacted = 0
    # TODO: check partial images redaction for pymupdf.PDF_REDACT_IMAGE_PIXELS?
    if images == pymupdf.PDF_REDACT_IMAGE_REMOVE:
        try:
            image_info = mupdf_page.get_image_info()
            for image in image_info:
                rectangle = Rectangle(image['bbox'])
                if any(redaction.overlaps_or_contains(rectangle)
                       for redaction in redactions_rotated):
                    count_images_not_redacted += 1
            if len(mupdf_page.get_images()) != len(image_info):
                warnings.append(_(
                        'Found possibly unredacted images during '
                        + 'post-processing on page\xa0{number}'
                        ).format(number=mupdf_page.number + 1))
        except Exception:
            print(traceback.format_exc())
            warnings.append(_(
                    'Failed to validate redaction of images during '
                    + 'post-processing on page\xa0{number}'
                    ).format(number=mupdf_page.number + 1))
    if count_images_not_redacted != 0:
        warnings.append(gettext.ngettext(
                'Failed to redact {count}\xa0image on page\xa0{number}',
                'Failed to redact {count}\xa0images on page\xa0{number}',
                count_images_not_redacted
                ).format(count=count_images_not_redacted,
                         number=mupdf_page.number + 1))
    # Check that number of images from different methods matches,
    # see https://codeberg.org/censor/Censor/issues/165
    if images != pymupdf.PDF_REDACT_IMAGE_NONE:
        try:
            n_images_get = len(mupdf_page.get_images())
            n_images_info = len(mupdf_page.get_image_info())
            n_images_blocks = sum(b[-1] == 1 for b in mupdf_page.get_text(
                    'blocks', flags=pymupdf.TEXT_PRESERVE_IMAGES,
                    clip=pymupdf.Rect(
                            pymupdf.FZ_MIN_INF_RECT, pymupdf.FZ_MIN_INF_RECT,
                            pymupdf.FZ_MAX_INF_RECT, pymupdf.FZ_MAX_INF_RECT)))
            if not (n_images_get == n_images_info == n_images_blocks):
                print(f'WARNING: Found {n_images_get} image(s) with'
                      + f" 'pymupdf.Page.get_images()', {n_images_info}"
                      + " image(s) with 'pymupdf.Page.get_image_info()' and"
                      + f' {n_images_blocks} image(s) with'
                      + " 'pymupdf.Page.get_text(\"blocks\","
                      + " flags=pymupdf.TEXT_PRESERVE_IMAGES)'")
                warnings.append(_(
                        'Found possibly unredacted images during '
                        + 'post-processing on page\xa0{number}'
                        ).format(number=mupdf_page.number + 1))
        except Exception:
            print(traceback.format_exc())
            warnings.append(_(
                    'Failed to validate redaction of images during '
                    + 'post-processing on page\xa0{number}'
                    ).format(number=mupdf_page.number + 1))
    # Check drawings redaction
    count_drawings_not_redacted = 0
    if graphics != pymupdf.PDF_REDACT_LINE_ART_NONE:
        try:
            matched_redaction_indices = []
            for drawing in mupdf_page.get_drawings():
                drawing_rectangle = Rectangle(drawing['rect'])
                matched_redaction = False
                for i, redaction in enumerate(redactions):
                    if (i not in matched_redaction_indices
                            and redaction.isclose(drawing_rectangle)):
                        matched_redaction_indices.append(i)
                        matched_redaction = True
                        break
                if matched_redaction:
                    continue
                if (graphics == pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED
                    and any(redaction.overlaps_or_contains(drawing_rectangle)
                            for redaction in redactions)
                    or
                    graphics == pymupdf.PDF_REDACT_LINE_ART_REMOVE_IF_COVERED
                    and any(redaction.contains(drawing_rectangle)
                            for redaction in redactions)):
                    count_drawings_not_redacted += 1
            # Check that number of drawings from different methods matches,
            # TODO: Commented for now, it seems that 'pymupdf.Page.get_text()'
            # is unreliable?
            # n_drawings_get = len(mupdf_page.get_drawings())
            # n_drawings_blocks = sum(b[-1] == 3 for b in mupdf_page.get_text(
            #         'blocks', flags=pymupdf.TEXT_COLLECT_VECTORS,
            #         clip=pymupdf.Rect(
            #             pymupdf.FZ_MIN_INF_RECT, pymupdf.FZ_MIN_INF_RECT,
            #             pymupdf.FZ_MAX_INF_RECT, pymupdf.FZ_MAX_INF_RECT)))
            # if not (n_drawings_get <= n_drawings_blocks <= 2*n_drawings_get):
            #     print(f'WARNING: Found {n_drawings_get} drawing(s) with '
            #       + f"'pymupdf.Page.get_drawings()' and {n_drawings_blocks}"
            #       + " drawing(s) with 'pymupdf.Page.get_text(\"blocks\", "
            #       + "flags=pymupdf.TEXT_COLLECT_VECTORS)'")
            #     warnings.append(_(
            #             'Found possibly unredacted drawings during '
            #             + 'post-processing on page\xa0{number}'
            #             ).format(number=mupdf_page.number + 1))
        except Exception:
            print(traceback.format_exc())
            warnings.append(_(
                    'Failed to validate redaction of drawings during '
                    + 'post-processing on page\xa0{number}'
                    ).format(number=mupdf_page.number + 1))
    if count_drawings_not_redacted != 0:
        warnings.append(gettext.ngettext(
                'Failed to redact {count}\xa0drawing on page\xa0{number}',
                'Failed to redact {count}\xa0drawings on page\xa0{number}',
                count_drawings_not_redacted
                ).format(count=count_drawings_not_redacted,
                         number=mupdf_page.number + 1))
    # Check text redaction
    text_not_redacted = []
    if text == pymupdf.PDF_REDACT_TEXT_REMOVE:
        try:
            for redaction in redactions:
                # Ignore check for text redaction if redaction width or height
                # is less than 2 pixel
                if redaction.width < 2 or redaction.height < 2:
                    continue
                clip = pymupdf.Rect(redaction.x0 + 1, redaction.y0 + 1,
                                    redaction.x1 - 1, redaction.y1 - 1)
                text_found = mupdf_page.get_text(clip=clip).strip()
                if text_found != '':
                    text_not_redacted.append(text_found)
        except Exception:
            print(traceback.format_exc())
            warnings.append(_(
                    'Failed to validate redaction of text during '
                    + 'post-processing on page\xa0{number}'
                    ).format(number=mupdf_page.number + 1))
    if len(text_not_redacted) != 0:
        warnings.append(
                _('Failed to redact the following text on page\xa0{number}: '
                  + '{text}'
                  ).format(number=mupdf_page.number + 1,
                           text=repr(' '.join(text_not_redacted))
                           ))
    # Check annotations redaction
    count_annotations_not_redacted = 0
    if annotations:
        try:
            for annot in mupdf_page.annots():
                if any(redaction.overlaps_or_contains(Rectangle(annot.rect))
                       for redaction in redactions):
                    count_annotations_not_redacted += 1
        except Exception:
            print(traceback.format_exc())
            warnings.append(_(
                    'Failed to validate redaction of annotations during '
                    + 'post-processing on page\xa0{number}'
                    ).format(number=mupdf_page.number + 1))
    if count_annotations_not_redacted != 0:
        warnings.append(gettext.ngettext(
                'Failed to redact {count}\xa0annotation on page\xa0{number}',
                'Failed to redact {count}\xa0annotations on page\xa0{number}',
                count_annotations_not_redacted
                ).format(count=count_annotations_not_redacted,
                         number=mupdf_page.number + 1))
    # Check widgets redaction
    count_widgets_not_redacted = 0
    if widgets:
        try:
            for widget in mupdf_page.widgets():
                if any(redaction.overlaps_or_contains(Rectangle(widget.rect))
                       for redaction in redactions):
                    count_widgets_not_redacted += 1
        except Exception:
            print(traceback.format_exc())
            warnings.append(_(
                    'Failed to validate redaction of widgets during '
                    + 'post-processing on page\xa0{number}'
                    ).format(number=mupdf_page.number + 1))
    if count_widgets_not_redacted != 0:
        warnings.append(gettext.ngettext(
                'Failed to redact {count}\xa0widget on page\xa0{number}',
                'Failed to redact {count}\xa0widgets on page\xa0{number}',
                count_widgets_not_redacted
                ).format(count=count_widgets_not_redacted,
                         number=mupdf_page.number + 1))
    # Check links redaction
    count_links_not_redacted = 0
    if links:
        try:
            for link in mupdf_page.links():
                if any(redaction.overlaps_or_contains(Rectangle(link['from']))
                       for redaction in redactions):
                    count_links_not_redacted += 1
        except Exception:
            print(traceback.format_exc())
            warnings.append(_(
                    'Failed to validate redaction of links during '
                    + 'post-processing on page\xa0{number}'
                    ).format(number=mupdf_page.number + 1))
    if count_links_not_redacted != 0:
        warnings.append(gettext.ngettext(
                'Failed to redact {count}\xa0link on page\xa0{number}',
                'Failed to redact {count}\xa0links on page\xa0{number}',
                count_links_not_redacted
                ).format(count=count_links_not_redacted,
                         number=mupdf_page.number + 1))
    # for t in text_not_redacted:
    #     print(mupdf_page.number + 1, 'TEXT      ', repr(t))
    # for i in mupdf_page.get_images():
    #     print(mupdf_page.number + 1, 'IMAGE     ',
    #           mupdf_page.get_image_rects(i))
    # for d in mupdf_page.get_drawings():
    #     print(mupdf_page.number + 1, 'DRAWING   ', d['rect'])
    # for a in mupdf_page.annots():
    #     print(mupdf_page.number + 1, 'ANNOTATION', a.rect)
    # for w in mupdf_page.widgets():
    #     print(mupdf_page.number + 1, 'WIDGET    ', w.rect)
    # for l in mupdf_page.links():
    #     print(mupdf_page.number + 1, 'LINK      ', l['from'])
    # for r in redactions:
    #     print(mupdf_page.number + 1, 'REDACTION ', r.pymupdf_rect)
    # for r in redactions_rotated:
    #     print(mupdf_page.number + 1, 'REDACTIONR', r.pymupdf_rect)
    # print(mupdf_page.number + 1, 'ROTATION  ', mupdf_page.rotation)
    # print(mupdf_page.number + 1, 'SCALES X,Y', _scales(mupdf_page))
    if len(warnings) != 0:
        raise RedactionWarning('\n'.join(warnings))

# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2026 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import traceback


def format_exception(exception: Exception):
    return traceback.format_exception_only(exception)[0].strip()

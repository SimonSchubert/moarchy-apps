# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import locale
import os
import platform

import gi
gi.require_versions({'Adw': '1', 'Gdk': '4.0', 'GLib': '2.0', 'Gtk': '4.0',
                     'Rsvg': '2.0'})  # noqa: E402
from gi.repository import Adw, Gdk, GLib, Gtk, Rsvg

import pymupdf


class AboutDialog():
    def __init__(self, version, application_id='page.codeberg.censor.Censor'):
        self.dialog = Adw.AboutDialog(
                application_name=_('Censor'),
                application_icon='page.codeberg.censor.Censor',
                version=version,
                website='https://codeberg.org/censor/Censor',
                issue_url='https://codeberg.org/censor/Censor/issues',
                developer_name='Robert Wolff',
                developers=['Robert Wolff <mahlzahn@posteo.de>'],
                debug_info=debug_info(version, application_id),
                license_type=Gtk.License.AGPL_3_0_ONLY)
        # Translators: Replace "translator-credits" with your name or username,
        # optionally followed by your email address between less-than and
        # greater-than signs ("<>") or a link to your Codeberg or Codeberg
        # Translate user profile (without "<>"), e.g., "mahlzahn",
        # "Robert Wolff <mahlzahn@posteo.de>",
        # "mahlzahn https://translate.codeberg.org/user/mahlzahn/", or
        # "Robert Wolff https://codeberg.org/mahlzahn"
        self.dialog.set_translator_credits(_('translator-credits'))
        self.dialog.add_legal_section(
                _('Censor’s Source Code'),
                copyright('Robert Wolff'),
                Gtk.License.GPL_3_0)
        self.dialog.add_legal_section(
                _('Censor’s Artwork'),
                copyright('Robert Wolff'),
                Gtk.License.CUSTOM,
                _('The artwork is licensed under the <a href='
                  + '"https://creativecommons.org/licenses/by-sa/4.0/deed.en">'
                  + 'Creative Commons Attribution-ShareAlike 4.0 International'
                  + ' license</a>.'))
        self.dialog.add_legal_section(
                _('PyMuPDF {pymupdf_version} and MuPDF {mupdf_version}'
                  ).format(
                      pymupdf_version=pymupdf.pymupdf_version,
                      mupdf_version=pymupdf.mupdf_version),
                copyright('Artifex'),
                Gtk.License.AGPL_3_0_ONLY)

    def present(self, parent):
        self.dialog.present(parent)


def copyright(copyright: str) -> str:
    if Gtk.Widget.get_default_direction() == Gtk.TextDirection.RTL:
        return copyright + ' ©'
    return '© ' + copyright


def debug_info(version: str, application_id='page.codeberg.censor.Censor'):
    flatpak_id = os.environ.get('FLATPAK_ID')
    source = 'native' if flatpak_id is None else 'Flatpak'
    info = f'Censor: {version} ({source})\n'
    info += f'ID: {application_id if flatpak_id is None else flatpak_id}\n\n'
    info += f'PyMuPDF: {pymupdf.pymupdf_version}\n'
    info += f'MuPDF: {pymupdf.mupdf_version}\n\n'

    try:
        info += f"OS: {platform.freedesktop_os_release()['PRETTY_NAME']}\n"
    except Exception:
        pass
    info += f'{platform.system()}: {platform.release()}'
    info += f' ({platform.machine()})\n'
    info += f"Locale: {'.'.join(locale.getlocale())}\n"
    info += f'Python: {platform.python_version()}\n'
    info += f'PyGObject: {gi_module_version(gi)}\n'
    info += f'GTK: {gi_module_version(Gtk)}\n'
    info += f'Adwaita: {gi_module_version(Adw)}\n'
    info += f'GLib: {gi_module_version(GLib)}\n'
    info += f'Rsvg: {gi_module_version(Rsvg)}\n\n'

    info += f'Monitors: {monitor_info()}'

    return info


def gi_module_version(module):
    try:
        return module.VERSION_S
    except AttributeError:
        pass
    try:
        return module.VERSION
    except AttributeError:
        pass
    try:
        major = module.MAJOR_VERSION
        minor = module.MINOR_VERSION
        micro = module.MICRO_VERSION
        return f'{major}.{minor}.{micro}'
    except AttributeError:
        pass
    try:
        major, minor, micro = module.version_info
        return f'{major}.{minor}.{micro}'
    except AttributeError:
        pass
    return module._version


def monitor_info():
    try:
        info = ''
        for monitor in Gdk.Display.get_default().get_monitors():
            geometry = monitor.get_geometry()
            info += f'\n- {monitor.get_description()} ('
            info += f'{geometry.width} × {geometry.height}, '
            info += f'{monitor.get_width_mm() / 10:.1f} cm '
            info += f'× {monitor.get_height_mm() / 10:.1f} cm, '
            dpi_x = geometry.width * 25.4 / monitor.get_width_mm()
            dpi_y = geometry.height * 25.4 / monitor.get_height_mm()
            dpi = (geometry.width * dpi_x + geometry.height * dpi_y) / (
                    geometry.width + geometry.height)
            info += f'{dpi:.1f} DPI)'
        return info
    except Exception:
        return 'information unavailable'

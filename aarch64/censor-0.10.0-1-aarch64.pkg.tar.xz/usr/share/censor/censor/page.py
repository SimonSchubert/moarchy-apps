# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

from collections import UserList

import gi
gi.require_version('Rsvg', '2.0')  # noqa: E402
from gi.repository import Rsvg

import pymupdf

from .rectangle import Rectangle


class Page(UserList, Rectangle):
    def __init__(self, mupdf_page: pymupdf.Page) -> None:
        self.mupdf_page = mupdf_page
        # MuPDF internally uses 72 dpi
        self._dpi = 72
        # Rectangle with page width and height
        bound = mupdf_page.bound()
        Rectangle.__init__(self, 0, 0, bound.width, bound.height)
        # List of redactions
        self.data = []

    @property
    def modified(self) -> bool:
        return len(self) != 0

    @property
    def dpi(self) -> int | float:
        "Original dot density in dpi"
        return self._dpi

    def get_height(self, dpi: int | float) -> int | float:
        "Page height in pixels for given dot density in dpi"
        return self.height * dpi / self._dpi

    def get_width(self, dpi: int | float) -> int | float:
        "Page height in pixels for given dot density in dpi"
        return self.width * dpi / self._dpi

    @property
    def handle(self) -> Rsvg.Handle:
        "SVG content"
        if not hasattr(self, "_handle"):
            svg_image = self.mupdf_page.get_svg_image()
            self._handle = Rsvg.Handle.new_from_data(svg_image.encode("utf-8"))
        return self._handle

    def __repr__(self) -> str:
        return repr(self.mupdf_page)

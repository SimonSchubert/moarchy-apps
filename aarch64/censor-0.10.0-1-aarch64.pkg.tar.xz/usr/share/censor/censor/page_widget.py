# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

from collections.abc import Callable

import gi
gi.require_versions({'Gio': '2.0', 'GLib': '2.0', 'Gtk': '4.0'})  # noqa: E402
from gi.repository import Gio, GLib, Gtk

from .action import Action
from .page import Page
from .rectangle import Rectangle
from .redaction import Redaction


@Gtk.Template(resource_path='/page/codeberg/censor/Censor/page_widget.ui')
class PageWidget(Gtk.Box):
    __gtype_name__ = "PageWidget"

    redaction_context_menu = Gtk.Template.Child()

    def __init__(self, perform: Callable[[Action], bool]) -> None:
        """Initialize page widget

        perform: callback function with actions to be performed as input
            argument
        """
        super().__init__()

        self._perform = perform

        self._selection = None
        self._selection_done = None
        self._dpi = 96

        self.frame = Gtk.Frame()
        self.frame.add_css_class("page-frame")

        self.set_halign(Gtk.Align.CENTER)
        self.set_valign(Gtk.Align.CENTER)
        self.append(self.frame)

        self.overlay = Gtk.Overlay()
        self.frame.set_child(self.overlay)

        self.area_content = Gtk.DrawingArea()
        self.area_content.set_draw_func(self.draw_content)
        self.overlay.set_child(self.area_content)

        self.area_redactions = Gtk.DrawingArea()
        self.area_redactions.set_draw_func(self.draw_redactions)
        self.overlay.add_overlay(self.area_redactions)

        # Gestures for selecting redactions, clicking for deleting
        gesture_drag = Gtk.GestureDrag()
        gesture_drag.connect("drag-begin", self.on_drag_begin)
        gesture_drag.connect("drag-update", self.on_drag_update)
        gesture_drag.connect("drag-end", self.on_drag_end)
        self.frame.add_controller(gesture_drag)

        self.action_group = Gio.SimpleActionGroup()
        delete_action = Gio.SimpleAction.new("delete")
        delete_action.connect("activate", self.on_delete)
        self.action_group.add_action(delete_action)
        self.insert_action_group("page", self.action_group)

        self.popover_menu = Gtk.PopoverMenu.new_from_model(
                self.redaction_context_menu)
        self.popover_menu.set_has_arrow(False)
        self.popover_menu.set_parent(self.area_redactions)
        self.popover_menu.set_halign(Gtk.Align.START)

        def on_closed(*_):
            self._selection = None
            self.area_redactions.queue_draw()

        self.popover_menu.connect("closed",
                                  lambda *_: GLib.idle_add(on_closed))

        gesture_click = Gtk.GestureClick(button=3)
        gesture_click.connect("pressed", self.on_right_click)
        self.area_redactions.add_controller(gesture_click)

        self.area_redactions.set_cursor_from_name("crosshair")

    @property
    def page(self) -> Page:
        return self._page

    @page.setter
    def page(self, value: Page) -> None:
        self._page = value
        self._scale = self._dpi / self._page.dpi
        self.set_size_request(self.page.width * self._scale,
                              self.page.height * self._scale)
        self.frame.set_size_request(self.page.width * self._scale,
                                    self.page.height * self._scale)
        self.area_content.queue_draw()
        self.area_redactions.queue_draw()

    @property
    def dpi(self) -> int | float:
        return self._dpi

    @dpi.setter
    def dpi(self, value: int | float) -> None:
        self._dpi = value
        self._scale = self._dpi / self._page.dpi
        self.set_size_request(self.page.width * self._scale,
                              self.page.height * self._scale)
        self.frame.set_size_request(self.page.width * self._scale,
                                    self.page.height * self._scale)

    def draw_content(self, area, ctx, width, height):
        "Draw content"
        # Scale for zooming
        ctx.scale(self._scale, self._scale)
        # White background
        ctx.rectangle(self.page.x, self.page.y,
                      self.page.width, self.page.height)
        ctx.set_source_rgb(1, 1, 1)
        ctx.fill()
        # Content
        self.page.handle.render_document(ctx, self.page.rsvg_rectangle)

    def draw_redactions(self, area, ctx, width, height):
        "Draw redactions and current selection"
        # Scale for zooming
        ctx.scale(self._scale, self._scale)
        # MuPDF adds a stroke of 1 px around redacted areas
        ctx.set_line_width(1)
        # Redactions
        for redaction in self.page:
            if redaction is self._selection:
                continue
            ctx.rectangle(redaction.x + 0.5, redaction.y + 0.5,
                          redaction.width - 1, redaction.height - 1)
            ctx.set_source_rgba(0, 0, 0, 0.7)
            ctx.fill_preserve()
            ctx.set_source_rgba(0, 0, 0, 1)
            ctx.stroke()
        # Current selection
        if self._selection is not None:
            ctx.rectangle(self._selection.x + 0.5,
                          self._selection.y + 0.5,
                          self._selection.width - 1,
                          self._selection.height - 1)
            color = area.get_style_context().lookup_color('accent_color')[1]
            ctx.set_source_rgba(color.red, color.green, color.blue, 0.5)
            ctx.fill_preserve()
            ctx.set_source_rgba(color.red, color.green, color.blue, 1)
            ctx.stroke()

    def on_drag_begin(self, gesture, x, y):
        self._drag = self._selection = Rectangle(x / self._scale,
                                                 y / self._scale)

    def on_drag_update(self, gesture, dx, dy):
        if self._selection is not None:
            self._selection = Rectangle(self._drag.x, self._drag.y,
                                        self._drag.x + dx / self._scale,
                                        self._drag.y + dy / self._scale)
        self.area_redactions.queue_draw()

    def on_drag_end(self, gesture, dx, dy) -> bool:
        if self._selection is None:
            return False
        if dx != 0 and dy != 0:
            redaction = Redaction(self._drag.x, self._drag.y,
                                  self._drag.x + dx / self._scale,
                                  self._drag.y + dy / self._scale,
                                  page=self.page)
            # Crop to page area
            redaction = redaction.intersection(self.page)
            self._perform(Action(None, redaction))
        self._selection = None
        self.area_redactions.queue_draw()
        return True

    def on_right_click(self, gesture, n, x, y):
        point = Rectangle(x / self._scale, y / self._scale)
        self.popover_menu.set_pointing_to(Rectangle(x, y).gdk_rectangle)
        for redaction in reversed(self.page):
            if point in redaction:
                self._selection = redaction
                self.popover_menu.popup()
                return True
        self._selection = None
        return False

    def on_delete(self, action, parameters):
        print(action, parameters)
        self._perform(Action(self._selection, None))
        self._selection = None

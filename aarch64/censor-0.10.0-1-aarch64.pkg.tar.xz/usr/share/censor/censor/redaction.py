# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

from __future__ import annotations

from .rectangle import Rectangle


class Redaction(Rectangle):
    def __init__(self,
                 x0: int | float | Redaction = 0,
                 y0: int | float = 0,
                 x1: int | float | None = None,
                 y1: int | float | None = None,
                 page: int | list[int] | None = None,
                 color: tuple[float, float, float] | None = (0., 0., 0.)):
        """
        Parameters
        ----------
        x0, y0, x1, y1: the extensions in x and y of the redaction rectangle.
            x0 might also be an instance of Redaction, then other arguments are
            ignored
        page: the page or pages on which the redaction is applied
        color: the fill color of the redaction as RGB tuple, None means
            transparency
        """
        super().__init__(x0=x0, y0=y0, x1=x1, y1=y1)
        if isinstance(x0, Redaction):
            self._page = x0._page
            self._color = x0._color
            return
        self._page = page
        self._color = color

    @property
    def page(self):
        return self._page

    @property
    def color(self):
        return self._color

    def __repr__(self):
        return (f'Redaction({self.x0}, {self.y0}, {self.x1}, {self.y1}, '
                + f'page={self.page}, color={self.color})')

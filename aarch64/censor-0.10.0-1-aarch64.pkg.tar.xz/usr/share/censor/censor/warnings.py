# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2026 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later


class SanitizationWarning(UserWarning):
    pass


class RedactionWarning(UserWarning):
    pass

# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2026 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import gi
gi.require_versions({'Gio': '2.0', 'Gtk': '4.0'})  # noqa: E402
from gi.repository import Gio, Gtk

FILE_FILTER_PDF = Gtk.FileFilter(
    name=_('PDF Documents'),
    mime_types=['application/pdf'],
    suffixes=['pdf'])

FILE_FILTER_JSON = Gtk.FileFilter(
    name=_('JSON Files'),
    mime_types=['application/json'],
    suffixes=['json'])

FILE_FILTER_ALL = Gtk.FileFilter(
    name=_('All Files'),
    patterns=['*'])

FILE_FILTERS_PDF = Gio.ListStore.new(Gtk.FileFilter)
FILE_FILTERS_PDF.append(FILE_FILTER_PDF)
FILE_FILTERS_PDF.append(FILE_FILTER_ALL)

FILE_FILTERS_JSON = Gio.ListStore.new(Gtk.FileFilter)
FILE_FILTERS_JSON.append(FILE_FILTER_JSON)
FILE_FILTERS_JSON.append(FILE_FILTER_ALL)

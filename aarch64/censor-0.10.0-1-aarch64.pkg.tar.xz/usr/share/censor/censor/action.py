# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import collections


class Action(collections.namedtuple("Action", ["before", "after"])):
    def reversed(self):
        return Action(*reversed(self))

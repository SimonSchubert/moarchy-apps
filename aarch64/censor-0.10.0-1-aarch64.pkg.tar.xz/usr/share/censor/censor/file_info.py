# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2026 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import os

import gi
gi.require_versions({'Gio': '2.0', 'GLib': '2.0', 'Gtk': '4.0'})  # noqa: E402
from gi.repository import Gio, GLib, Gtk


class FileInfo:
    def __init__(self, file: Gio.File):
        self.file = file
        self.path = file.get_path()
        self.name = file.get_basename()
        host_path_attribute = 'xattr::document-portal.host-path'
        info = file.query_info(host_path_attribute,
                               Gio.FileQueryInfoFlags.NONE, None)
        self.host_path = info.get_attribute_as_string(host_path_attribute)
        if self.host_path is None:
            self.host_path = self.path
        self.directory = os.path.dirname(self.host_path)
        home_dir = GLib.get_home_dir()
        if self.directory.startswith(home_dir):
            self.directory = '~' + self.directory.removeprefix(home_dir)

    def match(self, file_filter: Gtk.FileFilter) -> bool:
        info = self.file.query_info("standard::*", Gio.FileQueryInfoFlags.NONE,
                                    None)
        return file_filter.match(info)

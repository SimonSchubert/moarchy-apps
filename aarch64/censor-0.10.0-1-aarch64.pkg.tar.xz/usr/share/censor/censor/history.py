# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

from .action import Action


class History:
    "History of actions with past and future"

    def __init__(self):
        "Initialize self"
        self._past = []
        self._future = []

    @property
    def past(self) -> list[Action]:
        "Past"
        return self._past

    @property
    def future(self) -> list[Action]:
        "Future"
        return self._future

    def append(self, action: Action) -> None:
        "Do an action, clear future"
        self.past.append(action)
        self.future.clear()

    def undo(self) -> Action | None:
        "Undo and return last action or None if nothing to be undone"
        if not self.past:
            return None
        action = self.past.pop()
        self.future.append(action)
        return action

    def redo(self) -> Action | None:
        "Redo and return the previously undone action or return None"
        if not self.future:
            return None
        action = self.future.pop()
        self.past.append(action)
        return action

    def __getitem__(self, index) -> Action:
        "Return self[index]"
        return self.past[index]

    def __len__(self) -> int:
        "Return len(self)"
        return len(self.past)

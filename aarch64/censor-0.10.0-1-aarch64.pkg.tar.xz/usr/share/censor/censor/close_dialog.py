# Censor: PDF Document Redaction for the GNOME Desktop
#
# SPDX-FileCopyrightText: 2025 Robert Wolff <mahlzahn@posteo.de>
# SPDX-License-Identifier: GPL-3.0-or-later

import gi
gi.require_versions({'Adw': '1', 'Gtk': '4.0'})  # noqa: E402
from gi.repository import Adw, Gtk


@Gtk.Template(resource_path='/page/codeberg/censor/Censor/close_dialog.ui')
class CloseDialog(Adw.AlertDialog):
    __gtype_name__ = "CloseDialog"
